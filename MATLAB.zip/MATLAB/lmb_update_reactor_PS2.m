function [ reactor_slug ] = lmb_update_reactor_PS2( reactor_slug, all_slugs, react_slug, time, num_passes_completed,volume_outlet_to_quench)
%PS2 detection: update reactor slug 
% Input:
% reactor_slug
% all_slugs
% react_slug
% time
% num_passes_completed

% Output:
% reactor_slug

reactor_slug = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug );

reactor_slug.time_PS2_detection = time;  
reactor_slug.time_between_PD_PS2 =  reactor_slug.time_PS2_detection- reactor_slug.time_next_detection(num_passes_completed,1);

if  reactor_slug.time_between_PD_PS2 ~= 0 &&  volume_outlet_to_quench ~=0
    
reactor_slug.average_flow_rate_PD_PS2 = volume_outlet_to_quench/reactor_slug.time_between_PD_PS2 /1000*60;

end




end

