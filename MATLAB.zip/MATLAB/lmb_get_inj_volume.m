function [ base_inj_vol,quench_inj_vol] = lmb_get_inj_volume(all_slugs)
% finds the next slug to enter the reactor 
% determines injection volume to control which syringe has to be purged


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LMB
% 5/16/2018
%
% Inputs:
%               all_slugs is the list of slugs
%              
%               
% Outputs:
%          
%               base_inj_vol is the volume (uL) to inject right before the
%                   next reaction step (to prep injection)
%               quench_inj_vol is the volume (uL) to inject right after the
%                   next reaction step
%             
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Defaults
i = 0;
base_inj_vol = 0;
quench_inj_vol = 0;

    
i = find(cwc_list_property(all_slugs, 'injected') == 0, 1, 'first');%find next slug to be prepared

if i ~= 0
               
quench_inj_vol = all_slugs(i).quench_vol;            %get injection volumes
base_inj_vol = all_slugs(i).base_vol;

end


end