function [all_slugs] = ...
    cwc_mark_slug_injected_quench_v3(all_slugs, inj_slug, inj_vol, step)
% marks a slug as being injected into with quench
% v2Q is intended for multi-step chemistry where the multiple injections
%   occur at the outlet
% v3 is intended for flexible multistep chemistry (either inlet or outlet)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
% January 26, 2015
%
% Inputs:
%               all_slugs list of slugs
%               inj_slug is the INDEX assigned to the injected slug
%               inj_vol is the volume to inject
%               step is the current reaction step 
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Injected quench for (after) this step
if step == length(all_slugs(inj_slug).residence_time_goal)
    all_slugs(inj_slug).inj_quench = 1;
else
    all_slugs(inj_slug).multi_injected(step) = 1;
end
% Increase current slug volume
all_slugs(inj_slug).current_vol = all_slugs(inj_slug).current_vol + inj_vol;
% Record as out of the reactor
all_slugs(inj_slug).in_reactor = 0;

end