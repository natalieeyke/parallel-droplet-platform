function [ all_slugs_ret, opt_state_ret, output_prompt ] = ...
    lmb_optimization_add_slugs_as_needed_v3( all_slugs_old, opt_state_old ) 
%v2
% output of cval_yield_opts for yield optimum: N_cv x (number of discrete var combinations)
% v3
% optimization parameters are saved in opt_state object
% lmb adapted kwg_cwc version for multiple discrete variables

%Load optimization parameters
lin = opt_state_old.lin; 
percent_improve = opt_state_old.percent_improve;
N_extra = opt_state_old.N_extra;
yield_criterion = opt_state_old.yield_criterion;
tol = opt_state_old.tol;
patience = opt_state_old.patience;
buffer = opt_state_old.buffer;
counter_i = opt_state_old.counter_i;
not_improving = opt_state_old.not_improving;
prev_best_b = opt_state_old.prev_best_b;
fathomed_dvals = opt_state_old.fathomed_dvals;
removed_dvals = opt_state_old.removed_dvals;
opt_done = opt_state_old.opt_done;
opt_variables = opt_state_old.opt_variables;
iteration_counter = opt_state_old.iteration_counter;

opt_state_ret = opt_state_old; %save optimization variables

%% Get RSM parameters
% Get experimental matrix
all_slugs = all_slugs_old; %create a copy that can be modified
all_slugs_ret = all_slugs_old; %return original list of all slugs


output_prompt = []; %initialize output prompt

function output_prompt = push_message(output_prompt, new_message)

    disp(new_message);
    output_prompt = [output_prompt new_message '\n'];
    
end

for  i=1:size(removed_dvals,2)
    [ all_slugs ] = lmb_dvals_remove(all_slugs, opt_variables, removed_dvals(:,i)); %remove experiments associated with discrete variable combo that should be removed
 
end

[ completed_slugs ] = cwc_optimization_completed_slugs( all_slugs );%update property that marks slugs as finished
if lin
    [ X ] = lmb_optimization_slugs_to_linmat( completed_slugs, opt_variables,removed_dvals );
else
    [ X ] = lmb_optimization_slugs_to_quadmat( completed_slugs, opt_variables,removed_dvals ); %generates the model matrix of independent variables
end
[ dval_labels ] = cwc_optimization_slugs_to_dval_labels( completed_slugs, opt_variables );%creates cell array with slug labels, useful for graphing

% Get weights
[ W_unnorm ] = cwc_optimization_slugs_to_weights( completed_slugs );
[ W ] = W_unnorm * length(diag(W_unnorm)) / sum(diag(W_unnorm)); % normalized so average == 1

    
% Get objective function values
[ b ] = cwc_list_property( completed_slugs, 'objective' );

% Get yield values 
[ yield_vals ] = cwc_list_property( completed_slugs, 'yield' );
[ log_yield_vals ] = log( yield_vals );
 
% Get WLS parameters
  
str=['Number of completed experiments: ' num2str(length(b))];
output_prompt = push_message(output_prompt,str);
str = ['Number of parameters:            ' num2str(size(X, 2))];
output_prompt = push_message(output_prompt,str);
str = ['Rank of X:                       ' num2str(rank(X,tol))];
output_prompt = push_message(output_prompt,str);


if length(b) < size(X, 2)
    str = 'More parameters to fit than experiments';
    warning(str)
    output_prompt = push_message(output_prompt,str);
end
if rank(X,tol) < size(X, 2)
    str = 'More parameters to fit than rank of X';
    warning(str)
    output_prompt = push_message(output_prompt,str);
end



% Response surface fitting
[T_obj, stdT_obj, mse_obj, S_obj] = lscov(X, b, diag(W)); % objective
[T_y, stdT_y, mse_y, S_y] = lscov(X, log_yield_vals, diag(W)); % yield

 

%% Use the predicted optimum to see if we can fathom any discrete vars
check = false; % initialize
fathomed_pre = false; % initialize

for i = 1:size(fathomed_dvals,2)

remove_dvals = fathomed_dvals(:,i);


[ all_slugs_new ] = lmb_dvals_remove(all_slugs, opt_variables, remove_dvals); %remove experiments associated with discrete variable combo that should be removed

removed_dvals_new = [removed_dvals, remove_dvals]; %all discrete variable combos that would be removed

[ opt_variables_new ] = lmb_update_opt_var( opt_variables, removed_dvals_new ); %remove values from discrete optimization values if all combinations have been removed         
[ check ] = lmb_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol, removed_dvals_new);



    if check
        removed_exp = length(all_slugs) - length(all_slugs_new);

        all_slugs = all_slugs_new;
        removed_dvals = removed_dvals_new;  % add to removed variable list
        opt_variables  = opt_variables_new; 

        str =['Fathoming out discrete variable set ' ...
               num2str(remove_dvals') ' from fathom queue'];
        output_prompt = push_message(output_prompt,str);   
        str = ['...removed ' num2str(removed_exp) ' experiments']; 
        output_prompt = push_message(output_prompt,str);


        fathomed_dvals(:,i) = zeros(size(fathomed_dvals,1),1); % mark with 0 for removal after for loop is done

        fathomed_pre = true;
    end %if
end %for 
 
removals = lmb_find_dval_combo( fathomed_dvals , zeros(size(fathomed_dvals,1),1)); %get index for columns marked with 0
if~isempty(removals)
    fathomed_dvals(:,removals) = []; % remove from fathoming queue
end
% 

if fathomed_pre
    str = ['Reset convergence timer, making progress!'];
    output_prompt = push_message(output_prompt,str);
    not_improving = -1;
        opt_state_ret.counter_i = counter_i;
        opt_state_ret.not_improving = not_improving;
        opt_state_ret.prev_best_b = prev_best_b;
        opt_state_ret.fathomed_dvals = fathomed_dvals;
        opt_state_ret.removed_dvals = removed_dvals;
        opt_state_ret.opt_done = opt_done;
        opt_state_ret.opt_variables = opt_variables;
    return
end %if

 
% Find the predicted optima
    [ cvals_opts, b_opts, yield_opts, dvals_combos,cval_yield_opts  ] = ...
        lmb_optimization_estimate_max( T_obj, T_y, opt_variables, lin, fathomed_dvals, removed_dvals, yield_criterion);
     


% Get maximum yield
max_yield = max(yield_opts);

% Get maximum objective
[b_opt_max, i_opt] = max(b_opts);

% Get yield/cvals/dvals at maximum objective
y_opt_max = yield_opts(i_opt);
cvals_yield_opt_max = cval_yield_opts(:,i_opt);
cvals_opt_max = cvals_opts(:, i_opt);
dvals_opt_max = dvals_combos(:, i_opt);




str_obj1=['> Estimated max objective at discrete variable = ' num2str(dvals_opt_max') ...
          '\n continuous variables = ' num2str(cvals_opt_max')];
output_prompt = push_message(output_prompt,str_obj1);

str_y1=['> Estimated max yield at discrete variable = ' num2str(dvals_opt_max') ...
          '\n continuous variables = ' num2str(cvals_yield_opt_max')];
output_prompt = push_message(output_prompt,str_y1);
   
innermat = inv(X' * W * X);

% Estimate uncertainty at optimum
X_opt_obj = lmb_optimization_cvals_to_X( cvals_opt_max, dvals_opt_max, ...
                                     opt_variables, lin,removed_dvals );


 
    
%for objective function optimum:
b_opt_b_max = b_opt_max; %objective function optimum value
b_opt_y_max = X_opt_obj * T_y; %yield at objective function optimum 
b_opt_b_std = sqrt(mse_obj * (X_opt_obj * innermat * X_opt_obj')); %objective function standard deviation logarithmic
b_opt_y_std = sqrt(mse_y * (X_opt_obj  * innermat * X_opt_obj')); %yield standard deviation logarithmic
b_opt_b_pm = tinv(0.99, length(b) - length(T_obj)) * b_opt_b_std; %objective function 99% confidence interval logarithmic
b_opt_y_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * b_opt_y_std; % yield 99% condifence interval logartihmic

%Yield maximum
y_opt_max = yield_opts(i_opt); % Get maximum yield 
X_opt_yield = lmb_optimization_cvals_to_X( cvals_yield_opt_max, dvals_opt_max, ...
                                     opt_variables, lin,removed_dvals );
y_opt_b_max = X_opt_yield * T_obj;
y_opt_y_max = y_opt_max;
y_opt_b_std = sqrt(mse_obj * (X_opt_yield * innermat * X_opt_yield')); %objective function standard deviation logarithmic
y_opt_y_std = sqrt(mse_y * (X_opt_yield  * innermat * X_opt_yield')); %yield standard deviation logarithmic
y_opt_b_pm = tinv(0.99, length(b) - length(T_obj)) * y_opt_b_std; %objective function 99% confidence interval logarithmic
y_opt_y_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_opt_y_std; % yield 99% condifence interval logartihmic


%Output prompt TON
str_obj2=['Estimated global objective:      ' num2str(b_opt_b_max) ' +\- ' num2str(b_opt_b_pm) ...
      ' (99% confidence)'];
output_prompt = push_message(output_prompt,str_obj2);   

str_obj3=['Estimated global TON:      ' sprintf('%.0f',(exp(b_opt_b_max))) ' [' sprintf('%.1f',exp(b_opt_b_max-b_opt_b_pm))...
    ' to ' sprintf('%.1f',exp(b_opt_b_max+b_opt_b_pm)) ']' ' (99% confidence)'];
output_prompt = push_message(output_prompt,str_obj3);  
%Could also output the yield at objective function optimum if necessary

%Output prompt Yield

str_y2=['Estimated global yield:    ' sprintf('%.2f',(exp(y_opt_y_max))*100) '% [' sprintf('%.2f',(exp(y_opt_y_max-y_opt_y_pm))*100)...
    '% to ' sprintf('%.2f',(exp(y_opt_max+y_opt_y_pm))*100) '%]' ' (99% confidence)'];
output_prompt = push_message(output_prompt,str_y2);
%Could also output the objective function value for yield optimum if necessary

%record to optimization state
opt_state_ret.best_obj_b_str = [str_obj1 '\n' str_obj2 '\n' str_obj3];
opt_state_ret.best_slug_y_str = [str_y1 '\n' str_y2];
opt_state_ret.best_obj_b = cwc_optimization_cdvals_to_slug(cvals_opt_max , dvals_opt_max, opt_variables ); %predicted objective function optimum
opt_state_ret.best_slug_y =  cwc_optimization_cdvals_to_slug( cvals_yield_opt_max, dvals_opt_max, opt_variables ); %predicted yield optimum    



% Fathom worst variables first
% Prediction lower bound
b_opt_lb = b_opt_max - b_opt_b_pm;
diff_array = b_opts - b_opt_lb;
[sorted_diff_array, index] = sort(diff_array);

fathomed = false; % initialize
check = false; % initialize


if counter_i > 0        
    for i = 1:length(b_opts)
        if sorted_diff_array(i) < 0
            str =['Ready to fathom out discrete variable set ' ...
                  num2str(dvals_combos(:, index(i))') ', estimated opt (' ...
                  num2str(b_opts(index(i))) ') < global opt 99% lb (' ...
                  num2str(b_opt_lb) ')'];
            output_prompt = push_message(output_prompt,str); 

            remove_dvals = dvals_combos(:, index(i)); %discrete variable combo that should be removed
            removed_dvals_new = [removed_dvals, remove_dvals]; %all discrete variable combos that would be removed

            [ all_slugs_new ] = lmb_dvals_remove( ... 
                all_slugs, opt_variables, remove_dvals); %remove experiments associated with discrete variable combo that should be removed
            [ opt_variables_new ] = lmb_update_opt_var( opt_variables, removed_dvals_new ); %remove values from discrete optimization values if all combinations have been removed 

            [ check ] = lmb_check_remove( all_slugs_new,opt_variables_new, buffer, lin, tol, removed_dvals_new);
%                 [ check ] = kwg_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol);

            if check
                removed_exp = length(all_slugs) - length(all_slugs_new);

                all_slugs = all_slugs_new;
%                     opt_variables = opt_variables_new;

                removed_dvals  = removed_dvals_new;
                opt_variables  = opt_variables_new;

                str = ['Fathoming out discrete variable set ' ...
                      num2str(remove_dvals')];
                output_prompt = push_message(output_prompt,str);   
                str = ['...removed ' num2str(removed_exp) ' experiments'];
                output_prompt = push_message(output_prompt,str); 

                fathomed = true;
            else
                if any(lmb_find_dval_combo(fathomed_dvals, remove_dvals)) == 0 %if combo it is not in queue already
                    fathomed_dvals = [fathomed_dvals, remove_dvals]; %add to combo to fathoming queue
                    str = ['Adding discrete variable set ' ...
                           num2str(dvals_combos(:, index(i))') ...
                           ' to the fathom queue'];
                    output_prompt = push_message(output_prompt,str); 
                    
                end %if
                continue  
            end %if

        end %if
    end %for

        if fathomed % need to recalculate T, W, etc.
        str=['Reset convergence timer, making progress!'];
        output_prompt = push_message(output_prompt,str);
        not_improving = -1; 
        opt_state_ret.counter_i = counter_i;
        opt_state_ret.not_improving = not_improving;
        opt_state_ret.prev_best_b = prev_best_b;
        opt_state_ret.fathomed_dvals = fathomed_dvals;
        opt_state_ret.removed_dvals = removed_dvals;
        opt_state_ret.opt_done = opt_done;
        opt_state_ret.opt_variables = opt_variables;
        return
    end

    str=['No variables to fathom'];
    output_prompt = push_message(output_prompt,str); 

     
else
    counter_i = counter_i + 1;
end %if




%% Determine if sufficient progress is being made
% Filter by completed slugs
completed_slugs = cwc_optimization_completed_slugs( all_slugs );
obj_values = cwc_list_property( completed_slugs, 'objective' );
yield_values = cwc_list_property( completed_slugs, 'yield' );

% Filter by yield criterion 
yield_crit = max(yield_values);
yield_index = find( cwc_list_property(completed_slugs, 'yield') >= ...
                    yield_criterion * yield_crit );
obj_yield_values = obj_values(yield_index);
best_b = max(obj_yield_values);

% Sign change
if prev_best_b < 0
    prev_best_b_correction = - prev_best_b;
else
    prev_best_b_correction = prev_best_b;
end %if

if ( (best_b - prev_best_b) / prev_best_b_correction ) <= percent_improve
    not_improving = not_improving + 1;

    str=[num2str(not_improving) ' iterations without ' ...
          num2str(100*percent_improve) '% exp. improvement or fathoming'];   
    output_prompt = push_message(output_prompt,str); 
      
      
    if not_improving > patience
        str=['Optimization done: Failed to make satisfactory progress for more than ' ...
              num2str(patience) ' slugs'];
        output_prompt = push_message(output_prompt,str);  
              
        opt_done = 1; %optimization is done
        
        opt_state_ret.counter_i = counter_i;
        opt_state_ret.not_improving = not_improving;
        opt_state_ret.prev_best_b = prev_best_b;
        opt_state_ret.fathomed_dvals = fathomed_dvals;
        opt_state_ret.removed_dvals = removed_dvals;
        opt_state_ret.opt_done = opt_done;
        opt_state_ret.opt_variables = opt_variables;
        opt_state_ret.iteration_counter = [iteration_counter  size(cwc_optimization_completed_slugs( all_slugs_old ),2)]; %only count completed slugs
        return; %leave function

    end
else
    str=['Objective function = ' num2str(best_b) ' >= ' num2str(prev_best_b)];
    output_prompt = push_message(output_prompt,str); 
    
    prev_best_b = best_b;
    not_improving = 0;
end

%% Get the next set of G-optimal experiments (for each dval set)
% Get G-optimal
[ cvals_opts, G_opts, dvals_opts ] = ...
    lmb_optimization_get_Gopt( opt_variables, lin, ...
                                   fathomed_dvals, removed_dvals,  ...
                                   X, T_obj, T_y, yield_criterion, b, ...
                                   log_yield_vals, completed_slugs );

%% Add those experiments to all_slugs
g_opt_slugs = []; %initialize

for i = 1:length(G_opts)
    cvals_opt = cvals_opts(:, i);
    dvals_opt = dvals_opts(:, i);
    str=['for dvals ' num2str(dvals_opt') ', proposed cvals ' num2str(cvals_opt')];
    output_prompt = push_message(output_prompt,str); 
    
    
    % Estimate uncertainty at G_opt
    X_next = lmb_optimization_cvals_to_X( cvals_opt, dvals_opt, opt_variables, lin,removed_dvals );
        
    innermat = inv(X' * W * X);
    b_next_std = sqrt(mse_obj * (1 + (X_next * innermat * X_next')));
    y_next_std = sqrt(mse_y * (1 + (X_next * innermat * X_next')));
    b_next_pm = tinv(0.99, length(b) - length(T_obj)) * b_next_std;
    y_next_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_next_std;

    b_next = X_next * T_obj;
    y_next = X_next * T_y;

    % Define new slug and simulate
    new_slug_vals = cwc_optimization_cdvals_to_slug( cvals_opt, dvals_opt, opt_variables );
    new_slug = all_slugs(1);
    for opt_var = opt_variables
        eval(['new_slug.' opt_var.label ' = new_slug_vals.' opt_var.label ';']);
    end
    % Set slug number
    
    new_slug.number = max(cwc_list_property(all_slugs_ret,'number'))+i;
    % Reset vals
    new_slug.injected_vol = 0;
    new_slug.current_vol = 0;
    new_slug.residence_time_actual = 0;
    new_slug.in_prep = 0;
    new_slug.in_system = 0;
    new_slug.injected = 0;
    new_slug.in_reactor = 0;
    new_slug.in_hplc = 0;
    new_slug.distance = 0;
    new_slug.distance_matched = 0;
    new_slug.inj_base = 0;
    new_slug.inj_quench = 0;
    new_slug.analysis_time = 0;
    new_slug.complete = 0;
    new_slug.yield = 0;
    new_slug.objective = 0;
    new_slug.hplc_data_path = '';    
    new_slug.istd_conc = 0;
    g_opt_slugs = [g_opt_slugs new_slug];

    % Report
    str=['----- NEXT EXPERIMENT:-----'];
    output_prompt = push_message(output_prompt,str);  
    
    str=['    res time:     ' num2str(new_slug.residence_time_goal)];
    output_prompt = push_message(output_prompt,str);  
    
    str=['    temp:         ' num2str(new_slug.temperature)];
    output_prompt = push_message(output_prompt,str);    
    
    str=['    reag 3:       ' num2str(new_slug.reagent_3)];

    output_prompt = push_message(output_prompt,str);%append output prompt cell 
    
    
    str=['    reag 3 conc:  ' num2str(new_slug.reagent_3_conc)];

    output_prompt = push_message(output_prompt,str);
   
    
    str=['    Predicted objective:      ' num2str(b_next) ' +\- ' num2str(b_next_pm) ...
          ' (99% confidence)'];
    output_prompt = push_message(output_prompt,str);     
    str=['    Predicted TON:      ' sprintf('%.0f',(exp(b_next))) ' [' sprintf('%.1f',exp(b_next-b_next_pm))...
        ' to ' sprintf('%.1f',exp(b_next+b_next_pm)) ']' ' (99% confidence)'];
    output_prompt = push_message(output_prompt,str);    
      
    str=['    Predicted yield:    ' sprintf('%.2f',(exp(y_next))*100) '% [' sprintf('%.2f',(exp(y_next-y_next_pm))*100)...
        '% to ' sprintf('%.2f',(exp(y_next+y_next_pm))*100) '%]' ' (99% confidence)'];
    output_prompt = push_message(output_prompt,str); 
    
    
    
    
end

 
% Randomize order of new g optimal slugs  

iteration_counter = [iteration_counter  size(cwc_optimization_completed_slugs( all_slugs_old ),2)]; %add size of all_slug (only completed slugs!)  to mark iteration
g_opt_slugs = g_opt_slugs(randperm(length(g_opt_slugs))); %randperm random permutations
g_opt_numbers  = cwc_list_property( g_opt_slugs, 'number' ); %resort slug number after randomizing order
g_opt_numbers = sort(g_opt_numbers);

for i = 1:length(g_opt_numbers)
    
    g_opt_slugs(i).number = g_opt_numbers(i);
    
end
all_slugs_ret = [all_slugs_ret g_opt_slugs];
  
%Load optimization parameters 
opt_state_ret.counter_i = counter_i;
opt_state_ret.not_improving = not_improving;
opt_state_ret.prev_best_b = prev_best_b;
opt_state_ret.fathomed_dvals = fathomed_dvals;
opt_state_ret.removed_dvals = removed_dvals;
opt_state_ret.opt_done = opt_done;
opt_state_ret.opt_variables = opt_variables;
opt_state_ret.iteration_counter = iteration_counter;


end