function [ pretty_header ] = cwc_prettify_header( header )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


switch header
    
    case 'number'
        pretty_header = 'Number';
    case 'reagent_1'
        pretty_header = 'Reagent 1 ID';
    case 'reagent_1_conc'
        pretty_header = 'Reagent 1 Conc. (M)';
    case 'reagent_2'
        pretty_header = 'Reagent 2 ID';
    case 'reagent_2_conc'
        pretty_header = 'Reagent 2 Conc. (M)';
    case 'reagent_3'
        pretty_header = 'Reagent 3 ID';
    case 'reagent_3_conc'
        pretty_header = 'Reagent 3 Conc. (M)';
    case 'reagent_4'
        pretty_header = 'Reagent 4 ID';
    case 'reagent_4_conc'
        pretty_header = 'Reagent 4 Conc. (M)';
    case 'reagent_5'
        pretty_header = 'Reagent 5 ID';
    case 'reagent_5_conc'
        pretty_header = 'Reagent 5 Conc. (M)';
    case 'makeup'
        pretty_header = 'Make-Up Solvent ID';
    case 'prepared_vol'
        pretty_header = 'Load Volume (uL)';
    case 'injected_vol'
        pretty_header = 'Injected Volume (uL)';
    case 'current_vol'
        pretty_header = 'Current Volume (uL)';
    case 'base_vol'
        pretty_header = 'Inlet Injection (uL)';
    case 'quench_vol'
        pretty_header = 'Outlet Injection (uL)';
    case 'temperature'
        pretty_header = 'Temperature (degC)';
    case 'residence_time_goal'
        pretty_header = 'Residence Time Target (s)';
    case 'multi_injections'
        pretty_header = 'Multiple Injection Definition';
    case 'multi_injected'
        pretty_header = 'Multiple Injections Complete?';
    case 'residence_time_actual';
        pretty_header = 'Residence Time Actual (s)';
    case 'istd_conc'
        pretty_header = 'Internal Standard Conc. (g/L)';
    case 'in_prep'
        pretty_header = 'In preparation?';
    case 'in_system'
        pretty_header = 'In the system?';
    case 'injected'
        pretty_header = 'Injected into system?';
    case 'in_reactor'
        pretty_header = 'In the reactor?';
    case 'in_hplc'
        pretty_header = 'In analysis?';
    case 'distance'
        pretty_header = 'Current Distance (uL)';
    case 'distance_matched'
        pretty_header = 'Last Matched Distance (uL)';
    case 'inj_base'
        pretty_header = 'Inlet Injection Complete?';
    case 'inj_quench'
        pretty_header = 'Outlet Injection Complete?';
    case 'analysis_time'
        pretty_header = 'Current Analysis Time (s)';
    case 'complete'
        pretty_header = 'Slug Completely Done?';
    case 'objective'
        pretty_header = 'Objective Function Value';
    case 'yield'
        pretty_header = 'Reaction Yield';
    case 'eln'
        pretty_header = 'ELN Experiment';
    case 'hplc_sampletime'
        pretty_header = 'HPLC Sampling Time (ms)';
    case 'conversion'
        pretty_header = 'Conversion';
    case 'yield_2'
        pretty_header = 'Side Product Yield';
    case 'yield_ov'
        pretty_header = 'Total Yield';
    case 'ee'
        pretty_header = 'Enantiomeric excess';
    case 'mb'
        pretty_header = 'Mass Balance';
    otherwise
        pretty_header = header;
end

end

