function [ reactor_slug ] = lmb_update_reactor_first_PD( reactor_slug, all_slugs, react_slug, v1, outlet_comp_factor, time)
%Updates reactor slug after the first PD detection
%   Input:
% reactor_slug: reactor slug object
% all_slugs: all slugs
% react_slug: index of reacting all slug object
% v1: oscillation flow rate
% outlet_comp_factor: compensation factor set for withdrawing at end of pass
% time: time of first PD detection
%   Output: reactor_slug

reactor_slug = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug );

%log oscillation data
reactor_slug.oscill_flow_rate(1,1) = v1;  

reactor_slug.compensation_factor(1,1) = outlet_comp_factor;

reactor_slug.time_initial_detection(1,1) = time;

end

