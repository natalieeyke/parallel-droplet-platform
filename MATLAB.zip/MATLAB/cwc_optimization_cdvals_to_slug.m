function [ slug ] = cwc_optimization_cdvals_to_slug( cvals, dvals, opt_vars )
% cwc_optimization_cdvals_to_slug converts a list of cvals and dvals
% (ordered identically to opt_vars) to a slug

slug = Slug();
cvals_i = 1;
dvals_i = 1;
for opt_var = opt_vars
    % What is the type? 
    if strcmp(opt_var.type, 'continuous') % continuous
        % Save value
        if strcmp(opt_var.label, 'residence_time_goal')
            slug.residence_time_actual = cvals(cvals_i);
            slug.residence_time_goal = cvals(cvals_i);
        else
            eval(['slug.' opt_var.label ' = cvals(cvals_i);']);
        end
        cvals_i = cvals_i + 1;

    else % discrete
        % Need to convert exp. condition to one-hot vector
        eval(['slug.' opt_var.label ' = dvals(dvals_i);']);
        dvals_i = dvals_i + 1;
    end
end