load('C:\Users\Admin\Desktop\Optimization20170303\optimization20170303_03-03-2017_15_03.mat')
%load('C:\Users\Admin\Desktop\2.8.2017.mat')
%data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\LMB_Suzuki 2017-03-03 13-32-41\002-NV-no Sample Name.D';
%data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\Autoimporttest\Suzuki FBP calibration 2016-12-30 13-00-14\021-63-120816-FBP-1.D';
%ana_slug =1;
%ana_slug=2;

[ret_time,area,conc,all_slugs,file_read_fail,slug_area_fail] = cwc_process_hplc_data(data_path,all_slugs,reagent_table,reagent_table_index,ana_slug);
% Mark slug as complete in slug_tracker
[all_slugs] = cwc_mark_slug_complete(all_slugs, ana_slug);

all_slugs(ana_slug).reagent_1_conc = 1;
all_slugs(ana_slug).reagent_3_conc = 1;

% Store objective function value
[all_slugs] = lmb_objective_suzuki(all_slugs, ana_slug,area);
why
%slug_tracker = slug_objective_suzuki(slug_tracker,reagent_table,reagent_table_index,ana_slug,area,conc);