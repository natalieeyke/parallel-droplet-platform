function [ reactor_slug ] = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug )
%Copies all fields from the reacting all_slug to the reactor_slug object
%   Input:
% reactor_slug: copy fields to this object
% all_slugs: copy fields from this object
% react_slug: index of reacting slug
%   Output:
%   reactor_slug


headers =  Slug_v2().fields;

for i=1:size(headers,1)
    
    eval([ 'reactor_slug.' headers{i,1} '=' 'all_slugs(react_slug).' headers{i,1} ';' ]);
end




end

