clear
clc

%%
%initialize
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20180430.xlsx';

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-02-2018_07-05_345min'; %630
autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-02-2018_17-46_360min - done'; %630
% autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-01-2018_18-09_30min'; 
load(autosave_path) 


%recalculate objective function values and yield
ana_path = 'C:\Users\Admin\Desktop\log\ana_path';
stamp = '20170524test.txt';
ana_path = [ana_path stamp]; %add date/time
inj_vol = 15; %15 �l
rho_tf = 800;
ana_time = 1;
warmup_time = 15;
time = 1;
[all_slugs,analyte_table,counter_yield_changes] =...
 lmb_reprocess_slugs(ana_path,all_slugs,reagent_table_path,ana_time...
,warmup_time);
reprocess_slugs_status = ['Reprocessed data @ ' sprintf('%0.1fs', time) '- yield changes:' sprintf('%i',counter_yield_changes)];

% Get objective function values
[ b ] = cwc_list_property( all_slugs, 'objective' );

% Get yield values 
[ yield_vals ] = cwc_list_property( all_slugs, 'yield' );
[ log_yield_vals ] = log( yield_vals );
 
%reset
all_slugs_old = all_slugs;
opt_state.opt_variables(1, 2).values = [6,7,9,11];
all_slugs = all_slugs(1:36);
opt_state.buffer =1; % on removal of experiments after fathoming
opt_state.counter_i = 1; % initialize
opt_state.not_improving = 0; % initialize
opt_state.fathomed_dvals = []; % initialize
opt_state.removed_dvals = []; % initialize
opt_state.prev_best_b =  -0.5051;
opt_state.iteration_counter = [1 28];

%%
%optimization


opt_done = 0;
update_optimization_prompt = 0;



while 1
    % Add the next round
    [ all_slugs, opt_state, output_prompt ] =  lmb_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);

     update_optimization_prompt = 1;

     
end

opt_done = opt_state.opt_done;


why