clear


load('C:\Users\Admin\Desktop\20170303')
all_slugs(1).in_prep=0;

catalyst.conc= 3*0.042;%in M


reagent_table(7,4)=   catalyst.conc *reagent_table(7,3);%in g/mol
reagent_table(7,5) = catalyst.conc; %M

[start_prep,prep_flag] = cwc_check_can_start_prep_v2(all_slugs,refill_hold, paused_queue);
start_prep=1;
if start_prep == 1
   [prep_slug,comp,all_slugs] = ...
            cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,reagent_table_index,inj_vol,rho_tf);
    comp
    if ~isempty(comp)
        invalid_concs = double(any(comp(1,:) < 0))
        if invalid_concs
            all_slugs(prep_slug).complete = -1;
            temp_num = all_slugs(prep_slug).number;
            prep_slug = 0;
            prep_flag = ['Slug ' num2str(temp_num) ' has an invalid composition!'];
        else
            prep_flag = ['Preparing slug ' num2str(all_slugs(prep_slug).number)];
        end
    end

else
   prep_slug = 0;
   comp = [ ];
end