clc
clear
path = 'C:\Users\Admin\Documents\Optimization\Optimization 20171003\_10-04-2017_22-58_420min.mat';
load(path);

all_slugs=all_slugs(1:74);

  [ all_slugs, opt_state, output_prompt ] = ...
        cwc_kwg_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);