function [ opt_variables_new ] = lmb_update_opt_var( opt_variables, removed_dvals )
%Updates discrete variable choices to account for removed options
%  opt_variables: all optimization variables
%  removed_dvals: matrix with removed discrete variable combinations (N_discrete variables x N_removed_combos)

dvals_combos = cwc_optimization_get_dvals_combos( opt_variables, removed_dvals );


opt_variables_new = opt_variables;
for j = 1:length(opt_variables)
    if strcmp(opt_variables(j).type, 'discrete')
                
        opt_variables_new(j).values = [];%reset values for new discrete variable
        
        for i = 1:length(opt_variables(j).values) %for every value
            
        
         if sum (sum ( dvals_combos == opt_variables(j).values(i))) ~= 0 %if value appears in valid combinations of non-removed discrete variables
        
            opt_variables_new(j).values = [opt_variables_new(j).values , opt_variables(j).values(i)]; %copy value to new opt_variables, else: value gets dropped because all combinations with it have been removed
            
         else
             disp(sprintf('Dropping value %i from discrete variable %i',opt_variables(j).values(i) ,j))
         end
        
    
        end
    
    end
end %for

end

