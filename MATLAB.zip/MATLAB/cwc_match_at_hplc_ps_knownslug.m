function [all_slugs, lcbusy] = cwc_match_at_hplc_ps_knownslug(all_slugs, ps_dist, sys_slug)
% this function finds what kind of slug was detected at hplc phase sensor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               rinse_slugs is list of rinse slugs
%               ps_dist is distance to hplc phase sensor
%               dist_tol is the tolerance (uL) for matching
%               
% Outputs:
%               all_slugs is the updated slug list
%               inj_slug is the INDEX of slug in the sample loop
%                     0 if not a reacting slug
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lcbusy = 0;
all_slugs(sys_slug).distance_matched = ps_dist;

% Check if quench was injected
if all_slugs(sys_slug).inj_quench == 0
    all_slugs(sys_slug).inj_quench = -1;
    all_slugs(sys_slug).in_reactor = 0;
end

% Check if HPLC is busy
hplc_slug = find(cwc_list_property(all_slugs, 'in_hplc') == 1, 1, 'first');
if hplc_slug
    lcbusy = 1;
    all_slugs(sys_slug).complete = -1;
end

end