clear
clc
A  = [1,2,3];
B  = [4,5,6];
C = [7,8,9];

all_discrete_variable_combos = combvec(A,B,C);

% all_discrete_variable_combos = combvec(all_discrete_variable_values{1,:});

%create offset vector
X(:,1)= ones(size(A,2)*size(B,2),1);



        