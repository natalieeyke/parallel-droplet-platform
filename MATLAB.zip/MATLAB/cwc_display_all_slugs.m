function [headers, values] = cwc_display_all_slugs(all_slugs)
% This function prints all_slugs nicely so Labview can import

    function v = val_to_rep(v)
        if isnumeric(v)
            v = num2str(v);
        elseif iscell(v)
            v = strjoin(cellstr(v), '; ');
        else
            v = mat2str(v);
        end 
    end

if isempty(all_slugs)
    return
end

fields = fieldnames(all_slugs(1));
headers = {};
values = '';
for j = 1:length(fields)
    
    if strcmp(fields{j},'hplc_data_path')~=1  %don't display hplc data path
        headers{j} = cwc_prettify_header(fields{j});    
            for i = 1:length(all_slugs)    
                values = [values sprintf('%10s\t', val_to_rep(all_slugs(i).(fields{j})))];
            end
            values = [values '\n'];
        
    end
    
end

end