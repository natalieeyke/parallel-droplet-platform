function [ check ] = lmb_check_remove( all_slugs, opt_variables, buffer, lin, tol , removed_dvals_new)
% Checks if we can remove the discrete variable's experiments and 
% parameters based on potential rank deficiency issues or matrix
% computational errors.
% lmb: adapted for multiple discrete variables
% removed_dvals_new vector of removed and to fathom discrete variable
% combinations

if lin
    [ X_proposed ] = lmb_optimization_slugs_to_linmat( ... 
        cwc_optimization_completed_slugs(all_slugs), opt_variables,removed_dvals_new );
else
    [ X_proposed ] = lmb_optimization_slugs_to_quadmat( ...
        cwc_optimization_completed_slugs(all_slugs), opt_variables, removed_dvals_new );
end

if ( length(all_slugs) > size(X_proposed, 2) + buffer ) && ...
        ( rank(X_proposed, tol) >= size(X_proposed, 2) )
    
    % Get weights
    [ W_unnorm ] = cwc_optimization_slugs_to_weights( cwc_optimization_completed_slugs(all_slugs) );
    [ W_proposed ] = W_unnorm * length(diag(W_unnorm)) / sum(diag(W_unnorm)); % normalized so average == 1
    
    innermat_proposed = inv(X_proposed' * W_proposed * X_proposed);
    
    if rank(innermat_proposed, tol) >= size(X_proposed, 2)
        check = true;
        return
    end
    
    check = false;   
  
   
else
    check = false;
end %if

end
        