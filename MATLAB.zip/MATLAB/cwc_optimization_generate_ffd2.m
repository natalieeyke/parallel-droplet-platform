function [ all_slugs ] = cwc_optimization_generate_ffd2( all_slugs, opt_variables, FFD_type, lin, N_extra )
% cwc_optimization_generate_ffd generates a fractional factorial design
% based on the various variables that are being optimized

% NOTE: all_slugs must be defined so that the first slug corresponds to
% the default/fixed values of all variables not found in the optimization
% *before* that slug has been prepared (i.e., right after parsing)

% Parameter defaults: QUADRATIC AND N_extra = 3
if nargin < 5
    lin = false; % whether to use linear or quadratic response
    N_extra = 3; % buffer used in D-opt design; num experiments - num params
end

%% Prepare
% Initialize
if isempty(all_slugs)
    error('First slug must be defined (with all default/fixed values)')
end
all_slugs = all_slugs(1);

% Read conditions of optimization
num_opt_variables = length(opt_variables);

%% Generate design
switch FFD_type
    
       
        
    case 'd_opt' % CURRENT MODEL
        slug = all_slugs; % template slug
        all_slugs = []; % initialize
        
        % Divide up opt_variables
        continuous = cellfun(@(x) strcmp(x, 'continuous'), {opt_variables.type});
        opt_variables_continuous = opt_variables(continuous);
        
        discrete = cellfun(@(x) strcmp(x, 'discrete'), {opt_variables.type});
        opt_variables_discrete = opt_variables(discrete);
        
        N_cv = length(opt_variables_continuous);
        N_dv_combos = prod(cellfun(@(x) length(x), {opt_variables_discrete.values})); %prod() Product of array elements
        
        if lin
            num_params = length(lmb_optimization_slugs_to_linmat_trunc(slug, opt_variables));
        else
            num_params = length(cwc_optimization_slugs_to_quadmat(slug, opt_variables));%constructs vector with indepentent variables of slug
        end
        
        % Create list of slugs for fixed dv set
        N = 2; % # of initial experimental conditions, must be > 1
        ffd = fullfact((N+1) * ones(N_cv, 1)); % many leveled factorial design, all possible combination of N_cv factors with N+1 factor levels
        all_slugs = repmat(slug, 1, size(ffd, 1)); %create slug with number of possible combinations
        
        % Assign continuous vars
        for i = 1:length(opt_variables_continuous);
            vals = opt_variables_continuous(i).min + (0:N)/N * ... %N even spaced intervalls of possible values
                  (opt_variables_continuous(i).max - ...
                   opt_variables_continuous(i).min);
               
            label = opt_variables_continuous(i).label;
            is_residence_time = strcmp(label, 'residence_time_goal');
            
            for j = 1:length(all_slugs)
                eval(['all_slugs(j).' label ' = vals(ffd(j, i));']); %copy experimental setting to slug property for continuous variable
                if is_residence_time
                    all_slugs(j).residence_time_actual = vals(ffd(j, i));
                end
            end
        end
        
        % Assign all discrete values
        all_slugs = repmat(all_slugs, 1, N_dv_combos); %all possible combinations of number of cv x cv settings x dv
        X_0  = lmb_optimization_slugs_to_linmat_trunc(all_slugs, opt_variables);
        m = 1; % initialize counter for slugs
        
        %generate discrete variable combinations
        
        for i=1:length(opt_variables_discrete)
            all_discrete_variable_values{i} = opt_variables_discrete(i).values;
        end
        all_discrete_variable_combos = (combvec(all_discrete_variable_values{1,:}))';
        
        for i = 1:size(all_discrete_variable_combos,1) %for every discrete variable combination set
            
            for k = 1:size(ffd, 1)                
                for j = 1:length(opt_variables_discrete)                    
                    eval(['all_slugs(m).' opt_variables_discrete(j).label ...
                          ' = all_discrete_variable_combos(i,j);']);  

                end              
                m = m+1;   % increment counter                           
            end
            
                        
        end        
        % Choose the best ones
        if lin
            X = lmb_optimization_slugs_to_linmat_trunc(all_slugs, opt_variables);
%             X = cwc_optimization_slugs_to_linmat(all_slugs, opt_variables);
        else
            X = cwc_optimization_slugs_to_quadmat(all_slugs, opt_variables); %X is the matrix of the independent variables of the model
        end
        disp(sprintf('Columns of X: %i',size(X,2)))
        disp(sprintf('Rank of X: %i',rank(X)))
        
        disp(['generated ' num2str(size(X, 1)) ' options...'])
        % maxiter doesn't appear to affect N_exp needed or accuracy
        R = candexch(X, num_params + N_extra, 'display', 'on', 'maxiter', 100,'tries',100); %candexch: D-optimal design from candidate set using row exchanges, number of experiments: num_params + N_extra
        disp(['chose best ' num2str(length(R)) ' options'])
        all_slugs = all_slugs(R);
        
    otherwise
        error('Cannot create d_optimal design right now')
end

% Randomize order
all_slugs = all_slugs(randperm(length(all_slugs))); %randperm random permutations

%% Finish
% Change slug_nums to be unique, reset residence time
for i = 1:length(all_slugs)
    all_slugs(i).residence_time_actual = 0; 
    all_slugs(i).number = i;
end

end