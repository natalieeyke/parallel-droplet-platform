function [ property_list ] = cwc_list_property(all_slugs, property)
% Finds the property of each entry in 'all_slugs' and returns as list

if isempty(all_slugs)
    property_list = [];
    return
end

property_list = zeros(length(all_slugs), length(eval(['all_slugs(1).' property])));
for i = 1:length(all_slugs)
    eval(['property_list(i, :) = all_slugs(i).' property ';']);
end

end