function [ X ] = cwc_optimization_cvals_to_X( cvals, dvals, opt_vars, lin )
% cwc_optimization_cvals_to_X converts a list of continuous variable values
% (in order of opt_vars) to the scaled experimental condition vector, X,
% also using discrete values dvals (in order of opt_vars, again).

slug = cwc_optimization_cdvals_to_slug(cvals, dvals, opt_vars);
if lin
    [ X ] = cwc_optimization_slugs_to_linmat( [slug], opt_vars );
else
    [ X ] = cwc_optimization_slugs_to_quadmat( [slug], opt_vars );
end

end