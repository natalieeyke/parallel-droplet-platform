data = load('C:\Users\Admin\Documents\Optimization\Optimization 20170323\crash_all_slugs');


all_slugs = data.all_slugs;
[slug_headers,slug_values]=cwc_display_all_slugs(all_slugs);
num_headers = length(slug_headers);