function [ cvals_opts, b_opts, dvals_combos ] = ...
    lmb_optimization_get_Gopt( opt_vars, lin, fathomed_dvals, ...
                                   removed_dvals, X, T, T2, yield_criterion, ...
                                   obj_vals, log_yield_vals, completed_slugs )
% cwc_kwg_optimization_get_Gopt finds the optimal conditions to minimize 
% the variance in the predicted optimum objective function RS and predicted
% maximum yield RS
% lmb: adapted for multiple discrete variables

cvals_0 = [];%center points of continuous variables
lb = []; %lower boundary
ub = []; %upper boundary
for opt_var = opt_vars
    if strcmp(opt_var.type, 'continuous') % continuous
        cvals_0 = [cvals_0; (opt_var.min + opt_var.max) / 2]; % def.
        lb = [lb; opt_var.min];
        ub = [ub; opt_var.max];
    end
end

fr_dvals = [fathomed_dvals, removed_dvals];%fathom, removed discrete variables

% Initialize
dvals_combos = cwc_optimization_get_dvals_combos( opt_vars, fr_dvals );
cvals_opts = zeros(length(cvals_0), size(dvals_combos, 2));
b_opts = zeros(1, size(dvals_combos, 2)); 
cvals_y_opts = zeros(length(cvals_0), size(dvals_combos,2));
yield_opts = zeros(1, size(dvals_combos,2));

% Estimate maximum yield for each discrete variable value
for i = 1:size(dvals_combos,2)
    dvals = dvals_combos(:, i);
    
    X_opt = @(cvals) lmb_optimization_cvals_to_X(cvals, dvals, opt_vars, lin , removed_dvals);
    obj_fun_yield = @(cvals) - dot(X_opt(cvals), T2); %Dot product
    
    tol = 1e-20; % default
    A = []; b = []; Aeq = []; beq = []; nonlcon = [];
    options = optimoptions('fmincon', 'TolFun', tol, 'TolX', tol, ...
                           'TolCon', tol, 'Display', 'None');
    
    [cvals_opt, y_opt] = fmincon(obj_fun_yield, cvals_0, A, b, Aeq, beq, ...
                         lb, ub, nonlcon, options);%Find minimum of constrained nonlinear multivariable function
    
    yield_opts(i) = - y_opt;
    cvals_y_opts(:, i) = cvals_opt;
end %for

max_yield = max(yield_opts);

   % Nonlinear constraint on yield
    function [c, ceq] =  nonlcon_general(cvals, X_opt_func) 
        c =  - dot( X_opt_func(cvals), T2) + ( log(yield_criterion) + max_yield );
        ceq = [];
    end


disp(['optimizing variance at predicted opt. for ' num2str(size(dvals_combos, 2)) ' dval combos'])
for i = 1:size(dvals_combos, 2)
    dvals = dvals_combos(:, i);    

    tol = 1e-20; % default
    A = []; b = []; Aeq = []; beq = [];
    options = optimoptions('fmincon', 'TolFun', tol, 'TolX', tol, ...
                           'TolCon', tol, 'Display', 'None');
    
    % Find predicted optimum yield for this dval
    X_opt = @(cvals) lmb_optimization_cvals_to_X(cvals, dvals, opt_vars, lin,removed_dvals);
    obj_fun = @(cvals) - dot(X_opt(cvals), T);
    
 
    
    nonlcon = @(cvals) nonlcon_general(cvals, X_opt);
    
    [cvals_opt, ~] = fmincon(obj_fun, cvals_y_opts(:,i), A, b, Aeq, beq, ...
                                 lb, ub, nonlcon, options);
                       
    % Convert to an X vector for obj fun optimization (reduce variation)
    X_opt_obj = lmb_optimization_cvals_to_X( cvals_opt, dvals, opt_vars, lin,removed_dvals );
    
    % Convert to an X vector for yield optimization (reduce variation)
    X_opt_y = lmb_optimization_cvals_to_X( cvals_y_opts(:,i), dvals, opt_vars, lin,removed_dvals);
    
    % Find G-optimal experiment for this dval
    obj_fun2 = @(cvals) lmb_optimization_cvals_to_Vbopt( cvals, dvals, ...
                                                             opt_vars, lin, ...
                                                             X, T, T2, X_opt_obj, ...
                                                             X_opt_y, obj_vals, ...
                                                             log_yield_vals, ...
                                                             completed_slugs,removed_dvals );%value is proportional to model error at this experimental setting
    
    % Compute maximum
    [cvals_max_opt, b_opt] = fmincon(obj_fun2, cvals_opt, A, b, Aeq, beq, ...
                                     lb, ub, nonlcon, options);
        
    % Update optimum cvals and b for this dval set
    cvals_opts(:, i) = cvals_max_opt;
    b_opts(i) = - b_opt;
end
end