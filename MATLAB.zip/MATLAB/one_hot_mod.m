function [ one_hot_trunc ] = one_hot_mod(pool, choice)
 %creates truncated one hot vector for use with multiple
            %discrete variables
            %example: 
            % discrete variable pool: [12,16,30] %reagent IDs
            % choice: [16]
            % one hot vector: [0 1 0] 
            % 
            % truncated one hot vector: 
            % - assume effect of first element in discrete variable pool is
            % captured in offset
            % - indicate shift to other elements by one hot vector
            % discrete variable pool: [12,16,30]
            % choice: [12]
            % truncated one hot vector: [0 0]
            
            % discrete variable pool: [12,16,30]
            % choice: [16]
            % truncated one hot vector: [1 0]            

            % discrete variable pool: [12,16,30]
            % choice: [30]
            % truncated one hot vector: [0 1] 

n_output_digits = (size(pool,2)-1); %number of digits for truncated one-hot vector
one_hot_trunc = zeros(1,n_output_digits );
    
    
    for i = 1:n_output_digits
        
        choice_index = find(pool==choice);
        
        if ~isempty(choice_index) %make sure choice actually exists in pool
                      
            for j = 1:size(pool,2)

                if i + 1 == choice_index;

                    one_hot_trunc(1,i) = 1;

                end %end if i+1

            end %end for j
            
        end %end isempty        
        
    end  %end for i
    
end %end function

