function [base_inj_vol] = cwc_get_base_inj_vol_v2(all_slugs, base_inj_slug, step)
% get volume to inject into system
% v2 adds the third argument (injection step)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% October 26, 2015
%
% Inputs:
%               all_slugs is the list of slug objects
%               base_inj_slug is the INDEX assigned to the slug
%               step is the reaction step (index) of injection
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Default step == 1
if nargin < 3
    step = 1;
end

% Get base volume
base_inj_vol = all_slugs(base_inj_slug).base_vol(step);

end