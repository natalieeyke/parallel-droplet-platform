function [react_slug, v1_new, num_passes, upcoming_step, base_inj_vol, last_step] = ...
         cwc_get_next_slug_in_reactor_v3(all_slugs, v1_normal, v1_osc, oscillatory_vol, outlet_to_quench_vol, T_set)
% finds the next slug to enter the reactor (must have had base injected)
% v2 allows multistep chemistry
% v3 allows using a reaction time of "-3" to mean 3 passes at max velocity

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% October 27, 2015
%
% Inputs:
%               all_slugs is the list of slugs
%               v1_normal is  the flow rate upon exit
%               v1_osc is the oscillatory flow rate (max)
%               oscillatory_vol is the vol between photodetectors
%               outlet_to_quench_vol is the fixed distance to quench
%               T_set is the reactor temperature in C
%               
% Outputs:
%               react_slug is the INDEX of the identified slug
%               v1_new is the flow rate for oscillation
%               num_passes is the number of cycles (0 is straight through,
%                   2 is one forward-backward-forward)
%               upcoming_step is the index of the reaction step for the
%                   current slug
%               base_inj_vol is the volume (uL) to inject right before the
%                   next reaction step (to prep injection)
%               last_step is a 1 or 0 depending on if this next step is the
%                   last one
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% If T_set < 20, then chances are we are doing an unheated photoredox rxn
% ambient temperature ~23 degC
if T_set < 20
    T_set = 23;
end

% Find injected slug that is not COMPLETELY done reacting (its last step)
react_slug = find(and(cwc_list_property(all_slugs, 'residence_time_actual(end)') == 0, ...
                      cwc_list_property(all_slugs, 'injected') == 1), 1, 'first');

% If no slug, return 0s
if isempty(react_slug)
    react_slug = 0;
    v1_new = 0;
    num_passes = 0;
    upcoming_step = 0;
    base_inj_vol = 0;
    last_step = 0;
    return
end

% Figure out what step we're about to start
upcoming_step = find(all_slugs(react_slug).residence_time_actual == 0, 1, 'first');

% Get target time
residence_time_goal = all_slugs(react_slug).residence_time_goal(upcoming_step);

% Get base volume to prepare injection
base_inj_vol = all_slugs(react_slug).base_vol(upcoming_step);
    
%% valid residence time in seconds
if residence_time_goal > 0 

    % Get time from outlet to quench (fixed)
    min_time = outlet_to_quench_vol / v1_normal * 60;

    % Get new oscillatory goal
    oscillatory_time_goal = residence_time_goal - min_time;
    oscillatory_volume_ideal = oscillatory_time_goal / 60 * v1_osc;

    % Number of reactor volumes
    num_reactor_vols = oscillatory_volume_ideal / oscillatory_vol;

    % Direction at end depends on if this is the last step
    if upcoming_step == length(all_slugs(react_slug).residence_time_goal)
        last_step = 1;
        % Need to round up to the nearest odd number
        round_reactor_vols = floor((num_reactor_vols - 1) / 2) * 2 + 1;
        if round_reactor_vols < 1
            num_passes = 1;
            v1_new = v1_osc;
            return
        end
        num_passes = round_reactor_vols;

    else
        % Need to round up to the nearest even number
        last_step = 0;
        round_reactor_vols = floor(num_reactor_vols / 2) * 2;
        if round_reactor_vols < 2
            num_passes = 2;
            v1_new = v1_osc;
            return
        end
        num_passes = round_reactor_vols;
    end

    % Find exact flow rate now
    v1_new = round_reactor_vols * oscillatory_vol / oscillatory_time_goal * 60;

    % Correct for ideal gas law expansion
    v1_new = v1_new / (T_set + 273.15) * 293.15;

%% Using a negative residence time to indicate # of passes
else 
    num_reactor_vols = - residence_time_goal;
    
    % Round as appropriate
    if upcoming_step == length(all_slugs(react_slug).residence_time_goal)
        last_step = 1;
        % Need to round up to the nearest odd number
        round_reactor_vols = floor((num_reactor_vols - 1) / 2) * 2 + 1;
        num_passes = round_reactor_vols;
        if round_reactor_vols < 1
            num_passes = 1;
        end
    else
        last_step = 0;
        % Need to round up to the nearest even number
        round_reactor_vols = floor(num_reactor_vols / 2) * 2;
        num_passes = round_reactor_vols;
        if round_reactor_vols < 2
            num_passes = 2;
        end
    end
    
    % When defining reaction time with number of passes, always move at
    % the maximum allowable carrier velocity
    v1_new = v1_osc;
    
    % Correct for ideal gas law expansion
    v1_new = v1_new / (T_set + 273.15) * 293.15;
     
end

end