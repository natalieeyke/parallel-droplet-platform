function [sample_vol,rack_id,place_id,sample_id,first_sample,last_sample] = slug_load(load_num,comp)
%SLUG_LOAD instructs liquid handler of volume to aspirate and loaction of
%sample well

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% Inputs:
%               load_num is the iteration of sample loading
%               comp is the composition of the next slug to be prepared
%               
% Outputs:
%               sample_vol is the volume to aspirate
%               rack_id is the type of sample rack (200, 207, 209)
%               place_id is the placement of the sample rack (1 or 2)
%               sample_id is the sample well number on the rack
%               first_sample is 1 if this is the first injection into the
%               sample loop, 0 otherwise
%               last_sample is 1 if this is the last injection into the
%               sample loop, 0 otherwise
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if sum(comp(2:end-1,1)) ~= 0
    
    % Volume
    sample_vol = comp(load_num + 1,1);
    
    % Get rack_id, place_id, and sample_id
    rack_id = comp(load_num + 1,2);
    place_id = comp(load_num + 1,3);
    sample_id = comp(load_num + 1,4);
    
    % Determine if this is first or last sample to load
    if sample_vol > 0
        if load_num == 0 || sum(comp(1:load_num,1)) == 0
            first_sample = 1;
        else
            first_sample = 0;    
        end
    else
        first_sample = 0;
    end
    
    if sample_vol > 0
        if load_num == size(comp,1) - 1 || sum(comp(load_num + 2:end,1)) == 0
            last_sample = 1;
        else
            last_sample = 0;
        end
    else
        last_sample = 0;
    end  

else
    
    % Only makeup
    if load_num == 0
        
        first_sample = 1;
        last_sample = 1;
        
        % Volume
        sample_vol = comp(1,1) + comp(end,1);
    
        % Get rack_id, place_id, and sample_id
        rack_id = comp(1,2);
        place_id = comp(1,3);
        sample_id = comp(1,4);
        
    else
        
        first_sample = 0;
        last_sample = 0;
        
        % Volume
        sample_vol = 0;
    
        % Get rack_id, place_id, and sample_id
        rack_id = comp(load_num + 1,2);
        place_id = comp(load_num + 1,3);
        sample_id = comp(load_num + 1,4);
        
    end

end
    
end