clear
clc

%
%inputs
reagent_table_path = 'C:\Users\Lorenz\LRZ Sync+Share\Master Thesis\Labview interface\Test scripts\cwc_process_hplc_data_suzuki\System 20170523\Input\REAGENT_TABLE_20170328_new.xlsx';
reagent_table_path_old = 'C:\Users\Lorenz\LRZ Sync+Share\Master Thesis\Labview interface\Test scripts\cwc_process_hplc_data_suzuki\System 20170523\Input\REAGENT_TABLE.xlsx';

data_path = 'C:\Users\Lorenz\LRZ Sync+Share\Master Thesis\Labview interface\Test scripts\cwc_process_hplc_data_suzuki\System 20170523\LMB_Suzuki 2017-03-28 18-03-19\001-NV-no Sample Name.D';
optimization_on = 1;

ana_path = 'C:\Users\Lorenz\LRZ Sync+Share\Master Thesis\Labview interface\Test scripts\cwc_process_hplc_data_suzuki\System 20170523\log\slug_path';
stamp = '20170524.txt';
ana_path = [ana_path stamp]; %add date/time


% reagent_table lists all reagents in the system
[reagent_table_old,reagent_table_index] = load_reagent_table(reagent_table_path_old);
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

% slug_tracker is the matrix of slug information
% index identifies the information contained in each column of slug_tracker 
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
rinse_slugs = [];


inj_vol = 15; %15 �l
rho_tf = 800;

[~,~,all_slugs] = cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,inj_vol,rho_tf);

ana_slug = 1;    
reprocessing = 0;
all_slugs.analysis_time = 30;
[all_slugs,data_processing_exit_flag] = lmb_process_hplc_data_suzuki(data_path,ana_path,all_slugs,analyte_table,ana_slug,optimization_on,reprocessing);
ana_time = 15;
warmup_time = 15;
[all_slugs,analyte_table,counter_yield_changes] = lmb_reprocess_slugs(ana_path,all_slugs,reagent_table_path,ana_time);



why

