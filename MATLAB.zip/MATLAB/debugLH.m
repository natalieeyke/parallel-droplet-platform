clc
clear

load('C:\Users\Admin\Desktop\comp20170614.mat');
load_num =0;

for i=1:size(comp,1)+10
[sample_vol,rack_id,place_id,sample_id,first_sample,last_sample] = slug_load(load_num,comp);
total_vol = sum(comp(:,1));
load_num = load_num+1;
end
