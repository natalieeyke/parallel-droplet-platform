function [T_set] = cwc_get_temperature_set_v2(all_slugs)
% finds the correct temperature setpoint
% v2 allows for multistep reactions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% October 26, 2015
%
% Inputs:
%               all_slugs is the list of slugs
% Outputs:
%               T_set is the reactor set point temperature (in deg C)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set default
T_set = 0;

% Find the slug index of the last slug to exit the reactor
slug_num = find(cwc_list_property(all_slugs, 'injected') == 1 & ...
                cwc_list_property(all_slugs, 'in_reactor') == 0 & ...
                cwc_list_property(all_slugs, 'residence_time_actual(1)') > 0, 1, 'last');

% Nothing found -> still need the first slug temperature
if isempty(slug_num)
    if length(all_slugs) >= 1
        if all_slugs(1).in_reactor == 0
            % need first stage temperature
            T_set = all_slugs(1).temperature(1);
        else
            % need later stage temperature (in_reactor == # current step)
            T_set = all_slugs(1).temperature(all_slugs(1).in_reactor);
        end
    else
        T_set = 0;
    end
    
% If there is a next slug -> that slug
elseif (slug_num + 1 <= length(all_slugs))
    if all_slugs(slug_num + 1).in_reactor == 0 % need first stage temperature
        T_set = all_slugs(slug_num + 1).temperature(1);
    else % need later stage temperature
        % figure out the most recent base injection
        latest_base_inj = find(all_slugs(slug_num + 1).inj_base == 1, 1, 'last');
        T_set = all_slugs(slug_num + 1).temperature(latest_base_inj);
    end
    
% Done with slugs -> start cooling down
else
    T_set = 0; % let cool down
end

end