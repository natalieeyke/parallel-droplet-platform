%function [prev_exp,prev_result,N_prev] = TS_read_results_dragonfly(data_path_prev_results)

data_path_prev_results = 'C:\Users\Parallel Oscillator\Documents\Parallel LabVIEW\Input\Results_Continue.xlsx'
M = readmatrix(data_path_prev_results)

N_prev = size(M,1);
prev_exp = M(:,1:4);
results = M(:,5)';


%end