function [rinse_cleared,inject_flag,abort] = ...
    lmb_check_rinse_slugs_cleared(all_slugs, rinse_slugs)
% determines if we're ready to inject a slug that's waiting in the needle

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 5, 2012
% CWC
% June 17, 2015
% LMB 
% July 10, 2018
% split up cwc_check_can_inject_now into two functions so carrier syringe
% slows down while waiting for reactor to cool down
% 1. check if rinse slug have cleared: lmb_check_rinse_slugs_cleared
% 2. check if temperature is reached and other requirements: lmb_check_can_inject_now
%
% Inputs:
%             
% Outputs:
%               rinse_cleared is 1 if  all rinse slugs have been cleared, 0 otherwise
%               inject_flag denotes current status 
%               abort cancels slug injection if 1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set defaults
rinse_cleared = 0;
inject_flag = 'Default';
abort = 0;
    
% Find slug in prep which has not been injected into system
prep_slug = find(cwc_list_property(all_slugs, 'in_prep') - ...
                 cwc_list_property(all_slugs, 'injected') == 1, 1, 'first');

if isempty(prep_slug)
    rinse_cleared = 0;
    inject_flag = 'Couldnt get prep slug';
    abort = 0;
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check for slugs in system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if any(cwc_list_property(all_slugs, 'in_system') == 1)
    rinse_cleared = 0;
    inject_flag = 'Wait for slug to finish';
    return
end

if any(cwc_list_property(rinse_slugs, 'complete') == 0)
    rinse_cleared = 0;
    inject_flag = 'Wait for rinse slugs to finish';
    return
end
 


% If all requirements are met, continue by checking other requirements
rinse_cleared = 1;
inject_flag = 'Rinse complete: Wait for Temp.';

end