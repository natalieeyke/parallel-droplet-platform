function [all_slugs] = cwc_mark_slug_injected_hplc(all_slugs, inj_slug)
% marks a slug as being injected into hplc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs list of slugs
%               inj_slug is the INDEX assigned to the injected slug
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_slugs(inj_slug).in_system = 0;
all_slugs(inj_slug).in_hplc = 1;

end