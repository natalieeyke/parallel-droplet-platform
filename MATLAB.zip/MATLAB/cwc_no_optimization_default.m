function [re_optimization_state ] = cwc_no_optimization_default()
%sets default values for optimization state object if running experiments
%from sequence


    re_optimization_state = OptState;
    re_optimization_state.lin = false; % linear or quadratic
    re_optimization_state.percent_improve = 0.01; % range = [0,1]
    re_optimization_state.N_extra = 3; %standard = 3 range = [0,Inf]
    re_optimization_state.yield_criterion = 1; % range = [0.001,1]
    re_optimization_state.tol = 0.002; % rank tolerance
    % re_optimization_state.patience = 3; %standard value = 3; run patience experiments before giving up
    re_optimization_state.patience = 12; % run 4 experiments before giving up
    re_optimization_state.buffer = 1; % on removal of experiments after fathoming
    re_optimization_state.counter_i = 0; % initialize
    re_optimization_state.not_improving = 0; % initialize
    re_optimization_state.prev_best_b = -Inf; % initialize
    re_optimization_state.fathomed_dvals = []; % initialize
    re_optimization_state.removed_dvals = []; % initialize
    re_optimization_state.opt_done = 1; % set to 
    re_optimization_state.opt_variables = OptVar(); %generic empty optimization variable
    re_optimization_state.FFD_type    = 'd_opt';





end