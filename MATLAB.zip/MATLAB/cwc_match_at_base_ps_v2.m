function [all_slugs] = cwc_match_at_base_ps_v2(all_slugs, ps_dist, this_slug)
% update distance_matched for the online injection slug
% v2 allows for multi-step reactions, can't match rinse slugs
% (must know which slug is expected)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% October 27, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               ps_dist is distance to hplc phase sensor
%               this_slug is index of the slug expected at the sensor
%               
% Outputs:
%               all_slugs is the updated slug list
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Update slug
all_slugs(this_slug).distance_matched = ps_dist;

end