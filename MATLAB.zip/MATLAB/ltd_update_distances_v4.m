function [all_slugs, rinse_slugs] = ...
    ltd_update_distances_v4(all_slugs, rinse_slugs, time_prior, time, v1)
% updates distances of slugs and time in reactor
% v2 allows multi-step reactions
% v3 moved updating of rinse slug status to lmb_get_rinse_status in external
% v4 does not update distances of slugs during oscillation
% loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
% LMB
% April 4, 2018
% LTD
% December 3, 2019
% 
%
% Inputs:
%               all_slugs are reacting slugs
%               rinse_slugs are current rinse slugs
%               time_prior is the time at which slug_tracker_prior was
%               computed (in sec)
%               time is the current time (in sec)
%               v1 is the carrier phase flow rate (in uL/min)
%               v1_react is the effective carrier flow rate in the reactor at the set point temperature assuming feed at 25 deg. C (in uL/min)
%               
% Outputs:
%               updated all_slugs and rinse_slugs
%
%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Update reacting slugs (rxn time for specific step)
for i = 1:length(all_slugs)

    if all_slugs(i).in_system
        all_slugs(i).distance = all_slugs(i).distance + ...
                            v1 / 60 * (time - time_prior);
                        
    elseif all_slugs(i).in_hplc
        all_slugs(i).analysis_time = all_slugs(i).analysis_time + (time - time_prior);
        
    end
    

end

% Update rinse slugs
for i = 1:length(rinse_slugs)


    if rinse_slugs(i).in_system
        rinse_slugs(i).distance = rinse_slugs(i).distance + ...
                            v1 / 60 * (time - time_prior);
    end
    
    
end

 

end