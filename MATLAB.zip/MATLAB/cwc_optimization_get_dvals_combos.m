function [ dvals_combos ] = cwc_optimization_get_dvals_combos( opt_variables, fathomed_dvals )
% cwc_optimization_get_dvals_combos finds all possible combinations of 
% dicrete values in optimization variables. Filters out fathomed vals

% dvals_combos: each column is a set of dvals

% Get discrete variables
discrete = cellfun(@(x) strcmp(x, 'discrete'), {opt_variables.type});
opt_variables_discrete = opt_variables(discrete);

% Generate combinations
vecs = {};
for i = 1:length(opt_variables_discrete)
    vecs{length(vecs) + 1} = opt_variables_discrete(i).values;
end
dvals_combos = combvec(vecs{:}); %Create all combinations of vectors

% Filter fathomed sets
keep = ones(1, size(dvals_combos, 2));
for i = 1:size(dvals_combos, 2)
    for j = 1:size(fathomed_dvals, 2)
        if all(dvals_combos(:, i) == fathomed_dvals(:, j))
            keep(i) = 0;
        end
    end
end

dvals_combos = dvals_combos(:, keep == 1);

end

