function [ X ] = lmb_optimization_slugs_to_linmat_trunc( all_slugs, opt_vars )
% cwc_optimization_slugs_to_linmat converts all_slugs (each experimental
% condition) to a scaled linear system vector of experimental conditions,
% where each slug is one experiment given by the row vector X.

X = [];
labels = {};
for slug = all_slugs
     
    X_row = 1; %add offset
    for opt_var = opt_vars
        % What is the type? 
        if strcmp(opt_var.type, 'continuous') % continuous
            labels{length(labels) + 1} = opt_var.label;
            % Temperature doesn't get its own linear term
            if strcmp(opt_var.label, 'temperature')
                continue
            end
            % Need to append that scaled condition then
            if strcmp(opt_var.label, 'residence_time_goal')
                scaled_x = opt_var.scale_pm1(slug.residence_time_actual);
            else
                scaled_x = opt_var.scale_pm1(eval(['slug.' opt_var.label]));
            end
            X_row = [X_row, scaled_x];

        else % discrete
            % Need to convert exp. condition to one-hot vector
            discrete_x = eval(['slug.' opt_var.label ';']);
            one_hot_trunc = opt_var.one_hot_trunc(discrete_x); 
            %one_hot = opt_var.one_hot(discrete_x);
            
            % Need to append for whatever this discrete var modifies
            for i = 1:length(opt_var.modifies)
                modify = opt_var.modifies{i};
                if strcmp(modify, '1') % just a placeholder 1
                    X_row = [X_row, one_hot_trunc];
                else % multiply by continuous variable
                    scaled_x = 2;
                    for var = opt_vars
                        if strcmp(var.label, modify)
                            if strcmp(modify, 'residence_time_goal')
                                scaled_x = var.scale_pm1(slug.residence_time_actual);
                            else
                                scaled_x = var.scale_pm1(eval(['slug.' modify]));
                            end
                        end
                    end
                    if scaled_x == 2
                        error(['Discrete variable ' opt_var.label ' cannot '...
                            'modify non-existent continuous variable ' modify])
                    end
                    one_hot = opt_var.one_hot(discrete_x);
                    X_row = [X_row, one_hot * scaled_x];
                end                
            end
        end
    end
    
    % Append this slow (row) to the matrix
    X = [X; X_row];
end

end