function [slug_tracker] = slug_analysis(slug_tracker_prior,time_prior,time)
% SLUG_ANALYSIS updates slug_tracker for the time spent in HPLC analysis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% June 17, 2015
%
% Inputs:
%               slug_tracker_prior is the current slug_tracker matrix
%               time_prior is the time at which slug_tracker_prior was
%               computed (in sec)
%               time is the current time (in sec)
% Outputs:
%               slug_tracker is the matrix which will be used to track
%               slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Calculate elapsed time (in s)
t = time - time_prior;

% Find injected into HPLC index
col_LC = slug_get_index('Inject LC');

% Find analysis time index
col_ana = slug_get_index('Analysis');

% Find completed index
col_com = slug_get_index('Complete');

% Find slugs which have been injected into HPLC but not completed
ana_slugs = find(slug_tracker_prior(:,col_LC) - slug_tracker_prior(:,col_com) == 1);

% Update time spent in analysis
slug_tracker = slug_tracker_prior;
slug_tracker(ana_slugs,col_ana) = slug_tracker(ana_slugs,col_ana) + t;

end