function [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,inj_vol,rho_tf)
% SLUG_IN_PREP identifies composition of next slug to be prepared and
% updates the slug to reflect actual values (i.e., rounding)
%
% v2 allows for multistep reactions, *****NOTE THAT AUTOSAMPLER CONCS ARE
% NOT ADJUSTED TO ACCOUNT FOR ONLINE DILUTION *****
%
% v3 removes fill_min2 and fill_min3
%
% v4 uses the new ReagentTable class for reagent_table

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slugs
%               reagent_table is a ReagentTable object
%               inj_vol is the slug volume injected into the system (in uL)
%               rho_tf is the density of the transfer fluid (in g/L)
%               injection valve (in uL)
% Outputs:
%               prep_slug is the INDEX assigned to the slug
%               comp is the composition of the next slug to be prepared
%               all_slugs is the new list of slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find first slug which has not been injected into system
i = find(cwc_list_property(all_slugs, 'injected') == 0, 1, 'first');

if i ~= 0
    % Update to make slug in prep
    all_slugs(i).in_prep = 1;
    
    % Return slug index, too
    prep_slug = i;
    
    % Target base concentration (M)
    rb_conc = 0; % DO NOT ACCOUNT FOR ONLINE INJ WHEN PREPARING
    
    % Target precatalyst concentration (M)
    rp_conc = 0;
    
    % Bulk base concentration
    CB = 0;
    C_ISTD_base = 0;
    base_vol = 0;
    % NOTE: SLOPPY FIX FROM v1 OF THIS FUNCTION
    
    % Bulk precat concentration
    precat_reagent = find([reagent_table.reagents.type] == 5, 1, 'first');
    if ~isempty(precat_reagent)
        CP = precat_reagent.conc;
        C_ISTD_precat = precat_reagent.istd_conc;
    else
        CP = 0;
        C_ISTD_precat = 0;
    end
    
    % Load Volume (uL)
    load_vol = all_slugs(i).prepared_vol*1000/rho_tf; % rho_tf corrects volume sampled (h_tf/h_0 = (g/g)*(rho_0/rho_tf))
    load_vol = round(load_vol*10)/10;
    
    % Slug volume = injection volume + (Slug volume)*(frac base) + (Slug volume)*(frac precat)
    if CB > 0
        if CP > 0
            slug_vol = inj_vol/(1 - rb_conc/CB - rp_conc/CP);
        else
            slug_vol = inj_vol/(1 - rb_conc/CB);
        end
    elseif CP > 0
        slug_vol = inj_vol/(1 - rp_conc/CP);
    else
        slug_vol = inj_vol;
    end
    slug_vol = round(slug_vol*10)/10;
    
    % Minimum precat fill volume
    if CP > 0
        precat_vol = round(rp_conc/CP*slug_vol*10)/10;
    else
        precat_vol = 0;
    end
        
    % Total ISTD added (g)
    ISTD_mass = 0;
    
    % Total ISTD added (g)
    ISTD_mass = ISTD_mass + C_ISTD_precat*precat_vol*1e-6; % + C_ISTD_base*base_vol*1e-6;
    
    % Calculate composition and position of reagents
    comp = zeros(7,4);
    % Default values 
    r1_density = 1; r2_density = 1; r3_density = 1; r4_density = 1; r5_density = 1;
    c1 = 0; c2 = 0; c3 = 0; c4 = 0; c5 = 0;
    
    % Reagent 1
    % Bulk concentration (M)
    r1 = reagent_table.find_by_id(all_slugs(i).reagent_1);
    if ~isempty(r1)
        c1 = r1.conc;
        r1_density = r1.density /1000; %relative to H2O    
        if isnan(c1) == 0
            % Desired concentration (M)
            r1_conc = all_slugs(i).reagent_1_conc;
            % Reagent volume (uL), rounded to nearest 0.1 uL
            comp(2,1) = round(r1_conc/c1*(load_vol/inj_vol)*slug_vol*r1_density*10)/10;
        else
            c1 = 0;
            comp(2,1) = 0;
        end
        % Position
        comp(2,2) = r1.RackID;
        comp(2,3) = r1.PlaceID;
        comp(2,4) = r1.WellID;
    else
        c1 = 0;
        r1.istd_conc = 0;
    end
    
    % Reagent 2
    % Bulk concentration (M)
    r2 = reagent_table.find_by_id(all_slugs(i).reagent_2);
    if ~isempty(r2)
        c2 = r2.conc;
        r2_density = r2.density /1000; %relative to H2O   
        if isnan(c2) == 0
            % Desired concentration (M)
            r2_conc = all_slugs(i).reagent_2_conc;
            % Reagent volume (uL), rounded to nearest 0.1 uL
            comp(3,1) = round(r2_conc/c2*(load_vol/inj_vol)*slug_vol*r2_density*10)/10;
        else
            c2 = 0;
            comp(3,1) = 0;
        end
        % Position
        comp(3,2) = r2.RackID;
        comp(3,3) = r2.PlaceID;
        comp(3,4) = r2.WellID;
    else
        c2 = 0;
        r2.istd_conc = 0;
    end
    
    % Reagent 3
    % Bulk concentration (M)
    r3 = reagent_table.find_by_id(all_slugs(i).reagent_3);
    if ~isempty(r3)
        c3 = r3.conc;
        r3_density = r3.density /1000; %relative to H2O   
        if isnan(c3) == 0
            % Desired concentration (M)
            r3_conc = all_slugs(i).reagent_3_conc;
            % Reagent volume (uL), rounded to nearest 0.1 uL
            comp(4,1) = round(r3_conc/c3*(load_vol/inj_vol)*slug_vol*r3_density*10)/10;
        else
            c3 = 0;
            comp(4,1) = 0;
        end
        % Position
        comp(4,2) = r3.RackID;
        comp(4,3) = r3.PlaceID;
        comp(4,4) = r3.WellID;
    else
        c3 = 0;
        r3.istd_conc = 0;
    end
    
    % Reagent 4
    % Bulk concentration (M)
    r4 = reagent_table.find_by_id(all_slugs(i).reagent_4);
    if ~isempty(r4)
        c4 = r4.conc;
        r4_density = r4.density /1000; %relative to H2O   
        if isnan(c4) == 0
            % Desired concentration (M)
            r4_conc = all_slugs(i).reagent_4_conc;
            % Reagent volume (uL), rounded to nearest 0.1 uL
            comp(5,1) = round(r4_conc/c4*(load_vol/inj_vol)*slug_vol*r4_density*10)/10;
        else
            c4 = 0;
            comp(5,1) = 0;
        end
        % Position
        comp(5,2) = r4.RackID;
        comp(5,3) = r4.PlaceID;
        comp(5,4) = r4.WellID;
    else
        c4 = 0;
        r4.istd_conc = 0;
    end
    
    % Reagent 5
    % Bulk concentration (M)
    r5 = reagent_table.find_by_id(all_slugs(i).reagent_5);
    if ~isempty(r5)
        c5 = r5.conc;
        r5_density = r5.density /1000; %relative to H2O   
        if isnan(c5) == 0
            % Desired concentration (M)
            r5_conc = all_slugs(i).reagent_5_conc;
            comp(6,1) = round(r5_conc/c5*(load_vol/inj_vol)*slug_vol*r5_density*10)/10;

        else
            c5 = 0;
            comp(6,1) = 0;
        end
        % Position
        comp(6,2) = r5.RackID;
        comp(6,3) = r5.PlaceID;
        comp(6,4) = r5.WellID;
    else
        c5 = 0;
        r5.istd_conc = 0;
    end
    
    % Makeup
    rm = reagent_table.find_by_id(all_slugs(i).makeup);
    rm_density = rm.density/1000; %relative to H2O
    % Makeup volume (uL)
    sampled_vol = comp(2,1)/r1_density + comp(3,1)/r2_density + comp(4,1)/r3_density + comp(5,1)/r4_density + comp(6,1)/r5_density;
    comp(7,1) = round((load_vol - sampled_vol)*rm_density/2*10)/10;
    comp(1,1) = round(rm_density*(load_vol - sampled_vol - comp(7,1)/rm_density)*10)/10;
    % Position
    comp(1,2) = rm.RackID;
    comp(1,3) = rm.PlaceID;
    comp(1,4) = rm.WellID;
    comp(7,2) = rm.RackID;
    comp(7,3) = rm.PlaceID;
    comp(7,4) = rm.WellID;
    
    % Update load_vol
    load_vol = sampled_vol + comp(1,1)/rm_density + comp(7,1)/rm_density;
    

    % Correct slug concentration in slug_tracker
    
    all_slugs(i).reagent_1_conc = (comp(2,1)/r1_density)*c1/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_2_conc = (comp(3,1)/r2_density)*c2/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_3_conc = (comp(4,1)/r3_density)*c3/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_4_conc = (comp(5,1)/r4_density)*c4/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_5_conc = (comp(6,1)/r5_density)*c5/load_vol*inj_vol/slug_vol;

    
      %old density correction - brandon, why?   
%      if r2_density ~= 1
%         all_slugs(i).reagent_5_conc = (comp(6,1)/r5_density)*c5/load_vol*inj_vol/slug_vol;
%     else
%         all_slugs(i).reagent_5_conc = ((comp(6,1)+comp(3,1))/r5_density)*c5/load_vol*inj_vol/slug_vol;
%     end
 

%add clauses
    % Total ISTD added (g)
    ISTD_mass = ISTD_mass + r1.istd_conc*(comp(2,1)/r1_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + r2.istd_conc*(comp(3,1)/r2_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + r3.istd_conc*(comp(4,1)/r3_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + r4.istd_conc*(comp(5,1)/r4_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + r5.istd_conc*(comp(6,1)/r5_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + rm.istd_conc*(comp(1,1)+comp(7,1))/rm_density/load_vol*inj_vol*1e-6;
    
     % Update slug volume in slug_tracker
    all_slugs(i).injected_vol = slug_vol;
    
    % List ISTD concentration in slug_tracker in g/L
    ISTD_conc = (ISTD_mass)/(slug_vol*1e-6);
    all_slugs(i).istd_conc = ISTD_conc;
    
    % Temperature is accurate to 0.1oC
    all_slugs(i).temperature = round(all_slugs(i).temperature*10)/10;
    
    % Fix for weird situation where make-up solvent is slightly negative
    if comp(1,1) == -0.1
        comp(1,1) = 0;
    end
    
    % Fix situation where makeup solvent is tinz
    if abs(comp(7,1)) == 0.1
        comp(7,1) = 0;
    end
    
else
    % Don't update slug_tracker. Return all zeros for comp
    prep_slug = 0;
    comp = zeros(7,4);
end

end