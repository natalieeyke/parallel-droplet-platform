clear 
clc
% save_path = ['C:\Users\Admin\Desktop\12272016.mat'];
save_path = ['C:\Users\Admin\Desktop\20170215.mat'];
save_path = 'C:\Users\Admin\Documents\Optimization\Optimization 20170328\_03-28-2017_22-39_20 min.mat';
load(save_path)
% all_slugs = ans.all_slugs;
reagent_table_path = 'C:\Users\Admin\Documents\Input\Reagent_table_20170328_2';
data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\LMB_Suzuki 2017-03-28 18-03-19\014-NV-no Sample Name.D';
% [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,reagent_table_index,inj_vol,rho_tf);
% cwc_list_property(all_slugs,'istd_conc')
 ana_slug = 15;
 
 
 % reagent_table lists all reagents in the system
% index identifies the information contained in the columns of reagent_table
[reagent_table,reagent_table_index] = load_reagent_table(reagent_table_path);
 
 
[ret_time,area,conc,all_slugs,file_read_fail,slug_area_fail] = cwc_process_hplc_data(data_path,all_slugs,reagent_table,reagent_table_index,ana_slug);



ana_slug_reprocess =16;
data_path_reprocess = '\\LCMS2-HP\Chem32\1\Data\LMB\LMB_Suzuki 2017-03-28 18-03-19\015-NV-no Sample Name.D';

% ana_slug_reload is index of slug that should be reloaded
reprocess_exit_flag = '';

if exist(data_path_reprocess,'dir')==7

     % Get chromatogram data and convert to concentrations
     [ret_time_reprocess,area_reprocess,conc_reprocess,all_slugs,file_read_fail_reprocess,slug_area_fail_reprocess] = cwc_process_hplc_data(data_path_reprocess,all_slugs,reagent_table,reagent_table_index,ana_slug_reprocess);

     if (file_read_fail_reprocess+ slug_area_fail_reprocess)==0


          % Store objective function value
          [all_slugs] = lmb_objective_suzuki(all_slugs, ana_slug_reprocess,conc_reprocess);

          % Mark slug as complete in slug_tracker
          [all_slugs] = cwc_mark_slug_complete(all_slugs, ana_slug_reprocess);
          
          reprocess_exit_flag = 'Reprocessing successful!'; 

          else 
                if slug_area_fail_reprocess
                      reprocess_exit_flag = 'Reprocessed slug peak area fail!';
               end              
     end

else

     reprocess_exit_flag = 'Folder with report file not found!';

end


optim_path = 'C:\Users\Admin\Documents\Optimization\Optimization 20170328\_03-29-2017_00-55_00 min.mat';
save(optim_path, 'all_slugs','opt_state');

