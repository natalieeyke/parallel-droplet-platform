function [ all_slugs ] = lmb_objective_suzuki(all_slugs, ana_slug,conc)
%Calculate relative peak area yield and objective function value for suzuki reaction
%   Lorenz Baumgartner Februar 2017
%   Assumptions:
%   Internal standard is in line 1 of conc
%   Product is in line 3 of conc
%   Reactant 1 is limiting, Reactant 3 is the catalyst
%   Input: all_slugs object, ana_slug index of slug that was just analyzed,
%   area: reagent number in first column, peak area in second column
%   Output: all_slugs 

yield = 0;
objective_function_value = 1;

if ~isempty(conc)
    
    
    
    if all_slugs(ana_slug).reagent_1_conc ~=0 && conc(3,2) ~=0
        
        product_conc = conc(3,2);
        
        yield = product_conc / all_slugs(ana_slug).reagent_1_conc; 
    
    end
    
    if all_slugs(ana_slug).reagent_3_conc && conc(3,2)  ~=0  
        
        product_conc = conc(3,2);
        objective_function_value = log ( product_conc / all_slugs(ana_slug).reagent_3_conc );
        
    end
    

    
all_slugs(ana_slug).yield = yield;
all_slugs(ana_slug).objective = objective_function_value;



end %end if




end

