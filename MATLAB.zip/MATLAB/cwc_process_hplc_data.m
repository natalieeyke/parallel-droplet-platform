function [ret_time,area,conc,all_slugs,file_read_fail,slug_area_fail] = cwc_process_hplc_data(data_path,all_slugs,reagent_table,reagent_table_index,ana_slug)
%SLUG_AREA finds retention times, peak areas, and concentrations for reactants and products
%in reagent_table from HPLC chromatogram specified by data_path

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 23, 2012
% CWC
% June 17, 2015
%
% Inputs:
%               all_slugs is the list of slugs
%               data_path is the file path for the HPLC chromatogram
%               reagent_table is a matrix containing reagent information
%               reagent_table_index gives the header rows for reagent_table
%               ana_slug is the slug INDEX currently in analysis
%               
% Outputs:
%               ret_time is a matrix of retention times for the reagent
%               numbers in reagent_table
%               area is a matrix of peak areas for the reagent numbers in
%               reagent_table
%               conc is the calibrated chromatogram concentrations
%               all_slugs is the updated all_slugs
%               file_read_fail is 1 if file is not found
%               slug_area_fail is 1 if insufficient internal standard area
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Reagent number column
col_reag_num = find(strcmp(deblank(reagent_table_index),'Reagent Number') == 1);

% Reagent type column
col_type = find(strcmp(deblank(reagent_table_index),'Type') == 1);

% Minimum retention time column
col_rt_min = find(strncmp(deblank(reagent_table_index),'Min Ret Time',12) == 1);

% Maximum retention time column
col_rt_max = find(strncmp(deblank(reagent_table_index),'Max Ret Time',12) == 1);

% Linear calibration column
col_cal = find(strncmp(deblank(reagent_table_index),'Linear',6) == 1);

% Quadratic calibration column
col_quad = find(strncmp(deblank(reagent_table_index),'Quad',4) == 1);

% Wavelength column
col_wv = find(strncmp(deblank(reagent_table_index),'Wavelength',10) == 1);

% Initialize errors
slug_area_fail = 0;

% Build file name
file_name = [data_path '\REPORT01.xls'];

% Check for file. If no file, slug is incomplete
file_read = fopen(file_name);
if file_read == -1
    file_read_fail = 1;
else
    file_read_fail = 0;
end
if file_read_fail == 1
    all_slugs(ana_slug).complete = -1;
    %all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
    ret_time = [ ];
    area = [ ];
    conc = [ ];
    return
end 

% Read signals from file_name
[values,signals] = xlsread(file_name,'Signal','E2:E100');

% Read signal numbers fron file_name
sig_nums = xlsread(file_name,'Signal','N2:N100');

%If chemstation did not export signal numbers in column correctly this column is filled with zeros. 
%Fix: If all signal numbers are zero, assign signal number 1 to first signal, signal number 2 to second signal, ... 
if sum(sig_nums) == 0
    
    for i=1:size(sig_nums,1)
        sig_nums(i)=i;
    end
    
end

% Read peak data from file_name
peak_data = xlsread(file_name,'Peak','D2:P1000');

% Initialize peak_row, the rows of the ret_time and area matrices
peak_row = 0;

% Get internal standard concentration
conc_ISTD = all_slugs(ana_slug).istd_conc;

%estimate dilution by quench
quench_dilution = all_slugs(ana_slug).injected_vol/(all_slugs(ana_slug).injected_vol+all_slugs(ana_slug).quench_vol);


% Get internal standard peak area
area_ISTD = 0;
row_ISTD = find(reagent_table(:,col_type) == 9);

% Initialize slug_area_fail, which is 1 if internal standard area is
% insufficient
slug_area_fail = 0;

% Do for all reagents
for row_reag_num = reagent_table(:,col_reag_num)'
    
    % Get reagent number
    reag_num = reagent_table(row_reag_num,col_reag_num);
    
    % If calibration is given or reagent is internal standard
    if isnan(reagent_table(row_reag_num,col_cal)) + isnan(reagent_table(row_reag_num,col_quad)) ~= 2 || reagent_table(row_reag_num,col_type) == 9
           
        peak_row = peak_row + 1;
        
        % Search for calibration wavelength
        wavelength = reagent_table(row_reag_num,col_wv);
        if wavelength < 10
            wavelength = ['MSD' num2str(wavelength)];
        else
            wavelength = num2str(wavelength);
        end
        
        % Find wavelength in list of signals
        for sig_row = 1:length(sig_nums)
            if isempty(strfind(signals{sig_row},wavelength)) ~= 1;
                break
            end
        end
        
        % Find signal number
        %sig_num = sig_nums(sig_row,1);
        sig_num = sig_row;
        
        % Find minimum residence time
        rt_min = reagent_table(row_reag_num,col_rt_min);
        
        % Find maximum residence time
        rt_max = reagent_table(row_reag_num,col_rt_max);
        
        % Find all peaks between minimum and maximum residence time
        peak_range = find(peak_data(:,8) - rt_min >= 0 & rt_max - peak_data(:,8) >= 0);
        
        % Find peak area and rt. Assume peak is largest peak between rt_min and
        % rt_max measured at the wavelength
        ret_time(peak_row,:) = [reag_num 0];
        area(peak_row,:) = [reag_num 0];
        for peak_num = peak_range'
            
            % Check for right signal
            if peak_data(peak_num,1) == sig_num
                
                % If greater than previous area, accept
                if peak_data(peak_num,11) > area(peak_row,2);
                    ret_time(peak_row,2) = peak_data(peak_num,8);
                    area(peak_row,2) = peak_data(peak_num,11);
                    % If internal standard, store special area
                    if row_reag_num == row_ISTD
                        area_ISTD = peak_data(peak_num,11);
                    end
                end
                
            end
            
        end
        
    end % if isnan(reagent_table(reag_num,col_cal)) ~= 1
    
end


%Add internal standard tolerance?


% Check for acceptable internal standard area
if isnan(reagent_table(row_ISTD,col_cal)) ~= 1%only check if calibration is given in reagent table
    if area_ISTD < 0.4*reagent_table(row_ISTD,col_cal)*conc_ISTD*quench_dilution
        % Reject slug
        slug_area_fail = 1;
        all_slugs(ana_slug).complete = -1;
%         all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
        ret_time = [ ];
        area = [ ];
        conc = [ ];
        
        return
    end
end

% Calculate concentrations from calibration
peak_row = 0;

for reag_num = area(:,1)'
    
    peak_row = peak_row + 1;
    
    row_reag_num = find(reagent_table(:,col_reag_num) == reag_num);
    
    % For non-ISTD case
    if reagent_table(reag_num,col_type) ~= 9
        if isnan(reagent_table(row_reag_num,col_cal)) ~= 1
            if isnan(reagent_table(row_reag_num,col_quad)) ~= 1
                conc(peak_row,:) = [reag_num (reagent_table(row_reag_num,col_quad)*(area(peak_row,2)*conc_ISTD/area_ISTD)^2 + reagent_table(row_reag_num,col_cal)*area(peak_row,2)*conc_ISTD/area_ISTD)];
            else
                conc(peak_row,:) = [reag_num reagent_table(row_reag_num,col_cal)*area(peak_row,2)*conc_ISTD/area_ISTD];
            end
        else
            conc(peak_row,:) = [reag_num reagent_table(row_reag_num,col_quad)*(area(peak_row,2)*conc_ISTD/area_ISTD)^2];
        end
    else % For ISTD case
        conc(peak_row,:) = [reag_num conc_ISTD];
    end
    
end

end