function [ opt_variables ] = cwc_optimization_define( )
% cwc_optimization_define defines the variables to optimize over, their
% type (continuous/discrete) how they should be scaled, and any other
% relevant information.

% Reaction time
opt_variables(1) = OptVar();
opt_variables(1).label = 'residence_time_goal'; % s
opt_variables(1).type = 'continuous';
opt_variables(1).map = @(x) log(x);
opt_variables(1).min = 60;
opt_variables(1).max = 600;

% Temperature
opt_variables(2) = OptVar();
opt_variables(2).label = 'temperature'; % deg C
opt_variables(2).type = 'continuous';
opt_variables(2).map = @(x) 1 ./ (x + 273.15);
opt_variables(2).min = 30; 
opt_variables(2).max = 110;

% Reagent 1 species
opt_variables(3) = OptVar();
opt_variables(3).label = 'reagent_1'; % species no.
opt_variables(3).type = 'discrete';
opt_variables(3).values = 1:8;
opt_variables(3).modifies = {'1'; 'temperature'}; % offset and special factor for temperature

% Reagent 1 concentration
opt_variables(4) = OptVar();
opt_variables(4).label = 'reagent_1_conc'; % M
opt_variables(4).type = 'continuous';
opt_variables(4).map = @(x) log(x);
opt_variables(4).min = 0.835 / 1000;
opt_variables(4).max = 4.175 / 1000;

end