function [re_optimization_state ] = cwc_optimization_define_v3(start_opt)
% cwc_optimization_define defines the variables to optimize over, their
% type (continuous/discrete) how they should be scaled, and any other
% relevant information.
% v2 
% optimization parameters are saved in optimization state object
% v3 leave input empty to perform optimization, otherwise use any imput argument (e.g., "1")  

if nargin > 0 %don't run optimization, but create opt_state anyway so we can save and reload experimental data
       
re_optimization_state = OptState;
re_optimization_state.lin = false; % linear or quadratic
re_optimization_state.percent_improve = 0.01; % range = [0,1]
re_optimization_state.N_extra = 3; %standard = 3 range = [0,Inf]
re_optimization_state.yield_criterion = 1; % range = [0.001,1]
re_optimization_state.tol = 0.002; % rank tolerance
% re_optimization_state.patience = 3; %standard value = 3; run patience experiments before giving up
re_optimization_state.patience = 12; % run 4 experiments before giving up
re_optimization_state.buffer = 1; % on removal of experiments after fathoming
re_optimization_state.counter_i = 0; % initialize
re_optimization_state.not_improving = 0; % initialize
re_optimization_state.prev_best_b = -Inf; % initialize
re_optimization_state.fathomed_dvals = []; % initialize
re_optimization_state.removed_dvals = []; % initialize
re_optimization_state.opt_done = 1; % set to 
re_optimization_state.opt_variables = OptVar(); %generic empty optimization variable
re_optimization_state.FFD_type    = 'd_opt';

return

end


% Reagent 3 species
opt_variables(1) = OptVar();
opt_variables(1).label = 'reagent_3'; % base
opt_variables(1).type = 'discrete';
opt_variables(1).values = 4:6; %TEA, DBU, MTBD
% opt_variables(1).modifies = {'1'; 'temperature'}; % offset and special factor for temperature
opt_variables(1).modifies = {'1'}; % offset and special factor for temperature

% Reagent 4 species
opt_variables(2) = OptVar();
opt_variables(2).label = 'reagent_4'; % catalyst
opt_variables(2).type = 'discrete';
opt_variables(2).values = [ 7:13 ];
opt_variables(2).modifies = {'1';'temperature'}; % offset  


% Reaction time
opt_variables(3) = OptVar();
opt_variables(3).label = 'residence_time_goal'; % s
opt_variables(3).type = 'continuous';
opt_variables(3).map = @(x) log(x);
opt_variables(3).min = 60 ;
opt_variables(3).max = 1800;

% % Temperature
opt_variables(4) = OptVar();
opt_variables(4).label = 'temperature'; % deg C
opt_variables(4).type = 'continuous';
opt_variables(4).map = @(x) 1 ./ (x + 273.15);
opt_variables(4).min = 30; 
opt_variables(4).max = 100;
% 

% Reagent 2 concentration
opt_variables(5) = OptVar();
opt_variables(5).label = 'reagent_2_conc'; % M 1.5-3 piperidine equiv
opt_variables(5).type = 'continuous';
opt_variables(5).map = @(x) log(x);
opt_variables(5).min = 1.05;
opt_variables(5).max = 2.1;

% Reagent 3 concentration
opt_variables(6) = OptVar();
opt_variables(6).label = 'reagent_3_conc'; % M 1.5-3 base equiv
opt_variables(6).type = 'continuous';
opt_variables(6).map = @(x) log(x);
opt_variables(6).min = 1.05;
opt_variables(6).max = 2.1;

%initialize optimization parameters

re_optimization_state = OptState;

re_optimization_state.lin = false; % linear or quadratic
re_optimization_state.percent_improve = 0.01; % range = [0,1]
re_optimization_state.N_extra = 3; %standard = 3 range = [0,Inf]
re_optimization_state.yield_criterion = 1; % range = [0.001,1]
re_optimization_state.tol = 0.002; % rank tolerance
% re_optimization_state.patience = 3; %standard value = 3; run patience experiments before giving up
re_optimization_state.patience = 3; % run 4 experiments before giving up
re_optimization_state.buffer = 1; % on removal of experiments after fathoming
re_optimization_state.counter_i = 0; % initialize
re_optimization_state.not_improving = 0; % initialize
re_optimization_state.prev_best_b = -Inf; % initialize
re_optimization_state.fathomed_dvals = []; % initialize
re_optimization_state.removed_dvals = []; % initialize
re_optimization_state.opt_done = 0;
re_optimization_state.opt_variables = opt_variables;
re_optimization_state.FFD_type    = 'd_opt';
        



end