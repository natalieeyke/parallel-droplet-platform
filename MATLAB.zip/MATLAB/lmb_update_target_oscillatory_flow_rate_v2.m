function [v1_new] = ...
         lmb_update_target_oscillatory_flow_rate(all_slugs, react_slug, upcoming_step, num_passes, num_passes_completed, v1_normal, v1_osc, oscillatory_vol, outlet_to_quench_vol, T_set)
% recalculates the target oscillatory flow rate during the "Oscillating:
% waiting for PD detection step
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LMB
% January 9, 2017
%
% Inputs:
%               all_slugs is the list of slugs
%               react_slug is the INDEX of the identified slug
%               v1_normal is  the flow rate upon exit
%               v1_osc is the oscillatory flow rate (max)
%               oscillatory_vol is the vol between photodetectors
%               outlet_to_quench_vol is the fixed distance to quench
%               T_set is the reactor temperature in C
%               upcoming_step is the index of the reaction step for the
%                   current slug
%               num_passes is the number of cycles (0 is straight through,
%                   2 is one forward-backward-forward)
%               num_passes_completed is the number of completed passes
%               
% Outputs:
%               react_slug is the INDEX of the identified slug
%               v1_new is the flow rate for oscillation

%               base_inj_vol is the volume (uL) to inject right before the
%                   next reaction step (to prep injection)
%               last_step is a 1 or 0 depending on if this next step is the
%                   last one
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% If T_set < 20, then chances are we are doing an unheated photoredox rxn
% ambient temperature ~23 degC
if T_set < 20
    T_set = 23;
end



% Get target time
residence_time_goal = all_slugs(react_slug).residence_time_goal(upcoming_step);
residence_time_passed = all_slugs(react_slug).residence_time_actual(upcoming_step);

% Get time from outlet to quench (fixed)
min_time = outlet_to_quench_vol / v1_normal * 60;

% Get new oscillatory goal
oscillatory_time_goal = residence_time_goal - residence_time_passed - min_time; %time the slug should still remain in the system


num_passes_remaining = num_passes - num_passes_completed;

oscillatory_volume_remaining =  oscillatory_vol * num_passes_remaining;


% Find exact flow rate now
v1_new = oscillatory_volume_remaining / oscillatory_time_goal * 60;

% Correct for ideal gas law expansion
% v1_new = v1_new / (T_set + 273.15) * 293.15;

safetyfactor = 1;

%allow system to speed up to a higher flow rate for the last pass and
%slug does not have to be slow for a quench injection
% if num_passes_remaining == 1 && all_slugs(react_slug).quench_vol 
%     safetyfactor = 2.5; 
% end

if v1_new > v1_osc %limit the flow rate to maximum oscillation flow rate
    
    v1_new = v1_osc*safetyfactor;
    
end

end