function [ best_slug, N_experiment, remaining_discrete ] = ...
    lmb_optimization_testscript( opt_variables, lin, N_extra, ...
                                     simulate_function, percent_improve, ...
                                     yield_criterion, noise, tol, patience)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 8.18.16
% Kevin Gao
% 
% cwc_kwg_optimization_testscript runs an optimization algorithm for
% simulated kinetics using G-optimality; fathoming and removal of
% experiments.
% see kgao_report2016.doc
% 
% INPUTS:
% [opt_variables]       OptVar array; the variables to optimize over
% [lin]                 Logical; 0 for quadratic or 1 for linear
% [N_extra]             Float; # of extra experiments in the initial design
% [simulate_function]   String; the filename for the kinetic simulation   
% [percent_improve]     Float; the improvement criterion percentage
% [yield_criterion]     Float; constraint on yield as a percentage of the
%                              maximum global yield
% [tol]                 Float; tolerance used in rank() 
% [patience]            Float; number of times without improvement before
%                              terminating optimization
% [noise]               Float; uniformly distributed percentage of random
%                              noise
% 
% OUTPUTS:
% [best_slug]           Slug array; the predicted optimal conditions
% [N_experiment]        Float; tracks the number of experiments performed
% [remaining_discrete]  Float; tracks the number of discrete variables
%                              still in the optimization 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic

%%%%% DEFAULT SETTINGS %%%%%
if nargin < 9 %nargin: number of input arguments
    simulate_function = 'lmb_optimization_simulate_multidiscrete';
%     simulate_function = 'kwg_optimization_simulate_slugTON';
%     [ opt_variables ] = cwc_optimization_define();
    [ opt_variables ] = lmb_optimization_define_2dis(); 
%     lin = true; % linear or quadratic
    lin = false; % linear or quadratic
    percent_improve = 0.01; % range = [0,1]
    N_extra = 3; % range = [0,Inf]

    noise = 0.00; % range = [0,1]
    yield_criterion = 0.90; % range = [0.001,1]
    tol = max(noise, 0.002); 
    patience = 3; %
    
    fprintf('DEFAULT SETTINGS:\n')
end
%%%%% DEFAULT SETTINGS %%%%%

% Display parameters
if lin
    fprintf('LINEAR\n')
else
    fprintf('QUADRATIC\n')
end %if
disp(['N_extra:               ' num2str(N_extra)])
disp(['Patience:              ' num2str(patience)])
disp(['Rank tolerance:        ' num2str(tol)])
disp(['Improvement Criterion: ' num2str(100*percent_improve), '%'])  
disp(['Noise:                 ' num2str(100*noise), '%'])
disp(['Yield Criterion:       ' num2str(100*yield_criterion), '%'])

% Template
[ all_slugs ] = cwc_optimization_center_optvar( Slug(), opt_variables);
all_slugs(1).reagent_1_conc = 1;
all_slugs(1).temperature = 60;

% Initialize
dvals_combos = cwc_optimization_get_dvals_combos( opt_variables, [] );

 
  


% Initial design of experiments
[ all_slugs ] = lmb_optimization_generate_ffd( all_slugs, opt_variables, ...
                                               'd_opt', lin, N_extra );
all_slugs_log =    all_slugs;                                        
% [ all_slugs ] = cwc_optimization_generate_ffd3( all_slugs, opt_variables, ...
%                                                'ffd', lin, N_extra );


% Simulate initial experiments
for i = 1:length(all_slugs)
    all_slugs(i) = eval([simulate_function '(all_slugs(i), noise);']);
end



% Initialize
buffer = 1; % increases restriction on removal of exp.
counter_i = 0; % change to 1 removes extra cycle of exp. before fathoming
not_improving = 0; 
prev_best_b = -Inf; 
fathomed_dvals = []; 
removed_dvals = []; 
dvals_opt_max = [];
N_experiment = length(all_slugs); 

while true    
    %% Get RSM parameters
    % Get experimental matrix
    [ completed_slugs ] = cwc_optimization_completed_slugs( all_slugs );%update property that marks slugs as finished
    if lin
        [ X ] = lmb_optimization_slugs_to_linmat( completed_slugs, opt_variables,removed_dvals );
    else
        [ X ] = lmb_optimization_slugs_to_quadmat( completed_slugs, opt_variables,removed_dvals ); %generates the model matrix of independent variables
    end
    [ dval_labels ] = cwc_optimization_slugs_to_dval_labels( completed_slugs, opt_variables );%creates cell array with slug labels, useful for graphing
    
    % Get weights
    [ W_unnorm ] = cwc_optimization_slugs_to_weights( completed_slugs );
    [ W ] = W_unnorm * length(diag(W_unnorm)) / sum(diag(W_unnorm)); % normalized so average == 1
    
    % Get objective function values
    [ b ] = cwc_list_property( completed_slugs, 'objective' );
    
    % Get yield values 
    [ yield_vals ] = cwc_list_property( completed_slugs, 'yield' );
    [ log_yield_vals ] = log( yield_vals );
    
    % Get WLS parameters (weighted least squares)
    disp(['number of completed experiments: ' num2str(length(b))])
    disp(['number of parameters:            ' num2str(size(X, 2))])
    disp(['rank of X:                       ' num2str(rank(X,tol))])
    if length(b) < size(X, 2)
        warning('More parameters to fit than experiments')
    end
    if rank(X,tol) < size(X, 2)
        warning('More parameters to fit than rank of X')
    end
    
    if counter_i ==1;
        stop_string = '';
    end
    
    % Response surface fitting
    [T_obj, stdT_obj, mse_obj, S_obj] = lscov(X, b, diag(W)); % objective %lscov: Least-squares solution in presence of known covariance
    [T_y, stdT_y, mse_y, S_y] = lscov(X, log_yield_vals, diag(W)); % yield
    
    
    mese = ((b - X * T_obj)'*(b - X * T_obj))/(size(X,1)-size(X,2));
    
    
    
    % Get predictions
    b_hat = X * T_obj; %predicted objective function values %b_hat : b^   
    y_hat = X * T_y; %predicted yields
    
    %%%%%%%%%% PLOTTING PURPOSES ONLY %%%%%%%%%%
    %% Plot current data with error bars
    % Get confidence bounds on prediction for response at each point
    b_hat_pm = zeros(size(b_hat)); 
    y_hat_pm = zeros(size(y_hat));
    b_hat_pm_mean = zeros(size(b_hat));
    y_hat_pm_mean = zeros(size(y_hat));
    
    innermat = inv(X' * W * X);
    
    for i = 1:length(b_hat)
        % CI for individual response at X(i,:) of obj
        b_hat_pm(i) = tinv(0.99, length(b) - length(T_obj)) * ...
                      sqrt(mse_obj * (1 + X(i, :) * innermat * X(i, :)'));
        % tinv: Student's t inverse cumulative distribution function: x = tinv(p,nu); p = 1-alpha propability, nu = degree of freedoms      
                  
        % CI for mean response at X(i, :) of obj
        b_hat_pm_mean(i) = tinv(0.99, length(b) - length(T_obj)) * ...
                           sqrt(mse_obj * X(i, :) * innermat * X(i, :)');
        
        % CI for individual response at X(i, :) of yield
        y_hat_pm(i) = tinv(0.99, length(log_yield_vals) - length(T_y)) * ...
                      sqrt(mse_y * (1 + X(i, :) * innermat * X(i, :)'));
        
        % CI for mean response at X(i, :) of yield
        y_hat_pm_mean(i) = tinv(0.99, length(log_yield_vals) - length(T_y)) * ...
                           sqrt(mse_y * X(i, :) * innermat * X(i, :)');
    end %for
    
    figure(1)
    clf(1)
    scatter(1:length(b), b_hat, 'ko')
    hold on
    text((1:length(b)) + 0.2, b_hat, dval_labels)
    scatter(1:length(b), b_hat - b_hat_pm, 'ro')
    scatter(1:length(b), b_hat + b_hat_pm, 'go')
    scatter(1:length(b), b, 'b*')
    title('Predicted vs. experimental objective function')
    xlabel('Experiment #')
    ylabel('Objective value')
    legend({'prediction'; 'prediction (lb)'; 'prediction (ub)'; ...
            'experimental'}, 'Location', 'southoutside', 'Orientation', ...
            'horizontal')
        
    figure(2)
    clf(2)
    scatter(1:length(log_yield_vals), y_hat, 'ko')
    hold on
    text((1:length(log_yield_vals)) + 0.2, y_hat, dval_labels)
    scatter(1:length(log_yield_vals), y_hat - y_hat_pm, 'ro')
    scatter(1:length(log_yield_vals), y_hat + y_hat_pm, 'go')
    scatter(1:length(log_yield_vals), log_yield_vals, 'b*')
    title('Predicted vs. experimental yields')
    xlabel('Experiment #')
    ylabel('Yield')
    legend({'prediction'; 'prediction (lb)'; 'prediction (ub)'; ...
            'experimental'}, 'Location', 'southoutside', 'Orientation', ...
            'horizontal')
    
%     %% Plot slice of response surfaces with respect to catalyst conc.
%     % Get concentrations of catalyst
%     [ conc ] = cwc_list_property( completed_slugs, 'reagent_1_conc');
%     
%     % Find values of best discrete variable
%     if (isempty(dvals_opt_max) == 0)
%         [ dv_index ] = find( cwc_list_property( completed_slugs, 'reagent_1' ) == dvals_opt_max ...
%                            & cwc_list_property( completed_slugs, 'residence_time_goal' ) > 0.999*cvals_opt_max(1) ...
%                            & cwc_list_property( completed_slugs, 'residence_time_goal' ) < 1.001*cvals_opt_max(1) ...
%                            & cwc_list_property( completed_slugs, 'temperature') > 0.999*cvals_opt_max(2) ...
%                            & cwc_list_property( completed_slugs, 'temperature') < 1.001*cvals_opt_max(2) );
%         [ dv_conc ] = conc(dv_index);
%         [ dv_b ] = b(dv_index);
%         [ dv_log_yield_vals ] = log_yield_vals(dv_index);                   
%     end %if  
% 
%     % Only plot if discrete variable has not been removed
%     if (any(removed_dvals == dvals_opt_max) == 0) && (isempty(dvals_opt_max) == 0)
%         % Plot response surface vs conc. at optimal T/time
%         opt_vars = opt_variables;
%         dvals = dvals_opt_max;
%         cvals_array = zeros(3,100); % initialize
%         X_new_array = []; % initialize
% 
%         for opt_var = opt_vars
%             if strcmp(opt_var.label, 'reagent_1_conc')
%                 concentration = linspace(opt_var.min, opt_var.max);
%             end %if
%         end %for
% 
%         for i = 1:100
%             cvals_array(1,i) = cvals_opt_max(1);
%             cvals_array(2,i) = cvals_opt_max(2);
%             cvals_array(3,i) = concentration(i);
%         end %for
%         for i = 1:100
%             slug = cwc_optimization_cdvals_to_slug(cvals_array(:,i), dvals, opt_vars);
%             if lin
%                 X_new_array2 = cwc_optimization_slugs_to_linmat( slug, opt_vars );
%             else
%                 X_new_array2 = cwc_optimization_slugs_to_quadmat( slug, opt_vars );
%             end %if
%             
%             X_new_array = [X_new_array; X_new_array2];
%         end %for
% 
%         figure(3)
%         clf(3)
%         plot(concentration, X_new_array*T_obj)
%         hold on
%         plot(dv_conc, dv_b, 'o')
%         str = sprintf('RS: Obj vs Conc, dv = %s, time = %s, temp = %s', ...
%                       num2str(dvals_opt_max), num2str(cvals_opt_max(1)), ...
%                       num2str(cvals_opt_max(2)));
%         title(str);
%         text((1:length(log_yield_vals)) + 0.2, conc, dval_labels)
%         xlabel('Conc. (M)')
%         ylabel('Log(Obj)')
% 
%         figure(4)
%         clf(4)
%         plot(concentration, X_new_array*T_y)
%         hold on
%         plot(dv_conc, dv_log_yield_vals, 'o')
%         str2 = sprintf('RS: Yield vs Conc, dv = %s, time = %s, temp = %s', ...
%                        num2str(dvals_opt_max), num2str(cvals_opt_max(1)), ...
%                        num2str(cvals_opt_max(2)));
%         title(str2);
%         xlabel('Conc. (M)')
%         ylabel('Log(Yield)')
%     end %if
%     %%%%%%%%%% PLOTTING PURPOSES ONLY %%%%%%%%%%
%     
    %% Use the predicted optimum to see if we can fathom any discrete vars
    check = false; % initialize
    fathomed_pre = false; % initialize
    
    % Check if we can remove experiments from fathomed queue
     
    
    for i = 1:size(fathomed_dvals,2)
        
         remove_dvals = fathomed_dvals(:,i);
         
            
         [ all_slugs_new ] = lmb_dvals_remove(all_slugs, opt_variables, remove_dvals); %remove experiments associated with discrete variable combo that should be removed
         
         
         removed_dvals_new = [removed_dvals, remove_dvals]; %all discrete variable combos that would be removed
         
         [ opt_variables_new ] = lmb_update_opt_var( opt_variables, removed_dvals_new ); %remove values from discrete optimization values if all combinations have been removed         
         [ check ] = lmb_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol, removed_dvals_new);
     
   
        
        if check
            removed_exp = length(all_slugs) - length(all_slugs_new);
              
            all_slugs = all_slugs_new;
            removed_dvals = removed_dvals_new;  % add to removed variable list
            opt_variables  = opt_variables_new; 
            
            disp(['Fathoming out discrete variable set ' ...
                   num2str(remove_dvals') ' from fathom queue'])
            disp(['...removed ' num2str(removed_exp) ' experiments'])
            
             
            fathomed_dvals(:,i) = zeros(size(fathomed_dvals,1),1); % mark with 0 for removal after for loop is done
            
            fathomed_pre = true;
        end %if
    end %for 
%     removals = find(fathomed_dvals == 0);
    removals = lmb_find_dval_combo( fathomed_dvals , zeros(size(fathomed_dvals,1),1)); %get index for columns marked with 0
    if~isempty(removals)
       fathomed_dvals(:,removals) = []; % remove from fathoming queue
    end
    
    if fathomed_pre
        disp(['reset convergence timer, making progress!'])
        not_improving = -1;
        continue
    end %if
    
     
    % Find the predicted optima
    [ cvals_opts, b_opts, yield_opts, dvals_combos ] = ...
        lmb_optimization_estimate_max( T_obj, T_y, opt_variables, lin, fathomed_dvals, removed_dvals, yield_criterion);
                     
    % Get maximum yield
    max_yield = max(yield_opts);
    
    % Get maximum objective
    [b_opt_max, i_opt] = max(b_opts);
    
    % Get yield/cvals/dvals at maximum objective
    y_opt_max = yield_opts(i_opt);
    cvals_opt_max = cvals_opts(:, i_opt);
    dvals_opt_max = dvals_combos(:, i_opt);
    
    disp(['> estimated max objective at dvals = ' num2str(dvals_opt_max') ...
          ', cvals = ' num2str(cvals_opt_max')]);
    disp(['> estimated max objective = ' num2str(b_opt_max)])
    disp(['> estimated global max yield = ' num2str(exp(max_yield))])
    
    % Estimate uncertainty at optimum
    X_opt = lmb_optimization_cvals_to_X( cvals_opt_max, dvals_opt_max, ...
                                         opt_variables, lin,removed_dvals );

    innermat = inv(X' * W * X);
    b_opt_std = sqrt(mse_obj * (X_opt * innermat * X_opt'));
    y_opt_std = sqrt(mse_y * (X_opt * innermat * X_opt'));
    b_opt_pm = tinv(0.99, length(b) - length(T_obj)) * b_opt_std;
    y_opt_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_opt_std;
    
    % Prediction lower bound
    b_opt_lb = b_opt_max - b_opt_pm;
    
    disp(['> b_hat = ' num2str(b_opt_max) ' +/- ' num2str(b_opt_pm) ...
          ' (99% conf. interval)']);
    disp(['> y_hat = ' num2str(exp(y_opt_max)) ' +/- ' num2str(y_opt_pm) ...
          ' (99% conf. interval)']);
    
    % Fathom worst variables first
    diff_array = b_opts - b_opt_lb;
    [sorted_diff_array, index] = sort(diff_array);

    fathomed = false; % initialize
    check = false; % initialize
    
    if counter_i > 0        
        for i = 1:length(b_opts)
            if sorted_diff_array(i) < 0
                disp(['Ready to fathom out discrete variable set ' ...
                      num2str(dvals_combos(:, index(i))') ', estimated opt (' ...
                      num2str(b_opts(index(i))) ') < global opt 99% lb (' ...
                      num2str(b_opt_lb) ')'])
                  
                remove_dvals = dvals_combos(:, index(i)); %discrete variable combo that should be removed
                removed_dvals_new = [removed_dvals, remove_dvals]; %all discrete variable combos that would be removed
                  
                [ all_slugs_new ] = lmb_dvals_remove( ... 
                    all_slugs, opt_variables, remove_dvals); %remove experiments associated with discrete variable combo that should be removed
                [ opt_variables_new ] = lmb_update_opt_var( opt_variables, removed_dvals_new ); %remove values from discrete optimization values if all combinations have been removed 
                
                [ check ] = lmb_check_remove( all_slugs_new,opt_variables_new, buffer, lin, tol, removed_dvals_new);
%                 [ check ] = kwg_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol);
                
                if check
                    removed_exp = length(all_slugs) - length(all_slugs_new);
            
                    all_slugs = all_slugs_new;
%                     opt_variables = opt_variables_new;
            
                    removed_dvals  = removed_dvals_new;
                    opt_variables  = opt_variables_new;
                        
                    disp(['Fathoming out discrete variable set ' ...
                          num2str(remove_dvals')])
                    disp(['...removed ' num2str(removed_exp) ' experiments'])
                
                    fathomed = true;
                else
                    if any(lmb_find_dval_combo(fathomed_dvals, remove_dvals)) == 0 %if combo it is not in queue already
                        fathomed_dvals = [fathomed_dvals, remove_dvals]; %add to combo to fathoming queue
                        disp(['Adding discrete variable set ' ...
                               num2str(dvals_combos(:, index(i))') ...
                               ' to the fathom queue'])
                    end %if
                    continue  
                end %if
               
            end %if
        end %for
        
        if fathomed % need to recalculate T, W, etc.
            disp(['reset convergence timer, making progress!'])
            not_improving = -1;
            continue
        end
    
        disp(['no variables to fathom'])
    else
        counter_i = counter_i + 1;
    end %if
    
    %% Determine if sufficient progress is being made
    % Filter by completed slugs
    completed_slugs = cwc_optimization_completed_slugs( all_slugs );
    obj_values = cwc_list_property( completed_slugs, 'objective' );
    yield_values = cwc_list_property( completed_slugs, 'yield' );
    
    % Filter by yield criterion 
    yield_crit = max(yield_values);
    yield_index = find( cwc_list_property(completed_slugs, 'yield') >= ...
                        yield_criterion * yield_crit );
    obj_yield_values = obj_values(yield_index);
    best_b = max(obj_yield_values);
    
    % Sign change
    if prev_best_b < 0
        prev_best_b_correction = - prev_best_b;
    else
        prev_best_b_correction = prev_best_b;
    end %if
        
    if ( (best_b - prev_best_b) / prev_best_b_correction ) <= percent_improve
        not_improving = not_improving + 1;
            
        disp([num2str(not_improving) ' iterations without ' ...
              num2str(100*percent_improve) '% exp. improvement or fathoming'])   
    
        if not_improving > patience
            disp(['Failed to make satisfactory progress for more than ' ...
                  num2str(patience) ' slugs'])
            break%breaks while loop
        end
    else
        disp(['objective function = ' num2str(best_b) ' >= ' num2str(prev_best_b)])
        prev_best_b = best_b;
        not_improving = 0;
    end

    %% Get the next set of G-optimal experiments (for each dval set)
    % Get G-optimal
    [ cvals_opts, G_opts, dvals_opts ] = ...
        lmb_optimization_get_Gopt( opt_variables, lin, ...
                                       fathomed_dvals, removed_dvals,  ...
                                       X, T_obj, T_y, yield_criterion, b, ...
                                       log_yield_vals, completed_slugs );

    %% Run those proposed experiments
    % Run all proposed experiments
    for i = 1:length(G_opts)
        cvals_opt = cvals_opts(:, i);
        dvals_opt = dvals_opts(:, i);
        disp(['for dvals ' num2str(dvals_opt') ', proposed cvals ' num2str(cvals_opt')])
        
        % Estimate uncertainty at G_opt
        X_next = lmb_optimization_cvals_to_X( cvals_opt, dvals_opt, opt_variables, lin,removed_dvals );
        
        innermat = inv(X' * W * X);
        b_next_std = sqrt(mse_obj * (1 + (X_next * innermat * X_next')));
        y_next_std = sqrt(mse_y * (1 + (X_next * innermat * X_next')));
        b_next_pm = tinv(0.99, length(b) - length(T_obj)) * b_next_std;
        y_next_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_next_std;
        
        b_next = X_next * T_obj;
        y_next = X_next * T_y;
        
        % Define new slug and simulate
        new_slug = cwc_optimization_cdvals_to_slug( cvals_opt, dvals_opt, opt_variables );
        new_slug = eval([simulate_function '(new_slug, noise)']);
        all_slugs_log =    [all_slugs_log new_slug];
        all_slugs = [all_slugs new_slug];

        % Report
        disp(['----- NEXT EXPERIMENT: ' num2str(N_experiment) ' -----'])
        disp(['    res time:     ' num2str(new_slug.residence_time_goal)])
        disp(['    temp:         ' num2str(new_slug.temperature)])
        disp(['    reag 1:       ' num2str(new_slug.reagent_1)])
        disp(['    reag 1 conc:  ' num2str(new_slug.reagent_1_conc)])
        disp(['    PRE OBJ:      ' num2str(b_next) ' +\- ' num2str(b_next_pm) ...
              ' (99% confidence)'])
        disp(['    EXP OBJ:      ' num2str(new_slug.objective)])
        disp(['    PRE YIELD:    ' num2str(exp(y_next)) ' +\- ' num2str(y_next_pm) ...
              ' (99% confidence)'])
        disp(['    EXP YIELD:    ' num2str(new_slug.yield)])
       
        N_experiment = N_experiment + 1; % count experiments
    end
end

% Best/last predicted estimate:
new_slug = cwc_optimization_cdvals_to_slug( cvals_opt_max, dvals_opt_max, opt_variables );
best_slug = eval([simulate_function '(new_slug, noise)']);
all_slugs_log =    [all_slugs_log best_slug];

keyboard %Input from keyboard

% Display
for opt_var = opt_variables
    val = eval(['best_slug.' opt_var.label]);
    disp([opt_var.label ' : ' num2str(val)]);
end

remaining_discrete = length(G_opts);
time_comp = toc;

 

disp(['Algorithm computation time:  ' num2str(time_comp) ' seconds'])
disp(['Total number of experiments: ' num2str(N_experiment + 1)])
disp(['Remaining discrete:          ' num2str(remaining_discrete)])