function [T_set] = cwc_get_temperature_set(all_slugs)
% finds the correct temperature setpoint

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slugs
% Outputs:
%               T_set is the reactor set point temperature (in deg C)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find the slug index of the last slug to exit the reactor
slug_num = find(cwc_list_property(all_slugs, 'injected') == 1 & ...
                cwc_list_property(all_slugs, 'in_reactor') == 0 & ...
                cwc_list_property(all_slugs, 'residence_time_actual') > 0, 1, 'last');

% Nothing found -> still need the first slug temperature
if isempty(slug_num)
    T_set = all_slugs(1).temperature;
% If there is a next slug -> that temperature
elseif (slug_num + 1 <= length(all_slugs))
    T_set = all_slugs(slug_num + 1).temperature;
% Done with slugs -> start cooling down
else
    T_set = 0; % let cool down
end

end