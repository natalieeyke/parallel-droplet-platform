function [ X ] = cwc_optimization_slugs_to_quadmat( all_slugs, opt_vars )
% based on cwc_optimization_slugs_to_quadmat converts all_slugs (each experimental
% condition) to a scaled system vector of experimental conditions,
% where each slug is one experiment given by the row vector X. After all
% of the linear continuous and discrete terms are added to a row, the
% quadratic interactions between continuous vars are added.
% combo: supports combinations of different sets of discrete variables

X = []; % initialize


for slug = all_slugs
    X_row = []; %list of indepentent variables
    discrete_combo_slug = [];
    continuous = []; % keep track for quad terms
    for opt_var = opt_vars
        % What is the type? 
        if strcmp(opt_var.type, 'continuous') % continuous
            % Need to append that scaled condition then
            scaled_x = opt_var.scale_pm1(eval(['slug.' opt_var.label]));
            continuous = [continuous, scaled_x]; %add variable line
            % Temperature doesn't get its own linear term
            if strcmp(opt_var.label, 'temperature')
                continue
            end
            X_row = [X_row, scaled_x]; %add variable line

        else % discrete
            % Need to convert exp. condition to one-hot vector
            discrete_x = eval(['slug.' opt_var.label ';']);
            
            discrete_combo_slug =  [  discrete_combo_slug ; discrete_x  ];
            
            
            one_hot = opt_var.one_hot(discrete_x);
            % Need to append for whatever this discrete var modifies
            for i = 1:length(opt_var.modifies)
                modify = opt_var.modifies{i}; 
                if strcmp(modify, '1') % just a placeholder 1
%                     X_row = [X_row, one_hot]; % add combo one hot later
                else % multiply by continuous variable
                    scaled_x = 2;
                    for var = opt_vars
                        if strcmp(var.label, modify)
                            scaled_x = var.scale_pm1(eval(['slug.' modify]));
                        end
                    end
                    if scaled_x == 2
                        error(['Discrete variable ' opt_var.label ...
                               ' cannot modify non-existent continuous' ...
                               ' variable ' modify])
                    end
                    X_row = [X_row, one_hot * scaled_x];
                end                
            end
        end
    end
    
    %create one_hot vector for combos
    [ dvals_combos ] = cwc_optimization_get_dvals_combos( opt_vars, [] );
    
    
    
    one_hot_line_sum = zeros(1,size( dvals_combos,2)); %initialize
    for i = 1:size( dvals_combos,1)
    one_hot_line(i,:) = double(dvals_combos(i,:) == discrete_combo_slug(i));
    one_hot_line_sum = one_hot_line(i,:) + one_hot_line_sum; % add up
    end
    
    one_hot_combos = one_hot_line_sum == size( dvals_combos,1);
     
    X_row = [X_row, one_hot_combos];
    
    
    % Append quadratic terms from continuous vars now
    for i = 1:length(continuous)
        for j = i:length(continuous)
            X_row = [X_row, continuous(i) * continuous(j)];
        end
    end
    
    % Append this slow (row) to the matrix
    X = [X; X_row];
end

end