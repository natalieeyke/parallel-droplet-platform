function [ all_slugs ] = cwc_remake_failed_slug( all_slugs, cur_slug )
% remake this slug, insert into list before the last in-prep one
% cur_slug has to be an actual slug

% Initialize
new_slug = cur_slug;
new_slug.injected_vol = 0;
new_slug.current_vol = 0;
new_slug.residence_time_actual = 0 * new_slug.residence_time_actual;
new_slug.multi_injected = 0 * new_slug.multi_injected;
new_slug.in_prep = 0;
new_slug.in_system = 0;
new_slug.injected = 0;
new_slug.in_reactor = 0;
new_slug.in_hplc = 0;
new_slug.distance = 0;
new_slug.distance_matched = 0;
new_slug.inj_base = 0;
new_slug.inj_quench = 0;
new_slug.analysis_time = 0;
new_slug.complete = 0;
new_slug.yield = 0;
new_slug.objective = 0;
new_slug.hplc_data_path = '';

new_slug.number = max(cwc_list_property(all_slugs, 'number')) + 1;

% Insert as soon as possible (look for last prepped slug)
i = find(and(cwc_list_property(all_slugs, 'in_prep') == 0, ...
             cwc_list_property(all_slugs, 'injected') == 0), 1, 'first');

% FIXED BUG - failure on last slug
if isempty(i)
    all_slugs = [all_slugs new_slug];
else
    all_slugs_temp = [all_slugs(1:i-1) new_slug];
    all_slugs      = [all_slugs_temp all_slugs(i:end)];
end

end

