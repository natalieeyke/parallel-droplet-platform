function [ all_slugs, remake_flag ] = cwc_slugedit_remake( all_slugs, index )
% Given the all_slugs array and the index of a slug to remake, this script
% does just that

remake_flag = ['Inserted a repeat of slug ' num2str(all_slugs(index).number) ...
    ' as early as possible'];
all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(index));

end

