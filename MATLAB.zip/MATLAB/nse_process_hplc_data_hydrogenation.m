function [all_slugs,data_processing_exit_flag] = nse_process_hplc_data_hydrogenation(data_path, ana_path,all_slugs,analyte_table,ana_slug,optimization_on,reprocessing)
%rvp_process_hplc_data_hydrogenation finds retention times, peak areas, and concentrations for reactants and products
%in analyte table from HPLC chromatogram specified by data_path
%calculates yields and objective function for the asymmetric hydrogenation
%of ketones: yield_1 = enantiomer 1, yield_2 = enantiomer 2, yield = sum of
%enantiomers. This allows optimization of ee in objective function with
%yield criterion to work regardless of exact enantiomer formed.
%logs peak data and concentration of analytes to ana_path

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 23, 2012
% CWC
% June 17, 2015
% LMB
% May 24, 2017
% RvP
% January 29, 2019
% Inputs:  
%               all_slugs is the list of slugs
%               data_path is the file path for the HPLC chromatogram
%               ana_path is the folder path for the data log
%               analyte_table is a array containing analyte information
%               ana_slug is the slug INDEX currently in analysis
%               optimization_on is 1 if an optimization is in progress,
%               otherwise 0
%               reprocessing = 1 , reprocessing: don't remake
%               slugs but mark them incomple if ISTD area is too low or mass balance out of range, otherwise 0 
% Outputs:
%               all_slugs is the updated all_slugs
%               data_processing_exit_flag is a string containing
%               indicating: file read fail, internal standard area fail, success 

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     

% Initialize errors
slug_area_fail = 0;

% Build file name
file_name = [data_path '\REPORT01.xls'];
%file_name = [data_path '\Report01.xls'];
%file_name = ['\\LCMS2-HP\Chem32\1\Data\NSE\asymmetric_hydrogenation 2019-08-31 14-38-46\Report01.xls'];

 

% Check for file. If no file, slug is incomplete
file_read = fopen(file_name);

if file_read == -1
    file_read_fail = 1;
else
    file_read_fail = 0;
end
if file_read_fail == 1
    all_slugs(ana_slug).complete = -1;
    all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
    ret_time = [ ];
    area = [ ];
    conc = [ ];
    data_processing_exit_flag = sprintf('Slug %i:Failed to find HPLC file!',all_slugs(ana_slug).number);
    return
end 

all_slugs(ana_slug).hplc_data_path = data_path; %save file path to all_slugs if it exists


% Read signals from file_name
[values,signals] = xlsread(file_name,'Signal','E2:E100');

% Read signal numbers from file_name
sig_nums = xlsread(file_name,'Signal','N2:N100');

%If chemstation did not export signal numbers in column correctly this column is filled with zeros. 
%Fix: If all signal numbers are zero, assign signal number 1 to first signal, signal number 2 to second signal, ... 
if sum(sig_nums) == 0
    
    for i=1:size(sig_nums,1)
        sig_nums(i)=i;
    end
    
end

% Read peak data from file_name
peak_data = xlsread(file_name,'Peak','D2:P1000');

% Initialize peak_row, the rows of the ret_time and area matrices
peak_row = 0;

% Get internal standard concentration
conc_ISTD = all_slugs(ana_slug).istd_conc;

% Initialize internal standard peak area
area_ISTD = 0;

% Initialize slug_area_fail, which is 1 if internal standard area is
% insufficient
slug_area_fail = 0;


for analyte = analyte_table.analytes
    
    % Get reagent number
    reag_num = analyte.id;
            
        peak_row = peak_row + 1;
        
        % Search for calibration wavelength
        wavelength = analyte.wavelength;
        if wavelength < 10
            wavelength = ['MSD' num2str(wavelength)];
        else
            wavelength = num2str(wavelength);
        end
        
        % Find wavelength in list of signals
        for sig_row = 1:length(sig_nums)
            if isempty(strfind(signals{sig_row},wavelength)) ~= 1;
                break
            end
        end
        
        % Find signal number
        %sig_num = sig_nums(sig_row,1);
        sig_num = sig_row;
        
        % Find minimum residence time
        rt_min = analyte.min_ret_time;
        
        % Find maximum residence time
        rt_max = analyte.max_ret_time;
        
        % Find all peaks between minimum and maximum residence time
        peak_range = find(peak_data(:,8) - rt_min >= 0 & rt_max - peak_data(:,8) >= 0);
        
        % Find peak area and rt. Assume peak is largest peak between rt_min and
        % rt_max measured at the wavelength
        ret_time(peak_row,:) = [reag_num 0];
        area(peak_row,:) = [reag_num 0];
        for peak_num = peak_range'
            
            % Check for right signal
            if peak_data(peak_num,1) == sig_num
                
                % If greater than previous area, accept
                if peak_data(peak_num,11) > area(peak_row,2);
                    ret_time(peak_row,2) = peak_data(peak_num,8);
                    area(peak_row,2) = peak_data(peak_num,11);
                    % If internal standard, store special area
                    if analyte.type == 10 % 10 = I
                        area_ISTD = peak_data(peak_num,11);
                        analyte_ISTD = analyte;
                    end
                end
                
            end
            
        end
        

    

end % end for analyte

if reprocessing == 1    
    optimization_on = 1;        
end

if optimization_on  %only remake rejected slugs if optimization is running
    
    if all_slugs(ana_slug).istd_conc == 0
        data_processing_exit_flag = sprintf('Not remaking Slug %i: Blank slug',all_slugs(ana_slug).number);
        all_slugs(ana_slug).complete = -1;
        return
    end

    % Check for acceptable internal standard area
    if exist('analyte_ISTD')%only check if calibration is given in reagent table
        if area_ISTD < analyte_ISTD.linear_calib %linear calib is simply the minimum istd peak area
            % Reject slug
           
            all_slugs(ana_slug).complete = -1;
            if reprocessing == 0; %don't remake slugs if data is being reprocessed
                all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
            end

            data_processing_exit_flag = sprintf('Remaking Slug %i: ISTD area too low!',all_slugs(ana_slug).number);

            return
        end
        
    else %if no ISTD peak found
        
        
        all_slugs(ana_slug).complete = -1;
        if reprocessing == 0; %don't remake slugs if data is being reprocessed
                all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
        end
     
        data_processing_exit_flag = sprintf('Remaking Slug %i: No ISTD peak found!',all_slugs(ana_slug).number);
        return
        
    end

end %end if optimization_on 




% Calculate concentrations from calibration
peak_row = 0;

for reag_num = area(:,1)'
    
    peak_row = peak_row + 1;    
    row_reag_num = find([analyte_table.analytes.id] == reag_num);
    
    % For non-ISTD case
    if analyte_table.analytes(row_reag_num).type ~= 10 % Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
        if isnan(analyte_table.analytes(row_reag_num).linear_calib) ~= 1 %calculate concentration if calibration is given
            
           conc(peak_row,:) = [reag_num analyte_table.analytes(row_reag_num).linear_calib*area(peak_row,2)*conc_ISTD/area_ISTD];%only linear term
           
           
        end
    else % For ISTD case
        conc(peak_row,:) = [reag_num conc_ISTD]; %conc ISTD in g/L
    end
    
end
%%%

all_slugs(ana_slug).complete = 1;% add if clauses

all_slugs(ana_slug).conversion = 0.001; %avoid nan for log(conversion)
all_slugs(ana_slug).yield_1 = 0.001; %avoid nan for log(yield_1); enantiomer 1
all_slugs(ana_slug).yield_2 = 0.001; %avoid nan for log(yield_2); enantiomer 2
all_slugs(ana_slug).yield = 0.001; %avoid nan for log(yield overall/combined)
all_slugs(ana_slug).objective =  0.001; %avoid nan for log(objective)

%get reactant concentration
react_index = [analyte_table.analytes.type] == 1;% Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
react_id = analyte_table.analytes(react_index).id;
react_conc = conc((conc(:,1) == react_id),2);

%get enantiomer 1 concentration
prod_index = [analyte_table.analytes.type] == 7;% Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
prod_id = analyte_table.analytes(prod_index).id;
product_conc = conc((conc(:,1) == prod_id),2);

%get enantiomer 2 concentration
sideprod_index = [analyte_table.analytes.type] == 8;% Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
sideprod_id = analyte_table.analytes(sideprod_index).id;
sideproduct_conc = conc((conc(:,1) == sideprod_id),2);

%get side product concentration - ELIMINATION PRODUCT FROM �-AMINOKETONE
elimprod_index = [analyte_table.analytes.type] == 9;% Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
elimprod_id = analyte_table.analytes(elimprod_index).id;
elimprod_conc = conc((conc(:,1) == elimprod_id),2);

%conversion calculation
if ~isempty(react_conc)&&~isnan(react_conc)  %check if reactant is defined (in excel)
        
    if all_slugs(ana_slug).reagent_2_conc ~=0 
        all_slugs(ana_slug).conversion =  1 - react_conc / all_slugs(ana_slug).reagent_2_conc; 
       
    end  
    
    if all_slugs(ana_slug).conversion < 0.001
        all_slugs(ana_slug).conversion = 0.001; %avoid negative values for algorithm robustness
    end

end %end if

%product yield calculation - enantiomer 1
if ~isempty(product_conc)&&~isnan(product_conc)  %check if reactant is defined (in excel)
        
    if all_slugs(ana_slug).reagent_2_conc ~=0 
        all_slugs(ana_slug).yield_1 = product_conc / ( all_slugs(ana_slug).reagent_2_conc );         
    end
    
    if all_slugs(ana_slug).yield_1 < 0.001
        all_slugs(ana_slug).yield_1 = 0.001; %avoid nan for log(yield)  %avoid negative values for algorithm robustness
    end

end %end if

%product yield calculation - enantiomer 2
if ~isempty(sideproduct_conc)&&~isnan(sideproduct_conc)  %check if reactant is defined (in excel)
        
    if all_slugs(ana_slug).reagent_2_conc ~=0 
        all_slugs(ana_slug).yield_2 = sideproduct_conc / ( all_slugs(ana_slug).reagent_2_conc );         
    end
    
    if all_slugs(ana_slug).yield_2 < 0.001
        all_slugs(ana_slug).yield_2 = 0.001; %avoid nan for log(yield)  %avoid negative values for algorithm robustness
    end

    
%product yield calculation - elimination product
if ~isempty(elimprod_conc)&&~isnan(elimprod_conc)  %check if reactant is defined (in excel)
        
    if all_slugs(ana_slug).reagent_2_conc ~=0 
        all_slugs(ana_slug).yield_elim = elimprod_conc / ( all_slugs(ana_slug).reagent_2_conc );         
    end
    
    if all_slugs(ana_slug).yield_elim < 0.001
        all_slugs(ana_slug).yield_elim = 0.001; %avoid nan for log(yield)  %avoid negative values for algorithm robustness
    end
    
    
% Add to calculate overall yield

    all_slugs(ana_slug).yield = all_slugs(ana_slug).yield_1 + all_slugs(ana_slug).yield_2;
    
% Calculate mass balance from yields and starting concentration
    
    all_slugs(ana_slug).mb = (all_slugs(ana_slug).yield_1 + all_slugs(ana_slug).yield_2 + all_slugs(ana_slug).yield_elim + (react_conc / all_slugs(ana_slug).reagent_2_conc));
    
end %end if


% Enantiomeric excess calculation
if ~isempty(product_conc)&&~isnan(product_conc)  && ~isempty(sideproduct_conc)&&~isnan(sideproduct_conc)
    
    
    if all_slugs(ana_slug).yield_1 ~=0 || all_slugs(ana_slug).yield_2 ~=0;
        all_slugs(ana_slug).ee =  abs((all_slugs(ana_slug).yield_1 - all_slugs(ana_slug).yield_2)/(all_slugs(ana_slug).yield_1 + all_slugs(ana_slug).yield_2));
        
    end
    
    if all_slugs(ana_slug).yield_1 < 0.001 && all_slugs(ana_slug).yield_2 < 0.001;
        all_slugs(ana_slug).ee= 0.001; %avoid nan for log(ee)  %avoid negative values for algorithm robustness
    end
    
    if all_slugs(ana_slug).ee < 0.001
        all_slugs(ana_slug).ee= 0.001;
    end
    

    all_slugs(ana_slug).objective =log(all_slugs(ana_slug).ee);
    
end




% reject and rerun slug if mass balance is not within 0.9 - 1.1
if optimization_on %only remake rejected slugs if optimization is running
% RvP OVERRIDE TO HAVE MB OUTPUT WHILE TESTING 


    % Check for acceptable mass balance
    
%      
%         if all_slugs(ana_slug).mb < 0.9 || all_slugs(ana_slug).mb > 1.10 %unacceptable mass balance
%             % Reject slug
%             slug_area_fail = 1;
%             all_slugs(ana_slug).complete = -1;
%             if reprocessing == 0; %don't remake slugs if data is being reprocessed
%                 all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
%             end
%             ret_time = [ ];
%             area = [ ];
%             conc = [ ];
%             data_processing_exit_flag = sprintf('Remaking Slug %i: Mass balance not closed!',all_slugs(ana_slug).number);
% 
%             return
%         end
    

end %end if optimization_on 




%log data
if ~isempty(area)  
    
slug_analysis_write_v2(ana_path,data_path,ana_slug,ret_time,area,conc,analyte_table);

end

data_processing_exit_flag = sprintf('Slug %i: Processing successful!',all_slugs(ana_slug).number);

end