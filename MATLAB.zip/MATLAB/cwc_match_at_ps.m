function [all_slugs, rinse_slugs, inj_slug] = cwc_match_at_ps(all_slugs, rinse_slugs, ps_dist, dist_tol)
% this function finds what kind of slug was detected at hplc phase sensor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               rinse_slugs is list of rinse slugs
%               ps_dist is distance to hplc phase sensor
%               dist_tol is the tolerance (uL) for matching
%               
% Outputs:
%               all_slugs is the updated slug list
%               inj_slug is the INDEX of slug in the sample loop
%                     0 if not a reacting slug
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Reacting slug in system
sys_slug = find(cwc_list_property(all_slugs, 'in_system') == 1, 1, 'first');
if sys_slug
    if abs(all_slugs(sys_slug).distance - ps_dist) < dist_tol
        % Update distance with match
        inj_slug = sys_slug;
        all_slugs(sys_slug).distance_matched = ps_dist;
        return
    else
        % Probably just liquid from sample loop leaving upon valve switch
        % TODO: figure out error handling
    end
end

% Rinse slug
sys_slug = find(cwc_list_property(rinse_slugs, 'in_system') == 1, 1, 'first');
if sys_slug
    if abs(rinse_slugs(sys_slug).distance - ps_dist) < dist_tol
        % Update distance with match
        inj_slug = 0;
        rinse_slugs(sys_slug).distance_matched = ps_dist;
        return
    else
        % TODO: figure out error handling
    end
end    

end