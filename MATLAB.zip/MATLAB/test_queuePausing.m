clear
clc
load('C:\Users\Admin\Desktop\20170629_2.mat');
all_slugs(2).complete=-1;
all_slugs(3).complete=-1;
all_slugs(4).complete=-1;
all_slugs(5).complete=1;
%failed slugs in a row
complete_status_slugs = cwc_list_property(all_slugs, 'complete') ;

fail_counter = 0;%initialize
pause_queue = 0;
failed_slug_tolerance=3;
time=1;
queue_pausing_time = 2;

for fail_i = 1:size(complete_status_slugs,1)
if complete_status_slugs(fail_i,1) == -1
fail_counter = fail_counter +1;
else if complete_status_slugs(fail_i,1) == 1
fail_counter = 0; %reset if a slug was completed after slugs failed
end
end
end

if (fail_counter >= failed_slug_tolerance)|| time >= queue_pausing_time*3600
pause_queue =1;
end