function [ index ] = lmb_find_dval_combo( fathomed_dvals , remove_dvals )
%finds a vector remove_dvals  (N_dvalsx1) of discrete variable combos in the matrix fathomed_dvals (N_dvals x N_combos) of fathomed_dvals
% Returns empty index if not found
% returns logical index vector (N_combos x 1) corresponding to combo matrix  

index = [];

if ~isempty(fathomed_dvals)

for i = 1:size(fathomed_dvals,2)
    
    if sum(remove_dvals == fathomed_dvals(:,i))== size(remove_dvals,1) %all elements match
        
        index(1,i) = 1; %combo matches column in fathomed_dvals, mark with 1
        
    else
        
        index(1,i) = 0; %vector does not match, mark with 0
        
    end
     
    
end %end for i 

end %if is empty

index = logical(index); %convert to logical

end

