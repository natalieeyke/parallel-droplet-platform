function [ opt_variables ] = lmb_optimization_define_multi( )
% cwc_optimization_define defines the variables to optimize over, their
% type (continuous/discrete) how they should be scaled, and any other
% relevant information.

% Reagent 1 species
opt_variables(1) = OptVar();
opt_variables(1).label = 'reagent_1'; % species no.
opt_variables(1).type = 'discrete';
opt_variables(1).values = 1:8;
% opt_variables(1).modifies = {'1'; 'temperature'}; % offset and special factor for temperature
opt_variables(1).modifies = {'1'; 'temperature'}; % offset and special factor for temperature

% Reagent 1 species
opt_variables(2) = OptVar();
opt_variables(2).label = 'reagent_2'; % species no.
opt_variables(2).type = 'discrete';
opt_variables(2).values = 9:11;
opt_variables(2).modifies = {'1'}; % offset  


% % Reagent 1 species
% opt_variables(4) = OptVar();
% opt_variables(4).label = 'reagent_3'; % species no.
% opt_variables(4).type = 'discrete';
% opt_variables(4).values = 5;
% opt_variables(4).modifies = {'1';'residence_time_goal'}; % offset and special factor for temperature
% % opt_variables(2).modifies = {'1'; 'temperature'};

% Reaction time
opt_variables(3) = OptVar();
opt_variables(3).label = 'residence_time_goal'; % s
opt_variables(3).type = 'continuous';
opt_variables(3).map = @(x) log(x);
opt_variables(3).min = 60 ;
opt_variables(3).max = 600;

% % Temperature
opt_variables(4) = OptVar();
opt_variables(4).label = 'temperature'; % deg C
opt_variables(4).type = 'continuous';
opt_variables(4).map = @(x) 1 ./ (x + 273.15);
opt_variables(4).min = 30; 
opt_variables(4).max = 110;
% 

% Reagent 1 concentration
opt_variables(5) = OptVar();
opt_variables(5).label = 'reagent_1_conc'; % M
opt_variables(5).type = 'continuous';
opt_variables(5).map = @(x) log(x);
opt_variables(5).min = 0.835 / 1000;
opt_variables(5).max = 4.175 / 1000;



% % Reagent 1 species
% opt_variables(5) = OptVar();
% opt_variables(5).label = 'reagent_2'; % species no.
% opt_variables(5).type = 'discrete';
% opt_variables(5).values = 1:2;
% opt_variables(5).modifies = {'1'; 'temperature'}; % offset and special factor for temperature
% 



end