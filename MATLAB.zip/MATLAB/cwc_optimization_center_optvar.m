function [ slug ] = cwc_optimization_center_optvar( slug, opt_variables )
% cwc_optimization_center_optvar takes a slug and assigns the center-point
% values for each optimization variable (and the first possible discrete)

for opt_var = opt_variables
    if strcmp(opt_var.type, 'continuous')
        eval(['slug.' opt_var.label ' = ' num2str(opt_var.unscale_pm1(0)) ';']); %matlab reads expression inside eval() as code, assigns decoded center value of continuous variable 
    else
        eval(['slug.' opt_var.label ' = ' num2str(opt_var.values(1)) ';']);
    end
end

end
