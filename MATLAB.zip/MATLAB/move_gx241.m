function [New_XY, New_Z] = move_gx241(RackID, PlaceID, SampleID)
% move_gx241 finds X/Y/Z coordinates to move GX-241 liquid handler robot to

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC 2-23-2015
% Determines X/Y/Z coordinates for a given rack, place, and sample #
% Inputs:
%               RackID is the Gilson rack #
%               PlaceID is the position of the rack (1 left, 2 right)
%               SampleID is the sample vial number
% Outputs:
%               New_XY is the position to move the liquid handler
%               to in "X_pos/Y_pos"
%               New_Z is the position of the bottom of the vial
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (PlaceID ~= 1) && (PlaceID ~= 2)
    error('Invalid rack placement number')
end

% Do for Rack 335S
if  or(RackID == 350, RackID == 351) || RackID == 352
    % Measure rows and columns displacement from sample 10
    % Sample 10 (corner) is at X91/42.5
    
    % (closest to home location)
%     if ( (SampleID ~= 35) && (SampleID ~= 36) && (SampleID > 30) ) || (SampleID < 1)  % 35, 36 these positions because they provide good mixing
    if  (SampleID > 30) || (SampleID < 1)  
      
        error('Invalid sample number')  
    end

    % Rack is 10 rows tall
    rack_col = floor((SampleID - 1) / 10);
    % Rack is 4 columns wide
    rack_row = 9 - mod(SampleID - 1, 10);

    % Define coordinates based on sample 12 and displacement (in mm)
    % (using X8.5/40 as 12 and X62/40 as 48 and X62/244 as 37)
%     X_pos = roundn(91   + rack_col * (72)/3, -1); %before 2018/21/11
     X_pos = roundn(94   + rack_col * (72)/3, -1);
%     Y_pos = roundn(42.5 + rack_row * (190.8)/8, -1);
    Y_pos = roundn(44.5 + rack_row * (190.8)/8, -1); %9/20/2018 shifted coordinate to the right by 2 mm
    
    if RackID == 350 % flat bottom
        Z_pos = 53; 
    elseif RackID == 351 % conical bottom
        Z_pos = 60; %   58 prior to 5/23/2018   , 56.5 prior to 5/14/2018
    elseif RackID == 352 
        Z_pos = 65; % conical bottom with 7 to 9 mm magnetic stir bar
    end
    
elseif RackID == 346
    % Measure rows and columns displacement from sample 11
    % (closest to home location)
    if (SampleID > 44) || (SampleID < 1) 
        error('Invalid sample number')
    end
    
    % Rack is 11 rows tall
    rack_col = floor((SampleID - 1) / 11);
    % Rack is 4 columns wide
    rack_row = 10 - mod(SampleID - 1, 11);
    
    % Define coordinates based on sample 11 and displacement (in mm)
    % (using X8/42.5 as 11 and X61.5/42.5 as 44 and X61.5/241.5 as 34)

    X_pos = roundn(8    + rack_col * (61.5 - 8)/3, -1); 
    Y_pos = roundn(42.5 + rack_row * (241.5 - 42.5)/10, -1); 
    Z_pos = 13.7; % bottom of tall, round-bottom vials when touching bottom
    % 17.5 is Z_pos when arm is @ 125 mm
        
else
    error('Unknown RackID')
end

% Add offset for rack placement
if (PlaceID == 2)
   X_pos = X_pos + 92.5; 
end

% Convert to a string (with only one decimal)
X_str = sprintf('%.1f', X_pos);
Y_str = sprintf('%.1f', Y_pos);
New_Z = sprintf('%.1f', Z_pos);
New_XY = [X_str '/' Y_str];
    
end

