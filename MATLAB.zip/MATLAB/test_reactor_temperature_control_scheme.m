% Get the index for the next reaction along with its start time, temperature, and residence time
if ~isempty(reactor_10_rxns)
     reactor_10_done = 0;
     reactor_10_reaction = reactor_10_rxns(1);
     reactor_10_start_time = reactors_start_times(10, reactor_10_current_reaction);
     reactor_10_temperature_C = all_slugs(reactor_10_current_reaction).temperature;
     reactor_10_res_time = all_slugs(reactor_10_current_reaction).residence_time_goal;
     % convert temperature to degF and string for Watlow
     reactor_10_current_temperature_F = num2str((reactor_10_current_temperature_C * 1.8) + 32);
else
     reactor_10_done = 1;
end