function [] = cwc_save_slug_data_v2(all_slugs,time,v1,T,T_set,slug_path,status_path,system_path)
% records info on slugs, slug status, and system status at first iteration
% v2 allows multistep reaction recording

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
% October 28, 2015
%
% Inputs:
%               all_slugs is the list of slugs
%               time is the current time (in sec)
%               v1 is the carrier phase flow rate (in uL/min)
%               T is the measured reactor temperature (in deg C)
%               T_set is the reactor set point temperature (in deg C)
%               slug_path is the file path for the list of slugs
%               status_path is the file path for status of slugs in
%               automated system
%               system_path is the file path for system information
%               (temperatures, flowrates)
% Outputs:
%               None
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid1 = -1;
fid2 = -1;
fid3 = -1;

while fid1 < 0
    
    % Load list of slugs
    fid1 = fopen(slug_path,'a');
    
    if fid1 < 0
        fclose('all');
    end
    
end

% Write header
fprintf(fid1,'@%6.1f s --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\r\n', time);
fprintf(fid1,' Slug # | Reagent 1  Conc (M) | Reagent 2  Conc (M) | Reagent 3  Conc (M) | Reagent 4  Conc (M) | Reagent 4  Conc (M) |Makeup | Slug Vol (uL) | Base Vol (uL) | Quench Vol (uL) | Temp (deg C) | Res Time (s) \r\n');
fprintf(fid1,'----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\r\n');

% Loop for all slugs
for i = 1:length(all_slugs)
    num = all_slugs(i).number;
    r1 = all_slugs(i).reagent_1;
    c1 = all_slugs(i).reagent_1_conc;
    r2 = all_slugs(i).reagent_2;
    c2 = all_slugs(i).reagent_2_conc;
    r3 = all_slugs(i).reagent_3;
    c3 = all_slugs(i).reagent_3_conc;
    r4 = all_slugs(i).reagent_4;
    c4 = all_slugs(i).reagent_4_conc;
    r5 = all_slugs(i).reagent_5;
    c5 = all_slugs(i).reagent_5_conc;
    mk = all_slugs(i).makeup;
    vol = all_slugs(i).current_vol;
    base = regexprep(num2str(all_slugs(i).base_vol), '\s+', '; ');
    qu = all_slugs(i).quench_vol;
    temp = regexprep(num2str(all_slugs(i).temperature), '\s+', '; ');
    rt = regexprep(num2str(all_slugs(i).residence_time_goal), '\s+', '; ');
    
    % Write to file
    fprintf(fid1,'%6.0f  |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f  |    %6.1f     |    %s     |     %6.3f      |    %s    |   %s \r\n',num,r1,c1,r2,c2,r3,c3,r4,c4,r5,c5,mk,vol,base,qu,temp,rt);    
end

% Close list of slugs
fclose(fid1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while fid2 < 0
    
    % Load slug status
    fid2 = fopen(status_path,'a');
    
    if fid2 < 0
        fclose('all');
    end
    
end

% Write header
fprintf(fid2,'@%6.1f s -------------------------------------------------------------------------------------------------------------------------------------------\r\n', time);
fprintf(fid2,' Slug # | In Preparation | Injected into System | Injected into HPLC | Completed | Distance Traveled (uL) | Time in Reactor (s) | Analysis Time (s) \r\n');
fprintf(fid2,'----------------------------------------------------------------------------------------------------------------------------------------------------\r\n');

% Loop for all slugs
for i = 1:length(all_slugs)
    num = all_slugs(i).number;
    prep = all_slugs(i).in_prep;
    if prep == 1
        prep = sprintf('Yes');
    else
        prep = sprintf('No ');
    end
    sys = all_slugs(i).in_system;
    if sys == 1
        sys = sprintf('Yes');
    else
        sys = sprintf('No ');
    end
    lc = all_slugs(i).in_hplc;
    if lc == 1
        lc = sprintf('Yes');
    else
        lc = sprintf('No ');
    end
    comp = all_slugs(i).complete;
    if comp == 1
        comp = sprintf('Yes');
    else
        comp = sprintf('No ');
    end
    dis = all_slugs(i).distance;
    react = regexprep(num2str(all_slugs(i).residence_time_actual), '\s+', '; ');
    ana = all_slugs(i).analysis_time;
    
    % Write to file
    fprintf(fid2,'%6.0f  |      %s       |         %s          |        %s         |    %s    |         %6.1f         |       %s        |      %6.1f       \r\n',num,prep,sys,lc,comp,dis,react,ana);    
end

% Close slug status list
fclose(fid2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while fid3 < 0
    
    % Load system data
    fid3 = fopen(system_path,'a');
    
    if fid3 < 0
        fclose('all');
    end
    
end

% Write to file
fprintf(fid3,'  %6.1f  |           %6.3f           |       %6.1f        |        %6.1f         \r\n',time,v1,T,T_set);

% Close system status list
fclose(fid3);

end