function [ cvals_opts, b_opts, yield_opts, dvals_combos,cval_yield_opts ] = ...
    lmb_optimization_estimate_max( T, T2, opt_vars, lin, ...
                                         fathomed_dvals, removed_dvals, ...
                                       yield_criterion )
% cwc_kwg_optimization_estimate_max finds the optimal conditions that
% maximize the objective function given the current response surface and
% certain constraints.
% lmb: adapted for multiple discrete variables, added output of continuous
% variables for yield optimum

% T: response surface coeff for objective function
% T2: response surface coeff for yield
% opt_vars: variables to optimize over
% lin: if the model is linear or quadratic
% removed_dvals: sets of discrete variables whose parameters are removed
% fathomed_dvals: sets of fathomed discrete variables
% yield_criterion: nonlinear constraint on yield

% cvals_opts: N_cv x (number of discrete var combinations)
% b_opts: 1 x (number of discrete var combinations)
% yield_opts: 1 x (number of discrete var combinations)
% dvals_combos: N_dv x (number of discrete var combinations)

% Build initialization for cvals based on median of CVs
cvals_0 = [];
lb = [];
ub = [];
for opt_var = opt_vars
    % What is the type? 
    if strcmp(opt_var.type, 'continuous') % continuous
        % Need to append that scaled condition then
        cvals_0 = [cvals_0; (opt_var.min + opt_var.max) / 2]; % def.
        lb = [lb; opt_var.min];
        ub = [ub; opt_var.max];
    end
end

fr_dvals = [removed_dvals, fathomed_dvals];

% Initialize
dvals_combos = cwc_optimization_get_dvals_combos( opt_vars, fr_dvals );
cvals_opts = zeros(length(cvals_0), size(dvals_combos, 2)); 
b_opts = zeros(1, size(dvals_combos, 2)); 
yield_opts = zeros(1, size(dvals_combos,2));

% Estimate maximum yield for each discrete variable value
for i = 1:size(dvals_combos,2)
    dvals = dvals_combos(:, i);
    
    X_opt = @(cvals) lmb_optimization_cvals_to_X(cvals, dvals, opt_vars, lin,removed_dvals); %create model matrix without removed discrete variables
    obj_fun_yield = @(cvals) - dot(X_opt(cvals), T2); % yield
    
    tol = 1e-20; % default
    A = []; b = []; Aeq = []; beq = []; nonlcon = [];
    options = optimoptions('fmincon', 'TolFun', tol, 'TolX', tol, ...
                           'TolCon', tol, 'Display', 'None');
    
    [cval_yield_opt, y_opt] = fmincon(obj_fun_yield, cvals_0, A, b, Aeq, beq, ...
                         lb, ub, nonlcon, options);
                     
    cval_yield_opts(:,i) = cval_yield_opt;
    yield_opts(i) = - y_opt;
end %for

% Global maximum yield
max_yield = max(yield_opts);

   % Nonlinear constraint on yield
    function [c, ceq] =  nonlcon_general(cvals, X_opt_func) 
        c =  - dot( X_opt_func(cvals), T2) + ( log(yield_criterion) + max_yield );
        ceq = [];
    end

disp(['optimizing objective function for ' num2str(size(dvals_combos, 2)) ' dval combos'])
for i = 1:size(dvals_combos, 2)
    dvals = dvals_combos(:, i);
    
    X_opt = @(cvals) lmb_optimization_cvals_to_X(cvals, dvals, opt_vars, lin,removed_dvals);
    
    % Objective function
    obj_fun = @(cvals) - dot(X_opt(cvals), T); % TON
    
    % Nonlinear constraint on yield
   nonlcon = @(cvals) nonlcon_general(cvals, X_opt);
   
    % Solve
    [cvals_opt, b_opt] = fmincon(obj_fun, cvals_0, A, b, Aeq, beq, lb, ub, nonlcon, options);
    
    % Update
    cvals_opts(:, i) = cvals_opt;
    b_opts(i)= - b_opt;
end
end