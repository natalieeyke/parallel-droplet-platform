function [all_slugs, ana_slug] = cwc_mark_slug_analysis_complete(all_slugs, ana_time)
% marks slug analysis as complete

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs list of slugs
%               ana_time is the total analysis required (in seconds)
% Outputs:
%               updated all_slugs
%               ana_slug is the INDEX of the slug that just finished
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ana_slug = find(cwc_list_property(all_slugs, 'in_hplc') == 1, 1, 'first');

if ana_slug
    if all_slugs(ana_slug).analysis_time >= ana_time
        all_slugs(ana_slug).in_hplc = 0;
        return
    end
    ana_slug = 0; % analysis not done
else
    ana_slug = 0;
end

end