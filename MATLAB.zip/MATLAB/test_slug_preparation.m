clc
clear
%May 19th 2017

reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_test.xlsx';
inj_vol = 15; %sample loop volume in �L
rho_tf = 786.0; %transfer fluid density in g/L

% reagent_table lists all reagents in the system
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
all_slugs.base_vol = 0;

%  [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,inj_vol,rho_tf);
 [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4_dilution_adjustment(all_slugs,reagent_table,inj_vol,rho_tf);
 
 comp_undiluted = comp;
 all_slugs_undiluted = all_slugs;
 
 
%May 19th 2017

% reagent_table lists all reagents in the system
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
all_slugs.base_vol = 3.5;

%  [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,inj_vol,rho_tf);
 [prep_slug,comp,all_slugs] = cwc_get_next_slug_to_prep_v4_dilution_adjustment(all_slugs,reagent_table,inj_vol,rho_tf);
 
 comp_diluted = comp;
 
 
 
 why