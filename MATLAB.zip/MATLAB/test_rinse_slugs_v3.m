clear
clc
rinse_slugs = [];
new_vol = 15;
time_prior = 10;
time = 50;
v1= 6000;
v1_react = 60;
all_slugs = [];

[rinse_slugs] = cwc_add_rinse_slug(rinse_slugs, new_vol);
[rinse_slugs] = cwc_add_rinse_slug(rinse_slugs, new_vol);

[all_slugs, rinse_slugs] = cwc_update_distances_v3(all_slugs, rinse_slugs, time_prior, time, v1, v1_react);

rinse_vol_limit = 20000;
[rinse_slugs] = cwc_add_rinse_slug(rinse_slugs, new_vol);

[rinse_slugs, rinse_flag] =     lmb_update_rinse_status(rinse_slugs,rinse_vol_limit);

why
