function [quench_inj_vol] = cwc_get_quench_inj_vol(all_slugs,quench_inj_slug)
% updates slug properties as needed when injected into system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slug objects
%               quench_inj_slug is the INDEX assigned to the slug
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get quench volume
quench_inj_vol = all_slugs(quench_inj_slug).quench_vol;

end