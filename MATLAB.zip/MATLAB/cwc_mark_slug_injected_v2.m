function [all_slugs] = cwc_mark_slug_injected_v2(all_slugs,prep_slug,vol)
% updates slug properties as needed when injected into system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slug objects
%               prep_slug is the INDEX assigned to the slug
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set attributes as necessary
all_slugs(prep_slug).injected = 1;
all_slugs(prep_slug).in_system = 1;
all_slugs(prep_slug).in_prep = 0;
all_slugs(prep_slug).current_vol = vol;

end