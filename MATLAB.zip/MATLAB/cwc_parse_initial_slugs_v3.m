function [all_slugs] = cwc_parse_initial_slugs_v3(reagent_table_path)
% generate list of slugs
% v2 allows multi-step chemistry with base injections in uL
% v3 allows multi-step chemistry with multiple quench injections instead
%    note: input is checked so that if multiple residence times are
%    specified, then the number of base XOR quench injections must match

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% June 17, 2015
% October 28, 2015
% January 21, 2016
%
% Input:
%           reagent_table_path is a .xlsx file containing reagent
%           information and intial slug compositions
% Outputs:
%           all_slugs is a list of slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load initial slugs
[init_comp, txt, raw] = xlsread(reagent_table_path,'Initial Slugs','A2:Q100');

if ~isempty(init_comp) % Are any slugs defined?
    
    % Remove empty rows (reagent A undefined)
    init_comp(isnan(init_comp(:, 2)), :) = [];
    
    % Generate initial slug tracker
    N_rows = length(init_comp(:,1));
    all_slugs = [];
    
    % Fix number of columns (in case last columns are NaN)
    if size(init_comp, 2) < 17
        init_comp_temp = init_comp;
        init_comp = nan(N_rows, 17);
        init_comp(:, 1:size(init_comp_temp, 2)) = init_comp_temp;
    end
    
    for row = 1:N_rows
        
        new_slug = Slug_v2();
        
        % Slug number
        new_slug.number = init_comp(row,1);
        
        % Reagent 1 Type
        new_slug.reagent_1 = init_comp(row,2);
        
        % Reagent 1 Concentration
        new_slug.reagent_1_conc = init_comp(row,3);
        
        % Reagent 2 Type
        new_slug.reagent_2 = init_comp(row,4);
        
        % Reagent 2 Concentration
        new_slug.reagent_2_conc = init_comp(row,5);
        
        % Reagent 3 Type
        new_slug.reagent_3 = init_comp(row,6);
        
        % Reagent 3 Concentration
        new_slug.reagent_3_conc = init_comp(row,7);
        
        % Reagent 4 Type
        new_slug.reagent_4 = init_comp(row,8);
        
        % Reagent 4 Concentration
        new_slug.reagent_4_conc = init_comp(row,9);
        
        % Reagent 5 Type
        new_slug.reagent_5 = init_comp(row,10);
        
        % Reagent 5 Concentration
        new_slug.reagent_5_conc = init_comp(row,11);
        
        % Makeup Type
        new_slug.makeup = init_comp(row,12);
        
        % Slug Volume
        new_slug.prepared_vol = init_comp(row,13);
        
        % Base Volume(s)
        if ~isnan(init_comp(row, 14)) % single online injection
            new_slug.base_vol = init_comp(row,14);
            new_slug.inj_base = 0;
        else % multiple online injections
            new_slug.base_vol = str2double(strsplit(raw{row, 14}, ';'));
            new_slug.inj_base = zeros(size(new_slug.base_vol));
        end
        
        % Quench vol
        if ~isnan(init_comp(row, 15)) % single quench injection
            new_slug.quench_vol = init_comp(row,15);
            new_slug.inj_quench = 0;
        else % multiple quench injections
            new_slug.quench_vol = str2double(strsplit(raw{row, 15}, ';'));
            new_slug.inj_quench = zeros(size(new_slug.quench_vol));
        end
        
        % Temperature
        if ~isnan(init_comp(row, 16)) % single step
            new_slug.temperature = init_comp(row,16);
        else % multiple steps
            new_slug.temperature = str2double(strsplit(raw{row, 16}, ';'));
        end
        
        % Residence Time
        if ~isnan(init_comp(row, 17)) % single step
            new_slug.residence_time_goal = init_comp(row,17);
            new_slug.residence_time_actual = 0;
        else % multiple steps
            new_slug.residence_time_goal = str2double(strsplit(raw{row, 17}, ';'));
            new_slug.residence_time_actual = zeros(size(new_slug.residence_time_goal));
        end
        
        % Check for validity of multi-step definition before adding to list
        if and(length(new_slug.base_vol) > 1, ...
               length(new_slug.quench_vol) > 1)
           continue % can't have both > 1
        end
        multi = length(new_slug.temperature) > 1;
        multi_base = and(length(new_slug.base_vol) == length(new_slug.temperature), ...
               length(new_slug.base_vol) == length(new_slug.residence_time_goal));
        multi_quench = and(length(new_slug.quench_vol) == length(new_slug.temperature), ...
               length(new_slug.quench_vol) == length(new_slug.residence_time_goal));
        if multi % multi step
            if xor(multi_base, multi_quench) % must match lengths
                all_slugs = [all_slugs new_slug];
            end
        else % single step
            if and(multi_base, multi_quench) % everything must have len==1
                all_slugs = [all_slugs new_slug];
            end
        end
        
    end % for row = 1:N_rows
    
else
    
    all_slugs = [];
    
end

end