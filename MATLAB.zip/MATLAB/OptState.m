classdef OptState
    % Optimization tracks the state of an optimization
    
    properties
        lin = [];
        percent_improve = [];
        N_extra = [];
        yield_criterion = [];
        tol = [];
        patience = [];
        buffer = [];
        counter_i = [];
        not_improving = [];
        prev_best_b = [];
        fathomed_dvals = [];
        removed_dvals = [];
        opt_done = [];
        opt_variables = [];
        FFD_type = [];
        iteration_counter = 0; % records all_slugs (complete and incomplete) indices everytime new experiments are added (before they are added) and at the end of the optimization
        best_obj_b = []; %predicted objective function optimum  as slug
        best_slug_y = []; %predicted yield optimum as slug
        best_obj_b_str = ''; %predicted objective function optimum  as string
        best_slug_y_str = ''; %predicted yield optimum as string


       
        
    end
    
    methods
    end
    
end

