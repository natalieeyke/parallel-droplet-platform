function [rinse_slugs, rinse_flag] =     lmb_update_rinse_status(rinse_slugs,rinse_vol_limit)
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LMB
% April 4, 2018
%
% Inputs:
%            
%               rinse_slugs are current rinse slugsrinse_vol_limit in �L for rinse slugs to be marked as out
%               of the system
% Outputs:
%               updated rinse_slugs
%               rinse_flag is string with current rinse slug status 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rinse_flag = 'No rinse slugs in system';

% Update rinse slugs
for i = 1:length(rinse_slugs)

    
    if and(rinse_slugs(i).complete == 0, rinse_slugs(i).distance > rinse_vol_limit)
        rinse_slugs(i).in_system = 0;
        rinse_slugs(i).in_reactor = 0;
        rinse_slugs(i).complete = 1;
    end
    
end

%Construct rinse slug status string

if  sum(cwc_list_property(rinse_slugs, 'in_system'));
    
    min_rinse_vol = round(min(cwc_list_property(rinse_slugs,'distance'))); %remaining rinse volume in �L
    rinse_flag = sprintf('Rinsed volume: %i �L of %i �L',min_rinse_vol,round(rinse_vol_limit));
    
end



end