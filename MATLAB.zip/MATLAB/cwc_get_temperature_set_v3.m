function [T_set] = cwc_get_temperature_set_v3(all_slugs)
% finds the correct temperature setpoint
% v2 allows for multistep reactions at inlet
% v3 allows for multitep reactions anywhere

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% October 26, 2015
%
% Inputs:
%               all_slugs is the list of slugs
% Outputs:
%               T_set is the reactor set point temperature (in deg C)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set default
T_set = 0;

% Find the slug index of the last slug to exit the reactor
last_done_slug_num = find(cwc_list_property(all_slugs, 'injected') == 1 & ...
                cwc_list_property(all_slugs, 'inj_quench') == 1, 1, 'last');

% Get next one            
if isempty(last_done_slug_num)
    slug_num = 1;
else
    slug_num = last_done_slug_num + 1;
end

% If we are done, set to zero
if slug_num > length(all_slugs)
    T_set = 0;
    return
end

% Is this a single-step reaction?
if length(all_slugs(slug_num).residence_time_goal) == 1
    T_set = all_slugs(slug_num).temperature(1);
    return
else
    % Check how many steps have been completed
    done_steps = find(all_slugs(slug_num).multi_injected == 1, 1, 'last');
    if isempty(done_steps)
        done_steps = 0;
    end
    if done_steps >= length(all_slugs(slug_num).temperature)
        T_set = 0; % weird, what is going on?
        return
    end
    T_set = all_slugs(slug_num).temperature(done_steps + 1);
    return
end

end