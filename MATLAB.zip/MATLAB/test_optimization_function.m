load('C:\Users\Admin\Documents\Optimization\Optimization 20170722\_07-23-2017_02-22_750min')



incomplete_slugs = cwc_list_property(all_slugs, 'complete') == 0;
opt_done = 0;
update_optimization_prompt = 0;

% Do we need to add slugs now?
if not(any(incomplete_slugs))
    
    % Add the next round
    [ all_slugs, opt_state, output_prompt ] = ...
        cwc_kwg_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);

     update_optimization_prompt = 1;

end

opt_done = opt_state.opt_done;

why