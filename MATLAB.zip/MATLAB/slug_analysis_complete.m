function [slug_tracker,ana_slug,ana_slug_prior] = slug_analysis_complete(slug_tracker_prior,ana_time,report_time)
% SLUG_ANALYSIS_COMPLETE identifies slug which has finished HPLC analysis
% and is ready for data processing in slug_area.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 25, 2012
% CWC
% June 17, 2015
%
% Inputs:
%               slug_tracker_prior is the current slug_tracker matrix
%               ana_time is the time required for LC analysis (in min)
%               report_time is the time to wait before looking for the
%               report (in sec)
% Outputs:
%               slug_tracker is the updated slug_tracker matrix
%               ana_slug is the slug which has completed analysis and is 0
%               if no slug has completed analysis.
%               ana_slug_prior is the last slug to complete analysis
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Define index labels
index = slug_get_index();

% Find slug number index
col_num = find(strcmp(deblank(index),'Slug #') == 1);

% Find slug in prep index
col_prep = find(strcmp(deblank(index),'In Prep') == 1);

% Find residence time index
col_rt = find(strcmp(deblank(index),'Res Time') == 1);

% Find match distance index
col_match = find(strcmp(deblank(index),'Match Dis') == 1);

% Find volume at HPLC phase sensor index
col_vol_lc = find(strcmp(deblank(index),'HPLC Vol') == 1);

% Find injected into HPLC column
col_lc = find(strcmp(deblank(index),'Inject LC') == 1);

% Find analysis time index
col_ana = find(strcmp(deblank(index),'Analysis') == 1);

% Find completed index
col_com = find(strcmp(deblank(index),'Complete') == 1);

% Find first slug which has not been completed
slug_num = find(slug_tracker_prior(:,col_com) == 0,1,'first');

if isempty(slug_num) ~= 1
    
    % Determine if the lead slug has surpassed analysis time (in min) +
    % report wait time
    if slug_tracker_prior(slug_num,col_ana) >= ana_time*60 + report_time 
        ana_slug = slug_tracker_prior(slug_num,col_num);
        ana_slug_prior = ana_slug;
    else
        ana_slug = 0;
        if isempty(find(slug_tracker_prior(:,col_com) == 1,1,'last')) ~= 1
            ana_slug_prior = slug_tracker_prior(find(slug_tracker_prior(:,col_com) == 1,1,'last'),col_num);
        else
            ana_slug_prior = 0;
        end
    end
    
else
    
    ana_slug = 0;
    if isempty(find(slug_tracker_prior(:,col_com) == 1,1,'last')) ~= 1
        ana_slug_prior = slug_tracker_prior(find(slug_tracker_prior(:,col_com) == 1,1,'last'),col_num);
    else
        ana_slug_prior = 0;
    end
    
end

% Update slug_tracker
slug_tracker = slug_tracker_prior;

end