function [ all_slugs_new  ] = lmb_dvals_remove(all_slugs, opt_variables, remove_dvals)
% Removes experiments associated with the fathomed dval selection a


% Find experiments where this discrete set was used
if ~isempty(remove_dvals)
    
         
    remove = [];
    for slug = all_slugs
        dvals = [];
        for opt_var = opt_variables
            if strcmp(opt_var.type, 'discrete')
                dvals = [dvals, eval(['slug.' opt_var.label])];
            end %if
        end


        % If all discrete values match, this exp should be removed
        if all(dvals == remove_dvals')
            remove = [remove, 1];
        else
            remove = [remove, 0];
        end
    end
    
    all_slugs_new = all_slugs(~remove);%~ :negates boulean 
    
else
    all_slugs_new = all_slugs;        

end
%don't edit opt_var, we are keeping track of fathomed and removed discrete
%variable combos with removed_dvals and fathomed_dvals

  


end