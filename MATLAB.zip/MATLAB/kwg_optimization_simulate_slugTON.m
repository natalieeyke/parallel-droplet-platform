function [ slug ] = kwg_optimization_simulate_slugTON( slug, noise )

% Test Case 1

temp = slug.temperature;
time = slug.residence_time_goal;
c_cat = slug.reagent_1_conc;

switch slug.reagent_1
    case 1
        Eai = 0;
    case 2
        Eai = 0.3;
    case 3
        Eai = 0.3;
    case 4
        Eai = 0.7;
    case 5
        Eai = 0.7;
    case 6
        Eai = 2.2;
    case 7
        Eai = 3.8;
    case 8
        Eai = 7.3;     
end
Ar = 3.1 * 10^7; % L^.5 mol^-1.5 s^-1
Ear = 55; % kJ/mol
kR = c_cat^0.5 * Ar * exp(- 1000 * (Ear + Eai) / (8.3145 * (temp + 273.15)));

% concs (A, B, prod)
c0 = [0.167; 0.25; 0];

% Original Rate
rate = @(c) kR * c(1) * c(2);

odefun = @(t, c) [-rate(c); -rate(c); +rate(c)];
tspan = [0 time];
[~, cs] = ode15s(odefun, tspan, c0);

c_r = cs(end, 3); % final concentration

noise_percent = (- noise + 2 * noise * rand(1));
c_r = c_r * (1 + noise_percent); % noise = 0.5% simulates HPLC precision

yield = c_r / 0.167;

if yield < 0.001
    yield = 0.001;
end

TON = yield * 0.167 / c_cat; % includes noise
if TON < 0.001
    TON = 0.001;
end

slug.yield = yield;
slug.residence_time_actual = slug.residence_time_goal;
slug.objective = log(TON);

slug.complete = 1;
end