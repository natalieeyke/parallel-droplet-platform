function [all_slugs] = cwc_match_at_quench_ps_knownslug(all_slugs, ps_dist, sys_slug)
% this function finds what kind of slug was detected at hplc phase sensor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               rinse_slugs is list of rinse slugs
%               ps_dist is distance to hplc phase sensor
%               dist_tol is the tolerance (uL) for matching
%               
% Outputs:
%               all_slugs is the updated slug list
%               inj_slug is the INDEX of slug in the sample loop
%                     0 if not a reacting slug
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_slugs(sys_slug).distance_matched = ps_dist;
% Record that we are done with the reactor
all_slugs(sys_slug).in_reactor = 0;

end