function [ all_slugs_new, opt_variables_new ] = kwg_dvals_remove(all_slugs, opt_variables, remove_dvals)
% Removes experiments associated with the fathomed dval selection and their
% parameters

% Find experiments where this discrete set was used
remove = [];
for slug = all_slugs
    dvals = [];
    for opt_var = opt_variables
        if strcmp(opt_var.type, 'discrete')
            dvals = [dvals, eval(['slug.' opt_var.label])];
        end %if
    end
    
    % If all discrete values match, this exp should be removed
    if all(dvals == remove_dvals')
        remove = [remove, 1];
    else
        remove = [remove, 0];
    end
end

opt_variables_new = opt_variables;
for j = 1:length(opt_variables_new)
    if strcmp(opt_variables_new(j).type, 'discrete')
        opt_variables_new(j).values = opt_variables_new(j).values( ... 
            opt_variables_new(j).values ~= intersect( opt_variables_new(j).values,remove_dvals) ); %find intersection of values and variables to be removed
    end
end %for

%don't edit opt_var, we are keeping track of fathomed and removed discrete
%variable combos with removed_dvals and fathomed_dvals

% opt_variables_new = opt_variables; 
% for j = 1:length(opt_variables_new)
%     if strcmp(opt_variables_new(j).type, 'discrete')
%         opt_variables_new(j).values = opt_variables_new(j).values( ... 
%             opt_variables_new(j).values ~= intersect( opt_variables_new(j).values,remove_dvals) ); %find intersection of values and variables to be removed
%     end
% end %for

% Remove with *temporary variables first*: change all_slugs
all_slugs_new = all_slugs(~remove);%~ :negates boulean 

end