function [reagent_table,reagent_table_index] = load_reagent_table(reagent_table_path)
% LOAD_REAGENT_TABLE loads a table of reagents from an Excel file to be used
%   as reference for the automated liquid handling system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   
%   BJR
%   January 17, 2012
%   CWC
%   June 17, 2015
%
%   Input:
%           reagent_table_path is a .xlsx file containing reagent
%           information
%   Output:
%           reagent_table is a matrix containing information in
%           reagent_table_path
%           reagent_table_index gives the header rows for reagent_table
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load xlsx file
[num,txt,raw] = xlsread(reagent_table_path,'Reagent List','A1:Z200');

% Remove empty columns
[N_row,N_col] = size(txt);
reagent_table = num(1:N_row-1,1:N_col);

% Index is header row
reagent_table_index = txt(1,:);

% Find reagent types. Replace letters with values as follows:
% A = 1, B = 2, C = 3, M = 4, P = 5, X = 6, R = 7, S = 8, I = 9, W = 10
col_type = find(strncmp(deblank(reagent_table_index),'Type',4) == 1);
reagent_table_index(1,col_type) = cellstr('Type');
for row = 1:N_row - 1
    if strncmpi(txt(row + 1,col_type),'A',1) == 1
        reagent_table(row,col_type) = 1;
    elseif strncmpi(txt(row + 1,col_type),'B',1) == 1
        reagent_table(row,col_type) = 2;
    elseif strncmpi(txt(row + 1,col_type),'C',1) == 1
        reagent_table(row,col_type) = 3;
    elseif strncmpi(txt(row + 1,col_type),'M',1) == 1
        reagent_table(row,col_type) = 4;
    elseif strncmpi(txt(row + 1,col_type),'P',1) == 1
        reagent_table(row,col_type) = 5;
    elseif strncmpi(txt(row + 1,col_type),'X',1) == 1
        reagent_table(row,col_type) = 6;
    elseif strncmpi(txt(row + 1,col_type),'R',1) == 1
        reagent_table(row,col_type) = 7;
    elseif strncmpi(txt(row + 1,col_type),'S',1) == 1
        reagent_table(row,col_type) = 8;
    elseif strncmpi(txt(row + 1,col_type),'I',1) == 1
        reagent_table(row,col_type) = 9;
    elseif strncmpi(txt(row + 1,col_type),'W',1) == 1
        reagent_table(row,col_type) = 10;
    elseif strncmpi(txt(row + 1,col_type),'D',1) == 1
        reagent_table(row,col_type) = 11;
    end
end

% Find calibrate and substitute 'Y' for 1
col_calyn = find(strncmp(deblank(reagent_table_index),'Calibrate',9) == 1);
for row = 1:N_row-1
    if strncmpi(txt(row + 1,col_calyn),'Y',1) == 1
        reagent_table(row,col_calyn) = 1;
    else
        reagent_table(row,col_calyn) = 0;
    end
end

% Find reagent names and remove column
col_name = find(strncmp(deblank(reagent_table_index),'Reagent Name',12) == 1);
reagent_table = [reagent_table(:,1:col_name - 1) reagent_table(:,col_name + 1:end)];
reagent_table_index = [reagent_table_index(:,1:col_name - 1) reagent_table_index(:,col_name + 1:end)];

% Find ISTD conc and substitute 0 for NaN
col_istd = find(strncmp(deblank(reagent_table_index),'ISTD Conc',9) == 1);
for row = 1:N_row-1
    if isnan(reagent_table(row,col_istd)) == 1
        reagent_table(row,col_istd) = 0;
    end
end

end

