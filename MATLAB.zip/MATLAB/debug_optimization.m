clear
clc

%%
%initialize
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20180916 optimization.xlsx';
 

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
% Get definition of param space from Matlab descript
[ opt_state ] = cwc_optimization_define_v3();

% Use the first slug in all_slugs as a template for the D-opt design
[ all_slugs ] = lmb_optimization_generate_ffd_v2( all_slugs, opt_state );


why