clear 
close all

%inputs test


reagent_table_path = 'C:\Users\Parallel Oscillator\Documents\Parallel LabVIEW\Input\TS_kinetic_expts.xlsx';
r1_enabled = 0;
r2_enabled = 0;
r3_enabled = 0;
r4_enabled = 1;
r5_enabled = 1;
r6_enabled = 1;
r7_enabled = 0;
r8_enabled = 1;
r9_enabled = 0;
r10_enabled = 0;


master_time = 15000;
tau_prep = 480;
tau_loop_to_reactor = 125;
tau_rinse_vent_transfer_lines = 175;

tau_rinse_vent_reactor = 215;
tau_reactor_to_analysis = 140;
tau_analysis = 600;

%labview code

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

% slug_tracker is the matrix of slug information
% index identifies the information contained in each column of slug_tracker 

N_reactors = 0;
enabled_reactors_list = [];
if r1_enabled
    enabled_reactors_list = [enabled_reactors_list 1];
    N_reactors = N_reactors + 1;
end
if r2_enabled
    enabled_reactors_list = [enabled_reactors_list 2];
    N_reactors = N_reactors + 1;
end
if r3_enabled
    enabled_reactors_list = [enabled_reactors_list 3];
    N_reactors = N_reactors + 1;
end
if r4_enabled
    enabled_reactors_list = [enabled_reactors_list 4];
    N_reactors = N_reactors + 1;
end
if r5_enabled
    enabled_reactors_list = [enabled_reactors_list 5];
    N_reactors = N_reactors + 1;
end
if r6_enabled
    enabled_reactors_list = [enabled_reactors_list 6];
    N_reactors = N_reactors + 1;
end
if r7_enabled
    enabled_reactors_list = [enabled_reactors_list 7];
    N_reactors = N_reactors + 1;
end
if r8_enabled
    enabled_reactors_list = [enabled_reactors_list 8];
    N_reactors = N_reactors + 1;
end
if r9_enabled
    enabled_reactors_list = [enabled_reactors_list 9];
    N_reactors = N_reactors + 1;
end
if r10_enabled
    enabled_reactors_list = [enabled_reactors_list 10];
    N_reactors = N_reactors + 1;
end
[all_slugs] = nse_parse_initial_slugs_parallel_v7(reagent_table_path, N_reactors, enabled_reactors_list);


[liquid_handler_start_times, loop_to_reactor_start_times, rinse_transfer_lines_start_times, reactor_to_analysis_start_times, rinse_reactor_start_times, analysis_start_times, reactors_start_times] = nse_scheduler_v3(all_slugs, 10, tau_prep, tau_loop_to_reactor, tau_rinse_vent_transfer_lines, tau_rinse_vent_reactor, tau_reactor_to_analysis, tau_analysis)

