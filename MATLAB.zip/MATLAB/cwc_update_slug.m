function [ all_slugs ] = cwc_update_slug(all_slugs, cur_slug)
% Takes a slug object and replaces the corresponding entry in all_slugs
% to avoid aliasing issues

for i = 1:length(all_slugs)
    if all_slugs(i).number == cur_slug.number
        all_slugs(i) = cur_slug;
    end
end

end

