function [all_slugs,data_processing_exit_flag] = lmb_process_hplc_data_buchwald(data_path, ana_path,all_slugs,analyte_table,ana_slug,optimization_on,reprocessing)
%lmb_process_hplc_data_suzuki finds retention times, peak areas, and concentrations for reactants and products
%in in analyte table from HPLC chromatogram specified by data_path
%calculates yield and objective function for the buchwald coupling with
%preoxidated catalysts
%logs peak data and concentration of analytes to ana_path

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 23, 2012
% CWC
% June 17, 2015
% LMB
% May 24, 2017
% Inputs:  
%               all_slugs is the list of slugs
%               data_path is the file path for the HPLC chromatogram
%               ana_path is the folder path for the data log
%               analyte_table is a array containing analyte information
%               ana_slug is the slug INDEX currently in analysis
%               optimization_on is 1 if an optimization is in progress,
%               otherwise 0
%               reprocessing = 1 , reprocessing: don't remake
%               slugs but mark them incomple if ISTD area is too low, otherwise 0 
% Outputs:
%               all_slugs is the updated all_slugs
%               data_processing_exit_flag is a string containing
%               indicating: file read fail, internal standard area fail, success 

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     

% Initialize errors
slug_area_fail = 0;

% Build file name
file_name = [data_path '\REPORT01.xls'];

 

% Check for file. If no file, slug is incomplete
file_read = fopen(file_name);

if file_read == -1
    file_read_fail = 1;
else
    file_read_fail = 0;
end
if file_read_fail == 1
    all_slugs(ana_slug).complete = -1;
    %all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
    ret_time = [ ];
    area = [ ];
    conc = [ ];
    data_processing_exit_flag = sprintf('Slug %i:Failed to find HPLC file!',all_slugs(ana_slug).number);
    return
end 

all_slugs(ana_slug).hplc_data_path = data_path; %save file path to all_slugs if it exists


% Read signals from file_name
[values,signals] = xlsread(file_name,'Signal','E2:E100');

% Read signal numbers from file_name
sig_nums = xlsread(file_name,'Signal','N2:N100');

%If chemstation did not export signal numbers in column correctly this column is filled with zeros. 
%Fix: If all signal numbers are zero, assign signal number 1 to first signal, signal number 2 to second signal, ... 
if sum(sig_nums) == 0
    
    for i=1:size(sig_nums,1)
        sig_nums(i)=i;
    end
    
end

% Read peak data from file_name
peak_data = xlsread(file_name,'Peak','D2:P1000');

% Initialize peak_row, the rows of the ret_time and area matrices
peak_row = 0;

% Get internal standard concentration
conc_ISTD = all_slugs(ana_slug).istd_conc;

% Initialize internal standard peak area
area_ISTD = 0;

% Initialize slug_area_fail, which is 1 if internal standard area is
% insufficient
slug_area_fail = 0;


for analyte = analyte_table.analytes
    
    % Get reagent number
    reag_num = analyte.id;
            
        peak_row = peak_row + 1;
        
        % Search for calibration wavelength
        wavelength = analyte.wavelength;
        if wavelength < 10
            wavelength = ['MSD' num2str(wavelength)];
        else
            wavelength = num2str(wavelength);
        end
        
        % Find wavelength in list of signals
        for sig_row = 1:length(sig_nums)
            if isempty(strfind(signals{sig_row},wavelength)) ~= 1;
                break
            end
        end
        
        % Find signal number
        %sig_num = sig_nums(sig_row,1);
        sig_num = sig_row;
        
        % Find minimum residence time
        rt_min = analyte.min_ret_time;
        
        % Find maximum residence time
        rt_max = analyte.max_ret_time;
        
        % Find all peaks between minimum and maximum residence time
        peak_range = find(peak_data(:,8) - rt_min >= 0 & rt_max - peak_data(:,8) >= 0);
        
        % Find peak area and rt. Assume peak is largest peak between rt_min and
        % rt_max measured at the wavelength
        ret_time(peak_row,:) = [reag_num 0];
        area(peak_row,:) = [reag_num 0];
        for peak_num = peak_range'
            
            % Check for right signal
            if peak_data(peak_num,1) == sig_num
                
                % If greater than previous area, accept
                if peak_data(peak_num,11) > area(peak_row,2);
                    ret_time(peak_row,2) = peak_data(peak_num,8);
                    area(peak_row,2) = peak_data(peak_num,11);
                    % If internal standard, store special area
                    if analyte.type == 10 % 10 = I
                        area_ISTD = peak_data(peak_num,11);
                        analyte_ISTD = analyte;
                    end
                end
                
            end
            
        end
        

    

end % end for analyte

if reprocessing == 1    
    optimization_on = 1;        
end

if optimization_on %only remake rejected slugs if optimization is running

    % Check for acceptable internal standard area
    if exist('analyte_ISTD')%only check if calibration is given in reagent table
        if area_ISTD < analyte_ISTD.linear_calib %linear calib is simply the minimum istd peak area
            % Reject slug
            slug_area_fail = 1;
            all_slugs(ana_slug).complete = -1;
            if reprocessing == 0; %don't remake slugs if data is being reprocessed
                all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
            end
            ret_time = [ ];
            area = [ ];
            conc = [ ];
            data_processing_exit_flag = sprintf('Remaking Slug %i: ISTD area too low!',all_slugs(ana_slug).number);

            return
        end
        
    else %if no ISTD peak found
        
        slug_area_fail = 1;
        all_slugs(ana_slug).complete = -1;
        if reprocessing == 0; %don't remake slugs if data is being reprocessed
                all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
        end
        ret_time = [ ];
        area = [ ];
        conc = [ ];
        data_processing_exit_flag = sprintf('Remaking Slug %i: No ISTD peak found!',all_slugs(ana_slug).number);
        return
        
    end

end %end if optimization_on 




% Calculate concentrations from calibration
peak_row = 0;

for reag_num = area(:,1)'
    
    peak_row = peak_row + 1;    
    row_reag_num = find([analyte_table.analytes.id] == reag_num);
    
    % For non-ISTD case
    if analyte_table.analytes(row_reag_num).type ~= 10 % Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
        if isnan(analyte_table.analytes(row_reag_num).linear_calib) ~= 1 %calculate concentration if calibration is given
            
           conc(peak_row,:) = [reag_num analyte_table.analytes(row_reag_num).linear_calib*area(peak_row,2)*conc_ISTD/area_ISTD];%only linear term
           
           
        end
    else % For ISTD case
        conc(peak_row,:) = [reag_num conc_ISTD]; %conc ISTD in g/L
    end
    
end
%%%

all_slugs(ana_slug).complete = 1;% add if clauses



all_slugs(ana_slug).yield = 0.001; %avoid nan for log(yield)
all_slugs(ana_slug).objective =  log(all_slugs(ana_slug).yield);

%get product concentration
prod_index = [analyte_table.analytes.type] == 5;% Type code %['ABCMPXRSTIWD']); %A=1, B=2, C=3, M=4, P=5, X=6, R=7, S=8, T=9, I =10
prod_id = analyte_table.analytes(prod_index).id;
product_conc = conc((conc(:,1) == prod_id),2);



if ~isempty(product_conc)&&~isnan(product_conc)  
        
    if all_slugs(ana_slug).reagent_1_conc ~=0 && product_conc ~=0
        all_slugs(ana_slug).yield = product_conc / ( all_slugs(ana_slug).reagent_1_conc + all_slugs(ana_slug).reagent_4_conc ); %catalst is preoxidized with halide 
        all_slugs(ana_slug).objective = log(all_slugs(ana_slug).yield); %optimize for yield
    end
    
    if all_slugs(ana_slug).yield < 0.001
        all_slugs(ana_slug).yield = 0.001; %avoid nan for log(yield)
        all_slugs(ana_slug).objective =  log(all_slugs(ana_slug).yield);
    end
    
      

end %end if


%reject and rerun slug if yield is too high
if optimization_on %only remake rejected slugs if optimization is running

    % Check for acceptable product yield
    
        if all_slugs(ana_slug).yield > 1.05 %unphysical yield
            % Reject slug
            slug_area_fail = 1;
            all_slugs(ana_slug).complete = -1;
            if reprocessing == 0; %don't remake slugs if data is being reprocessed
                all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(ana_slug));
            end
            ret_time = [ ];
            area = [ ];
            conc = [ ];
            data_processing_exit_flag = sprintf('Remaking Slug %i: Yield is too high!',all_slugs(ana_slug).number);
% 
            return
        end
    

end %end if optimization_on 




%log data
if ~isempty(area)  
    
slug_analysis_write_v2(ana_path,data_path,ana_slug,ret_time,area,conc,analyte_table);

end

data_processing_exit_flag = sprintf('Slug %i: Processing successful!',all_slugs(ana_slug).number);

end