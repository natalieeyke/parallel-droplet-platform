function [ labels ] = cwc_optimization_slugs_to_dval_labels( all_slugs, opt_vars )
% cwc_optimization_slugs_to_dval_labels converts all_slugs to a cell array
% containing a short label (e.g., "1") for experiments based on their
% discrete variable. This is useful for graphing.

labels = {};
i = 0;
for slug = all_slugs
    i = i + 1;
    for opt_var = opt_vars
        % What is the type? 
        if strcmp(opt_var.type, 'discrete') 
            % Need to convert exp. condition to index
            discrete_x = eval(['slug.' opt_var.label ';']);
            one_hot = opt_var.one_hot(discrete_x);
            if length(labels) < i
                labels{i} = num2str(find(one_hot));
            else
                labels{i} = [labels{i} ',' num2str(find(one_hot))];
            end
        end
    end
end

end