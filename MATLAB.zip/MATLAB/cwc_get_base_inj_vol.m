function [base_inj_vol] = cwc_get_base_inj_vol(all_slugs,base_inj_slug)
% get volume to inject into system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slug objects
%               base_inj_slug is the INDEX assigned to the slug
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get base volume
base_inj_vol = all_slugs(base_inj_slug).base_vol;

end