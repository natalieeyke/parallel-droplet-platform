classdef Slug
    % Slug describes a slug in the system
    
    properties
        number = 0;
        reagent_1 = 0;
        reagent_1_conc = 0;
        reagent_2 = 0;
        reagent_2_conc = 0;
        reagent_3 = 0;
        reagent_3_conc = 0;
        reagent_4 = 0;
        reagent_4_conc = 0;
        reagent_5 = 0;
        reagent_5_conc = 0;
        makeup = 0;
        prepared_vol = 0;
        injected_vol = 0;
        current_vol = 0;
        base_conc = 0;
        base_vol = 0;
        quench_vol = 0;
        temperature = 0;
        residence_time_goal = 0;
        residence_time_actual = 0;
        istd_conc = 0;
        in_prep = 0;
        in_system = 0;
        injected = 0;
        in_reactor = 0;
        in_hplc = 0;
        distance = 0;
        distance_matched = 0;
        inj_base = 0;
        inj_quench = 0;
        analysis_time = 0;
        complete = 0;
        objective = 0;
        yield = 0;
    end
    
    methods
    end
    
end

