function [v1, fill_vol1, refill_hold, refill_now] = cwc_check_refill_needed_simple( ...
    all_slugs, rinse_slugs, time_prior_v1, time, v1_prior, fill_vol1_prior, refill_hold_prior)
% checks to see if a refill is needed, based on refilling every 4 slugs
% v2 lets refills occur when rinse slugs in system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% August 7, 2015
%
% Inputs:
%               all_slugs and rinse_slugs are lists of slugs
%               time_prior_v1 is the last time v1 the syringe volume was updated (in s)
%               time is the current time (in s)
%               v1_prior is the current carrier phase flow rate (in uL/min)
%               fill_vol1_prior is the current liquid volume in carrier syringe (in mL)
% Outputs:
%               slug_tracker is the updated slug_tracker matrix
%               v1 is the carrier phase flow rate (in uL/min)
%               fill_vol1 is the updated liquid volume in carrier syringe (in mL)
%               refill_hold is 1 if no more slugs should be injected into system before refill, 0 otherwise
%               refill is 1 if refill should start, 0 otherwise
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Update fill volume (in mL)
fill_vol1 = fill_vol1_prior - v1_prior*(time - time_prior_v1)/(60*1000);

% Set default
refill_hold = 0;
refill_now = 0;
v1 = v1_prior;

% Check if refill is needed (EVERY FOUR SLUGS)
if refill_hold_prior == 1 
    refill_hold = 1;
else
   sys_slug = find(cwc_list_property(all_slugs, 'in_system') == 1);
   if and(mod(sys_slug, 3) == 0, fill_vol1 < 7)
       refill_hold = 1;
   elseif fill_vol1 < 2 % new
       refill_hold = 1;
   end
end



% Check if refill should start now
if refill_hold == 1
    if sum(cwc_list_property(all_slugs, 'in_system')) == 0 
        refill_now = 1;
        v1 = 0;
    end
end

end