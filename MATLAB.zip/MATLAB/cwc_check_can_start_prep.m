function [start_prep,prep_flag] = cwc_check_can_start_prep(all_slugs,refill_hold)
% checks if it's okay to start preparing the next slug. need the previous
% one to have been quenched already

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% February 28, 2013
% CWC
% July 7, 2015
% 
% Inputs:
%               slug_tracker_prior is the current slug_tracker matrix
%               V2 is the volume of reactor (in uL)
%               refill_hold is 1 if no more slugs should be injected into system before refill, 0 otherwise
% Outputs:
%               start_prep is 1 if slug preparation can begin, 0 otherwise
%               prep_flag denotes restriction for slug being prepared, if
%               any
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find first slug which has not been injected into system
i = find(cwc_list_property(all_slugs, 'injected') == 0, 1, 'first');

if ~isempty(i)
    
% NOTE: INJECTING RINSE SLUGS NOW CHECKS IF THE SYS IS EMPTY
%     % Find any slugs in the the reactor (back and forth section)
%     sys_slug = find(cwc_list_property(all_slugs, 'in_system') == 1, 1, 'first');
%     if sys_slug
%         if all_slugs(sys_slug).inj_quench == 0
%             start_prep = 0;
%             prep_flag = 'Need current slug to be quenched first';
%             return
%         end
%     end
    
    if refill_hold >= 1
        start_prep = 0;
        prep_flag = 'System Holding for Refill';
    else
        % If all requirements are met, start prep
        start_prep = 1;
        prep_flag = 'Okay To Begin Preparing Next Slug';
    end
else
    start_prep = 0;
    prep_flag = 'All Slugs Have Been Injected';
end 

end