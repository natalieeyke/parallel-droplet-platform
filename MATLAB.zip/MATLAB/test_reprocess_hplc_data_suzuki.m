clear
clc

load('C:\Users\Admin\Documents\Autosave\Optimization 20180907\_09-07-2018_21-55_105min.mat')
%

%inputs
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20170919.xlsx';
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20180907 optimization.xlsx';

ana_path = 'C:\Users\Admin\Desktop\log\ana_path';
stamp = '20170524test.txt';
ana_path = [ana_path stamp]; %add date/time


% reagent_table lists all reagents in the system
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);
analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);


rinse_slugs = [];


inj_vol = 15; %15 �l
rho_tf = 800;
ana_time = 6;
warmup_time = 15;
time = 1;

ana_path = [ana_path stamp]; %add date/time and .txt-file extension


%from labview

[all_slugs,analyte_table,counter_yield_changes] =...
 lmb_reprocess_slugs(ana_path,all_slugs,reagent_table_path,ana_time...
,warmup_time);

reprocess_slugs_status = ['Reprocessed data @ ' sprintf('%0.1fs', time) '- yield changes:' sprintf('%i',counter_yield_changes)];


why

