clear
clc

%%
%initialize
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20180430.xlsx';

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);
autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-01-2018_18-09_15min';
%autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-01-2018_12-14_285min'; %630
% autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-02-2018_07-05_240min'; %630
% autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-01-2018_18-09_30min'; 
load(autosave_path) 

%all_slugs = all_slugs(1:46);

%%
%optimization


opt_done = 0;
update_optimization_prompt = 0;



while 1
    % Add the next round
    [ all_slugs, opt_state, output_prompt ] =  lmb_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);

     update_optimization_prompt = 1;

     
end

opt_done = opt_state.opt_done;


why