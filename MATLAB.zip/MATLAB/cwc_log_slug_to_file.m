function cwc_log_slug_to_file(slug, logs_hplc, reagent_table)
% Create a permanent record of the conditions for each injected slug

    function v = val_to_rep(v)
        if isnumeric(v)
            v = num2str(v);
        elseif iscell(v)
            v = strjoin(cellstr(v), '; ');
        else
            v = mat2str(v);
        end 
    end

timeinj = datestr(datetime('now'),'yyyy-mmm-dd HH-MM-ss');
hplc_fname = [logs_hplc timeinj '.tdf'];

if slug.reagent_1_conc
   slug.reagent_1 = reagent_table.find_by_id(slug.reagent_1).name; 
else
    slug.reagent_1 = '';
    slug.reagent_1_conc = '';
end

if slug.reagent_2_conc
   slug.reagent_2 = reagent_table.find_by_id(slug.reagent_2).name; 
else
    slug.reagent_2 = '';
    slug.reagent_2_conc = '';
end

if slug.reagent_3_conc
   slug.reagent_3 = reagent_table.find_by_id(slug.reagent_3).name; 
else
    slug.reagent_3 = '';
    slug.reagent_3_conc = '';
end

if slug.reagent_4_conc
   slug.reagent_4 = reagent_table.find_by_id(slug.reagent_4).name; 
else
    slug.reagent_4 = '';
    slug.reagent_4_conc = '';
end

if slug.reagent_5_conc
   slug.reagent_5 = reagent_table.find_by_id(slug.reagent_5).name; 
else
    slug.reagent_5 = '';
    slug.reagent_5_conc = '';
end

slug.makeup = reagent_table.find_by_id(slug.makeup).name; 

fid = fopen(hplc_fname, 'w');
fprintf(fid, 'Slug injected at %s \r\n', timeinj);

fields = fieldnames(slug);
for j = 1:length(fields)
    header = cwc_prettify_header(fields{j});
    value = val_to_rep(slug.(fields{j}));
    
    fprintf(fid, '%20s \t %15s \r\n', header, value);
end

fclose(fid);

end

