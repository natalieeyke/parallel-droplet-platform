clear
clc

%%
%initialize
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20180430.xlsx';

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-02-2018_07-05_345min';
% autosave_path = 'C:\Users\Admin\Documents\Autosave\Optimization 20180430\_05-01-2018_19-22_630min.mat'; %630
 
load(autosave_path) 



%reset
all_slugs_old = all_slugs;
opt_state.opt_variables(1, 2).values = [6,7,9,11];
all_slugs = all_slugs(1:36);
opt_state.buffer =3; % on removal of experiments after fathoming
opt_state.counter_i = 0; % initialize
opt_state.not_improving = 0; % initialize
opt_state.prev_best_b = -Inf; % initialize
opt_state.fathomed_dvals = []; % initialize
opt_state.removed_dvals = []; % initialize
opt_state.prev_best_b =  -0.5051;
iteration_counter = [1 28];





%%
%optimization


opt_done = 0;
update_optimization_prompt = 0;



while 1
    % Add the next round
    [ all_slugs, opt_state, output_prompt ] =  lmb_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);

     update_optimization_prompt = 1;

     
end

opt_done = opt_state.opt_done;


why