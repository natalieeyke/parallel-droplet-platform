classdef RinseSlug
    % RinseSlug describes a slug in the system
    
    properties
        in_system = 0;
        in_reactor = 0;
        current_volume = 0;
        distance = -240;
        distance_matched = 0;
        complete = 0;
    end
    
    methods
    end
    
end

