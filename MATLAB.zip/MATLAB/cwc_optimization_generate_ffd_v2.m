function [ all_slugs ] = cwc_optimization_generate_ffd_v2( all_slugs, opt_state )
% cwc_optimization_generate_ffd generates a fractional factorial design
% based on the various variables that are being optimized

% NOTE: all_slugs must be defined so that the first slug corresponds to
% the default/fixed values of all variables not found in the optimization
% *before* that slug has been prepared (i.e., right after parsing)

%Read optimization parameters
opt_variables = opt_state.opt_variables;
FFD_type = opt_state.FFD_type;
lin = opt_state.lin;
N_extra = opt_state.N_extra;

% Parameter defaults: QUADRATIC AND N_extra = 2
if nargin < 2
    lin = false; % whether to use linear or quadratic response
    N_extra = 2; % buffer used in D-opt design; num experiments - num params
end


%% Prepare
% Initialize
if isempty(all_slugs)
    error('First slug must be defined (with all default/fixed values)')
end
all_slugs = all_slugs(1);

% Read conditions of optimization
num_opt_variables = length(opt_variables);

%% Generate design
switch FFD_type
    
    case 'full'
        num_experiments = 1;
        for i = 1:num_opt_variables
            % Continuous variables default to two levels (min and max)
            if strcmp(opt_variables(i).type, 'continuous')
                num_experiments = num_experiments * 2;
                
                all_slugs_new = [all_slugs all_slugs]; % duplicate
                n = length(all_slugs);
                for k = 1:n
                    eval(['all_slugs_new(k).' opt_variables(i).label ' = opt_variables(i).min ;']);
                    eval(['all_slugs_new(k + n).' opt_variables(i).label ' = opt_variables(i).max ;']);
                end
                
                
            % Discrete variables have number of levels as defined elsewhere
            elseif strcmp(opt_variables(i).type, 'discrete')
                nlevels = length(opt_variables(i).values);
                num_experiments = num_experiments * nlevels;
                
                all_slugs_new = [];
                n = length(all_slugs);
                for j = 1:nlevels
                    all_slugs_new = [all_slugs_new all_slugs];
                    for k = 1:n
                        eval(['all_slugs_new(n * (j - 1) + k).' opt_variables(i).label ' = opt_variables(i).values(j) ;']);
                    end
                end
            end
            
            % Save
            all_slugs = all_slugs_new;
            
        end
        
    case 'minquad'
        slug = all_slugs; % template slug
        all_slugs = [];
        
        % Divide up opt_variables
        continuous = cellfun(@(x) strcmp(x, 'continuous'), {opt_variables.type});
        opt_variables_continuous = opt_variables(continuous);
        discrete = cellfun(@(x) strcmp(x, 'discrete'), {opt_variables.type});
        opt_variables_discrete = opt_variables(discrete);
        N_cv = length(opt_variables_continuous);
        N_dv_combos = prod(cellfun(@(x) length(x), {opt_variables_discrete.values}));
        num_params = length(cwc_optimization_slugs_to_quadmat([all_slugs], opt_variables));
        
        % Full centroid design
        centroid = ccdesign(N_cv, 'fraction', 0, 'center', N_dv_combos, 'type', 'inscribed');
        discrete_counter = 1;
        discrete_val_counter = 1;
        for i = 1:size(centroid, 1)
            new_slug = slug; % copy template
            
            % Assign continuous variable values according to centroid
            for j = 1:size(centroid, 2)
                eval(['new_slug.' opt_variables_continuous(j).label ' = ' ...
                    num2str(opt_variables_continuous(j).unscale_pm1(centroid(i, j))) ';']);
            end
            
            % Assign discrete variables
            if all(centroid(i, :) == 0) % center
                eval(['new_slug.' opt_variables_discrete(discrete_counter).label ...
                    ' = ' num2str(opt_variables_discrete(discrete_counter).values(discrete_val_counter)) ';']);
                if discrete_val_counter == length(opt_variables_discrete(discrete_counter).values)
                    % done with this discrete var
                    discrete_val_counter = 1;
                    discrete_counter = discrete_counter + 1;
                else
                    % same var, next value
                    discrete_val_counter = discrete_val_counter + 1;
                end
            else % not in the center
                % give random discrete variable values
                for opt_var = opt_variables_discrete
                    choices = randperm(length(opt_var.values));
                    eval(['new_slug.' opt_var.label ' = ' ...
                        num2str(opt_var.values(choices(1))) ';']);
                end
            end
            all_slugs = [all_slugs, new_slug];
        end        
        
    case 'd_opt' % CURRENT MODEL
        slug = all_slugs; % template slug
        all_slugs = []; % initialize
        
        % Divide up opt_variables
        continuous = cellfun(@(x) strcmp(x, 'continuous'), {opt_variables.type});
        opt_variables_continuous = opt_variables(continuous);
        
        discrete = cellfun(@(x) strcmp(x, 'discrete'), {opt_variables.type});
        opt_variables_discrete = opt_variables(discrete);
        
        N_cv = length(opt_variables_continuous);
        N_dv_combos = prod(cellfun(@(x) length(x), {opt_variables_discrete.values}));
        
        if lin
            num_params = length(cwc_optimization_slugs_to_linmat(slug, opt_variables));
        else
            num_params = length(cwc_optimization_slugs_to_quadmat(slug, opt_variables));
        end
        
        % Create list of slugs for fixed dv set
        N = 11; % # of initial experimental conditions, must be > 1
        ffd = fullfact(N * ones(N_cv, 1)); % many leveled factorial design
        all_slugs = repmat(slug, 1, size(ffd, 1));
        
        % Assign continuous vars
        for i = 1:length(opt_variables_continuous);
            vals = opt_variables_continuous(i).min + (0:(N-1))/(N-1) * ...
                  (opt_variables_continuous(i).max - ...
                   opt_variables_continuous(i).min);
               
            label = opt_variables_continuous(i).label;
            is_residence_time = strcmp(label, 'residence_time_goal');
            
            for j = 1:length(all_slugs)
                eval(['all_slugs(j).' label ' = vals(ffd(j, i));']);
                if is_residence_time
                    all_slugs(j).residence_time_actual = vals(ffd(j, i));
                end
            end
        end
        
        % Assign all discrete values
        all_slugs = repmat(all_slugs, 1, N_dv_combos);
        m = 1; % initialize
        for i = 1:length(opt_variables_discrete)
            for j = 1:length(opt_variables_discrete(i).values)
                for k = 1:size(ffd, 1)
                    eval(['all_slugs(m).' opt_variables_discrete(i).label ...
                          ' = opt_variables_discrete(i).values(j);']);
                    m = m + 1;
                end
            end
        end
        
        % Choose the best ones
        if lin
            X = cwc_optimization_slugs_to_linmat(all_slugs, opt_variables);
        else
            X = cwc_optimization_slugs_to_quadmat(all_slugs, opt_variables);
        end
            
        disp(['generated ' num2str(size(X, 1)) ' options...'])
        % maxiter doesn't appear to affect N_exp needed or accuracy
        R = candexch(X, num_params + N_extra, 'display', 'on', 'maxiter', 40);
        disp(['chose best ' num2str(length(R)) ' options'])
        all_slugs = all_slugs(R);
        
    otherwise
        error('Can only do full or minquad right now')
end

% Randomize order
all_slugs = all_slugs(randperm(length(all_slugs)));

%% Finish
% Change slug_nums to be unique, reset residence time
for i = 1:length(all_slugs)
    all_slugs(i).residence_time_actual = 0; 
    all_slugs(i).number = i;
end

end