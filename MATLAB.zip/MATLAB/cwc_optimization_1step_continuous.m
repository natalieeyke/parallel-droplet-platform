function [all_slugs, optimizer, done] = cwc_optimization_1step_continuous(all_slugs, optimizer)
% this function finds what kind of slug was detected at hplc phase sensor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% January 27, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               
% Outputs:
%               all_slugs is the updated slug list, with 0 or more slugs
%                     appended
%               done is a 1 if we have converged
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Is this the first time running the function?
if ~optimizer
    optimizer = Optimizer();
    
    % Variables involved in the optimization
    optimize_over = { ...
        {'reagent_1_conc'; [0.02, 0.08]};
        {'reagent_2_conc'; [0.02, 0.08]};
        {'temperature'; [30, 140]}};
end

% Default
done = false;

% Check if we need a FFD to start still?
if ~optimizer.generated_ffd
    
    
    return
end

% Look for completed slugs
completed_slugs = length(find(cwc_list_property(all_slugs, 'complete') == 1));
remaining_slugs = length(find(cwc_list_property(all_slugs, 'complete') == 0));

% How many are left? We always want *1* remaining
if remaining_slugs > 1
    return
    
end