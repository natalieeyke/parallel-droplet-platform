load('C:\Users\Admin\Documents\Autosave\Optimization 20180907\_09-07-2018_21-55_105min.mat')
%load('C:\Users\Admin\Desktop\2.8.2017.mat')
%data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\LMB_Suzuki 2017-03-03 13-32-41\002-NV-no Sample Name.D';
%data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\Autoimporttest\Suzuki FBP calibration 2016-12-30 13-00-14\021-63-120816-FBP-1.D';
%ana_slug =1;
%ana_slug=2;


g_objective_suzuki(slug_tracker,reagent_table,reagent_table_index,ana_slug,area,conc);