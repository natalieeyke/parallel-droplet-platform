clear
clc
close all


%% First initialization

% Initialize variables
v1 = 0; % uL/min
v1_react = 0; % uL/min
time_prior_v1 = 0;
hold_sys = 0;
hold_sys2 = 0;
refill_hold = 0;
refill_now = 0;
prep_flag = '';
fill_min2 = 0; % mL
fill_min3 = 0; % mL
T = 25; % deg C
T_tol = 0; % deg C
T_set = 0; % deg C
quench_inj_vol = -1;
react_slug = 0;
residence_time_goal = 0;
skip_quench_inj = 0;
base_inj_vol = 0;
slug_in_reactor = 0;
slug_in_prep = 0;
rinse_in_sys = 0;
slug_in_analysis = 0;
fill_vol1 = 0;

%% Reset values and load reagent table

% reagent_table lists all reagents in the system
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20181020 LH test.xlsx';

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

% slug_tracker is the matrix of slug information
% index identifies the information contained in each column of slug_tracker 
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);

all_slugs(1)=[]; %erase blank
rinse_slugs = [];

%Set reactor volumes from front panel
V1 = 53.0; % Entrance volume [ul]
V2 = 225.0; % Reactor volume [ul] 
V3 = 57.0; % Post-reactor volume [ul]

%Set logging filepaths
timestamp = datestr(now, '_mm-dd-yyyy_HH-MM');
stamp = [timestamp '.txt'];
slug_path = 'C:\Users\Admin\Desktop\log\slug_path';
status_path = 'C:\Users\Admin\Desktop\log\status_path';
system_path = 'C:\Users\Admin\Desktop\log\system_path';
matlab_path = 'C:\Users\Admin\Desktop\log\labview';


%% Promt for optimization

% Left button

% Get definition of param space from Matlab descript
%intialize with default values and completed optimization status
%create opt_state object so we can save automatically
[ opt_state ] = cwc_no_optimization_default();  

% Right button

% Get definition of param space from Matlab descript
%     [ opt_state ] = cwc_optimization_define_v4();

% Use the first slug in all_slugs as a template for the D-opt design
%     [ all_slugs ] = lmb_optimization_generate_ffd_v2( all_slugs, opt_state );

% Center button
% 
%     load(optim_backup);
%     for i =1:length(all_slugs)
%         if any([all_slugs(i).in_system, all_slugs(i).in_prep, ...
%                 all_slugs(i).in_reactor])
%             all_slugs(i).residence_time_actual = zeros(size(all_slugs(i).residence_time_goal));
%             all_slugs(i).in_system = 0;
%             all_slugs(i).in_prep = 0;
%             all_slugs(i).in_reactor = 0;
%             all_slugs(i).in_hplc = 0;
%             all_slugs(i).distance = 0;
%             all_slugs(i).complete = 0;
%             all_slugs(i).injected = 0;
%             all_slugs(i).distance_matched = 0;
%             all_slugs(i).inj_base = 0;
%             all_slugs(i).inj_quench = 0;
%         end
%     end

%% Main Loops

% Liquid handler is idle

% Identify slug and list status as in prep

% Check whether slug can be started
paused_queue = 0;
inj_vol = 15; % LH Sample loop volume (ul)
rho_tf = 889.0; % LH Transfer fluid density (g/l]

[start_prep,prep_flag] = cwc_check_can_start_prep_v2(all_slugs,refill_hold, paused_queue);
inject_rinse_now = cwc_check_can_inject_rinse( all_slugs, refill_hold );

invalid_concs = 0;

if and(inject_rinse_now, start_prep)
   [prep_slug,comp,all_slugs] = ...
            cwc_get_next_slug_to_prep_v4_dilution_adjustment(all_slugs,reagent_table,inj_vol,rho_tf);
    
    if ~isempty(comp)
        invalid_concs = double(any(comp(1,:) < 0));
        if invalid_concs
            all_slugs(prep_slug).complete = -1;
            temp_num = all_slugs(prep_slug).number;
            all_slugs(prep_slug).in_prep = 0;
            prep_slug = 0;
            prep_flag = ['Slug ' num2str(temp_num) ' has an invalid composition!'];
        else
            prep_flag = ['Preparing slug ' num2str(all_slugs(prep_slug).number)];
        end
    end

else
   prep_slug = 0;
   comp = [ ];
end

%% Found slug to prepare - inject rinse slugs

% Skip

%% Found slug to prepare - mixing reagents

%Check rinse slug injection status

[rinse_cleared,inject_flag,abort_prep] = lmb_check_rinse_slugs_cleared(all_slugs, rinse_slugs);

% Check that slug can be injected into system

ana_time = 7.5; %Analysis time [min]
warmup_time = 15; % HPLC warmum time [s]
cushion_time = 0; % Time in between injections [s]

[inject_slug,inject_flag,abort_prep] = ...
    lmb_check_can_inject_now(all_slugs,V1, V3, ...
     T, T_tol, ana_time, warmup_time, cushion_time, hold_sys, hold_sys2, refill_hold);

% Inject loaded slug

% Update status of slug to injected into system
load_vol = 15; %LH Sample loop volume [ul];
[all_slugs] = cwc_mark_slug_injected_v2(all_slugs,prep_slug,load_vol);

% Prepare quench injection
quench_inj_vol = cwc_get_quench_inj_vol(all_slugs, prep_slug);
% Base is prepared inside reactor control loop



%% Reactor

% No slug in system

v1_normal = 80; % Normal carrier flow [ul/min]
v1_osc = 400; % maximum oscillatory flow [ul/min]
oscillatory_vol = 310; %Effective oscillatory volume [ul]
outlet_to_quench_vol = 0; % reactor outlet to quench [ul]

[react_slug, new_v1, num_passes, upcoming_step, base_inj_vol, ...
            quench_inj_vol, start_infuse, end_infuse, last_step, first_step] = ...
         cwc_get_next_slug_in_reactor_v4(all_slugs, v1_normal, v1_osc, ...
            oscillatory_vol, outlet_to_quench_vol, T_set);

% Waiting for ps1 detection

ps_dist = 53; %Distance to ps1 [ul]
base_ps_dist = 53; % Distance to inlet ps1 [ul]

% Correct slug distances to identify slug
 [all_slugs] = cwc_match_at_base_ps_v2(all_slugs, base_ps_dist, react_slug);

 % Waiting for ps1 return to baseline
 fill_vol1 = 8; %Syringe volume [ml]
 fill_vol2 = 8; %Syringe volume [ml]
 fill_vol3 = 8; %Syringe volume [ml]
 fill_vol4 = 8; %Syringe volume [ml]
 
 % Mark as complete
base_inj_vol_record = base_inj_vol;
[all_slugs] = cwc_mark_slug_injected_base_v3(all_slugs, react_slug, base_inj_vol_record, all_slugs(react_slug).in_reactor + 1);
% Update fill volume
fill_vol2 = fill_vol2 - base_inj_vol_record / 1000;

% Start step with infuse = Y;
inlet_dist = 73; % Distance to reactor inlet [ul]
outlet_dist = 298; % Distance to reactor outlet [ul]
v1 = new_v1;
all_slugs(react_slug).in_reactor = upcoming_step;
all_slugs(react_slug).distance_matched = inlet_dist;
all_slugs(react_slug).distance = inlet_dist;
outlet_dist = outlet_dist;


% Waiting for ps2 detection

quench_ps_dist = 338; %Distance to outlet ps2 [ul]

% Mark slug (note: we know it's react_slug, so don't need to match)
[all_slugs] = cwc_match_at_quench_ps_knownslug(all_slugs, quench_ps_dist, react_slug);

% Mark as complete
[all_slugs] = ...
    cwc_mark_slug_injected_quench_v3(all_slugs, react_slug, quench_inj_vol, upcoming_step);
% Update fill volume
fill_vol3 = fill_vol3 - quench_inj_vol / 1000;

v1_quench = 700; %Flowrate during quench [ul/min]
v1 = v1_quench;

%% Write slug data to file

write_iter = 0; % Fix to make code work
time = 0; % Fix to make code work

if write_iter <= 0
        % Initialize
         cwc_save_slug_data_first_v2(all_slugs,time,v1,T,T_set,slug_path,status_path,system_path);
else
         % Modify existing files
         cwc_save_slug_data_v2(all_slugs,time,v1,T,T_set,slug_path,status_path,system_path);
end
save(matlab_path);


%manually mark slug as finished analysis
all_slugs(1).in_hplc = 1;
all_slugs(1).analysis_time = 7.8*60;

%% Analyze HPLC data

% Identify slug which has completed analysis
% Look 20 seconds early in case new data file is created automatically after prior slug completion
[all_slugs, ana_slug] = cwc_mark_slug_analysis_complete(all_slugs, ana_time*60+warmup_time-20);

% Process HPLC data

% Process HPLC data
ana_path = 'C:\Users\Admin\Desktop\log\ana_path';
data_path = '\\LCMS2-HP\Chem32\1\Data\LMB\Buchwald optimization\Aniline\AlPhos\2018-09-12 18-33-44 no Sample Name.D';
ana_path = [ana_path stamp]; %add date/time and .txt-file extension
reprocessing = 0;
optimization_on = 0;

process_fun = 'rvp_process_hplc_data_hydrogenation';



%normal processing
[all_slugs,data_processing_exit_flag] = ...
feval(process_fun,data_path,ana_path,all_slugs,analyte_table,ana_slug,optimization_on,reprocessing);


%reprocessing
[all_slugs,analyte_table,counter_yield_changes] =...
 lmb_reprocess_slugs_v2(process_fun,ana_path,all_slugs,reagent_table_path,ana_time...
,warmup_time);





%Reactor 
% all scripts until slug is passed on to hplc

%HPLC loop
%everything until yields, conversions etc are calculated

