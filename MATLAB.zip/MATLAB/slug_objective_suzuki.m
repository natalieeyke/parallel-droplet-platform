function [slug_tracker] = slug_objective_suzuki(slug_tracker_prior,index,reagent_table,reagent_table_index,ana_slug,area,conc)
%SLUG_OBJECTIVE Calculates the objective function value and stores the
%value in slug_tracker
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% June 14, 2013
% Inputs:
%               slug_tracker_prior is the matrix which will be used to track
%               slugs
%               index labels the columns of slug_tracker for easy reference
%               reagent_table is a matrix containing reagent information
%               reagent_table_index gives the header rows for reagent_table
%               ana_slug is the slug currently in analysis
%               area is a matrix of peak areas for the reagent numbers in
%               reagent_table
%               conc is the calibrated chromatogram concentrations
% Outputs:
%               slug_tracker is the matrix which will be used to track slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find slug number column
col_num = find(strcmp(deblank(index),'Slug #') == 1);

% Find reagent 1 concentration column
col_c1 = find(strcmp(deblank(index),'Reag 1 Conc') == 1);

% Find reagent 2 concentration column
col_c2 = find(strcmp(deblank(index),'Reag 2 Conc') == 1);

% Find base concentration column
col_base = find(strcmp(deblank(index),'Base Conc') == 1);

% Find objective function column
col_obj = find(strcmp(deblank(index),'Objective') == 1);

% Find reagent number column
col_reag_num = find(strcmp(deblank(reagent_table_index),'Reagent Number') == 1);

% Find reagent type column
col_type = find(strcmp(deblank(reagent_table_index),'Type') == 1);

slug_tracker = slug_tracker_prior;

% Area desired product
row_desired = find(reagent_table(:,col_type) == 7);
desired = reagent_table(row_desired,col_reag_num);
area_row_desired = find(area(:,1) == desired);
area_desired = area(area_row_desired,2);
if area_desired <= 1
    area_desired = 1;
end

% Area internal standard
row_ISTD = find(reagent_table(:,col_type) == 9);
ISTD_num = reagent_table(row_ISTD,col_reag_num);
area_row_ISTD = find(area(:,1) == ISTD_num);
area_ISTD = area(area_row_ISTD,2);

% Concentration internal standard
conc_ISTD = conc(area_row_ISTD,2);

% Store objective function value in slug_tracker
ana_row = find(slug_tracker(:,col_num) == ana_slug);
conc_SM = slug_tracker(ana_row,col_c1);
conc_cat = slug_tracker(ana_row,col_c2);

% Concentration desired product
conc_desired = conc(area_row_desired,2);
if conc_desired <= 0.01*conc_SM
    conc_desired = 0.01*conc_SM;
end

% Objective function based on turnover number
B = log(conc_desired/conc_cat);

% Objective function based on weighting of yield and catalyst loading
%B = log(conc_desired/conc_SM - 0.2/(.02*0.167)*conc_cat); % 20% yield = max range of catalyst loading
slug_tracker(ana_row,col_obj) = B;

end

