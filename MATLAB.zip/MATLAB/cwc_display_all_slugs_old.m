function cwc_display_all_slugs(all_slugs)
% This function prints all_slugs nicely

if isempty(all_slugs)
    return
end

fields = fieldnames(all_slugs(1));

for i = 1:length(all_slugs)
    disp(sprintf('Slug %3d', i))
    for j = 1:length(fields)    
        disp(sprintf('%25s = %5.5g', char(fields(j)), ...
            eval(['all_slugs(' num2str(i) ').' char(fields(j))])))
    end
    disp(' ')
end

end