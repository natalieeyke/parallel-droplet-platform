function [ X ] = lmb_optimization_cvals_to_X( cvals, dvals, opt_vars, lin,fr_dvals )
% cwc_optimization_cvals_to_X converts a list of continuous variable values
% (in order of opt_vars) to the scaled experimental condition vector, X,
% also using discrete values dvals (in order of opt_vars, again).
% lmb: adapted for multiple discrete variables

slug = cwc_optimization_cdvals_to_slug(cvals, dvals, opt_vars);
if lin
    [ X ] = lmb_optimization_slugs_to_linmat( [slug], opt_vars,fr_dvals );
else
    [ X ] = lmb_optimization_slugs_to_quadmat( [slug], opt_vars,fr_dvals );
end

end