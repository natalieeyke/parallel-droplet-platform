function [v1, fill_vol1, refill_hold, refill_now] = cwc_check_refill_needed( ...
    all_slugs, rinse_slugs, time_prior_v1, time, v1_prior, fill_vol1_prior, ...
    fill_vol2, fill_vol3, fill_min2, fill_min3, V1, V2, V3, push_in_vol1, ...
    vol_syringe1, push_in_vol2, vol_syringe2, push_in_vol3, vol_syringe3, ...
    refill_hold_prior)
% SLUG_REFILL Checks whether to refill any of the syringes and updates
% syringe volumes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs and rinse_slugs are lists of slugs
%               time_prior_v1 is the last time v1 the syringe volume was updated (in s)
%               time is the current time (in s)
%               v1_prior is the current carrier phase flow rate (in uL/min)
%               fill_vol1_prior is the current liquid volume in carrier syringe (in mL)
%               fill_vol2 is the current liquid volume in precat syringe (in mL)
%               fill_vol3 is the current liquid volume in base syringe (in mL)
%               fill_min2 is the minimum fill volume needed for all precat slugs before precat injection point (in mL)
%               fill_min3 is the minimum fill volume needed for all base slugs before base injection point (in mL)
%               V1 is the volume of tubing prior to reactor (in uL)
%               V2 is the volume of reactor (in uL)
%               V3 is the volume of the quench region (in uL)
%               push_in_vol1 is the volume to push in the carrier syringe before refilling (in mL)
%               vol_syringe1 is the total volume of the carrier syringe (in mL)
%               push_in_vol2 is the volume to push in the precat syringe before refilling (in mL)
%               vol_syringe2 is the total volume of the precat syringe (in mL)
%               push_in_vol3 is the volume to push in the base syringe before refilling (in mL)
%               vol_syringe3 is the total volume of the base syringe (in mL)
%               refill_hold_prior is 1 if no more slugs should be injected into system before refill, 0 otherwise
% Outputs:
%               slug_tracker is the updated slug_tracker matrix
%               v1 is the carrier phase flow rate (in uL/min)
%               fill_vol1 is the updated liquid volume in carrier syringe (in mL)
%               refill_hold is 1 if no more slugs should be injected into system before refill, 0 otherwise
%               refill is 1 if refill should start, 0 otherwise
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Update fill volume (in mL)
fill_vol1 = fill_vol1_prior - v1_prior*(time - time_prior_v1)/(60*1000);

% Check if refill is needed
if refill_hold_prior == 1 || ...
        fill_vol1 <= 0.400 + (V1 + V2 + V3)/1000 + push_in_vol1 + 0.05*vol_syringe1 || ...
        fill_vol2 <= fill_min2 + push_in_vol2 + 0.1*vol_syringe2 || ...
        fill_vol3 <= fill_min3 + push_in_vol3 + 0.1*vol_syringe3
    
    refill_hold = 1;
    
    % Check if refill should start now
    if sum(cwc_list_property(all_slugs, 'in_system')) + ...
            sum(cwc_list_property(rinse_slugs, 'in_system')) == 0 
        refill_now = 1;
        v1 = 0;
    else
        refill_now = 0;
        v1 = v1_prior;
    end
    
else
    
    refill_hold = 0;
    refill_now = 0;
    v1 = v1_prior;
    
end

end