function [] = slug_analysis_write(ana_path,data_path,ana_slug,ret_time,area,conc)
%SLUG_ANALYSIS_WRITE records slug analysis results

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 23, 2012
% Inputs:
%               ana_path is the path to the file where analysis data are
%               stored
%               data_path is the HPLC output file location
%               ana_slug is the slug currently in analysis
%               ret_time is a matrix of retention times for the reagent
%               numbers in reagent_table
%               area is a matrix of peak areas for the reagent numbers in
%               reagent_table
%               conc is the calibrated chromatogram concentrations
% Outputs:
%               None
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid4 = -1;

while fid4 < 0
    
    % Load analysis file
    fid4 = fopen(ana_path,'a');
    
    if fid4 < 0
        fclose('all');
    end
    
end

% Write header
fprintf(fid4,'--------------------------------------------------------------------\r\n');
fprintf(fid4,'                            Slug %d                                 \r\n',ana_slug);
fprintf(fid4,'--------------------------------------------------------------------\r\n');
fprintf(fid4,' Reagent # | Ret Time (min) | Peak Area (mAU*s) | Concentration (M) \r\n',ana_slug);

% Loop for all reagents
for reag_row = 1:length(ret_time(:,1))
    reag_num = ret_time(reag_row,1);
    ret = ret_time(reag_row,2);
    a = area(reag_row,2);
    c = conc(reag_row,2);
    
    % Write to file
    fprintf(fid4,' %6.0f    |     %6.3f     |   %12.5f    |      %6.5f \r\n',reag_num,ret,a,c);    
end

fprintf(fid4,'\r\n');

% File name for HPLC data
file_name = [data_path '\REPORT01.xls'];

% Record location of HPLC data file
fprintf(fid4,'See %s for HPLC Data\r\n',file_name);

fprintf(fid4,'\r\n');

% Close list of slugs
fclose(fid4);

end