reagent_table_path = 'C:\Users\Parallel Oscillator\Documents\Parallel LabVIEW\Input\TS_Reagent_Table_Dragonfly.xlsx'
N_reactors = 1;
enabled_reactors_list=1;

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

[all_slugs] = nse_parse_initial_slugs_parallel_v7(reagent_table_path, N_reactors, enabled_reactors_list);


reprocessing = 0;
optimization_on = 0;
converged = 0;

ana_path = [];
process_fun = 'TS_process_coupling_product_area';
data_path = 'C:\Chem32\1\Data\Test_Blank_FullReportF 2022-06-24 11-34-10.D';

%[all_slugs,product_area,data_processing_exit_flag] = TS_process_coupling_product_area(data_path,ana_path,all_slugs,analyte_table,1,optimization_on,reprocessing);

[all_slugs,product_area,data_processing_exit_flag] = feval(process_fun,data_path,ana_path,all_slugs,analyte_table,1,optimization_on,reprocessing);