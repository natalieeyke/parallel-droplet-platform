classdef Analyte
    
    properties
        id = 0;
        name = 'New analyte';
        type = 1.0;
        min_ret_time = 0.0; %minimum retention time in min
        max_ret_time = 0.0;
        linear_calib = [] ; %linear calibration parameter in g ISTD / mol Analyte)
        wavelength = 0; %wavelength in nm or MSD# 

    end
    
    methods
    end
    
end

