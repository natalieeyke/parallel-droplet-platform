classdef Slug_v2
    % Slug describes a slug in the system
    % v2 includes multiple-step chemistry, where base injections in uL
    % April 7, 2017 added ELN tag
    % April 10, 2017 added HPLC sampling time tag
    
    properties
        eln = 'ELN-EXP-UNKNOWN';
        number = 0;
        reagent_1 = 0;
        reagent_1_conc = 0;
        reagent_2 = 0;
        reagent_2_conc = 0;
        reagent_3 = 0;
        reagent_3_conc = 0;
        reagent_4 = 0;
        reagent_4_conc = 0;
        reagent_5 = 0;
        reagent_5_conc = 0;
        makeup = 0;
        prepared_vol = 0;
        injected_vol = 0;
        current_vol = 0;
        base_vol = 0;
        quench_vol = 0;
        temperature = [];
        residence_time_goal = [];
        multi_injections = {};
        multi_injected = [];
        residence_time_actual = [];
        istd_conc = 0;
        in_prep = 0;
        in_system = 0;
        injected = 0;
        in_reactor = 0;
        in_hplc = 0;
        distance = 0;
        distance_matched = 0;
        inj_base = 0;
        inj_quench = 0;
        hplc_sampletime = 100;
        analysis_time = 0;
        complete = 0;
        yield_1 = 0;
        yield_2 = 0;
        yield = 0;
        yield_elim = 0;
        conversion = 0;
        ee = 0;
        mb = 0;
        objective = 0;
        hplc_data_path = '';
        
    end
    
    methods
    end
    
end

