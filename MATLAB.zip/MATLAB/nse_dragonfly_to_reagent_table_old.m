function [dest_path] = nse_dragonfly_to_reagent_table(template_file_path, iteration, next_batch)
% Prepare a new reagent file (dest_path) for processing by
% nse_parse_initial_slugs_parallel_v7.m based on an existing
% reagent file template (template_file_path)

dest_path = strcat(template_file_path, num2str(iteration), '.xlsx');
status = copyfile(template_file_path, dest_path);
N_expts = size(next_batch, 1)

% Column 1 is temperatures
% Column 2 is residence times (in minutes)
% Column 3 is the catalyst index
% Column 4 is the base index

% Load initial slugs
[init_comp, txt, raw] = xlsread(dest_path,'Initial Slugs','A2:V100');
out_comp = init_comp; % base matrix to edit

% Remove empty rows (reagent A undefined)
init_comp(isnan(init_comp(:, 2)), :) = [];

% Generate initial slug tracker
all_slugs = [];

% Fix number of columns (in case last columns are NaN)
if size(init_comp, 2) < 22
    init_comp_temp = init_comp;
    init_comp = nan(N_rows, 22);
    init_comp(:, 1:size(init_comp_temp, 2)) = init_comp_temp;
end



for expt = 1:N_expts

    new_slug = Slug_v4();

    % Slug number
    new_slug.number = (iteration * N_expts) + expt;
    out_comp(expt, 1) = new_slug.number;

    % Reagent 1 Type
    new_slug.reagent_1 = init_comp(1,2);
    out_comp(expt,2) = new_slug.reagent_1;

    % Reagent 1 Concentration
    new_slug.reagent_1_conc = init_comp(1,3);
    out_comp(expt,3) = new_slug.reagent_1_conc;

    % Reagent 2 Type
    new_slug.reagent_2 = init_comp(1,4); % 9H-carbazol-2-yl trifluoromethanesulfonate
    out_comp(expt,4) = new_slug.reagent_2;

    % Reagent 2 Concentration
    new_slug.reagent_2_conc = init_comp(1,5);
    out_comp(expt,5) = new_slug.reagent_2_conc;

    % Reagent 3 Type
    new_slug.reagent_3 = init_comp(1,6); % 3-aminopyridine
    out_comp(expt,6) = new_slug.reagent_3;

    % Reagent 3 Concentration
    new_slug.reagent_3_conc = init_comp(1,7);
    out_comp(expt,7) = new_slug.reagent_3_conc;

    % Reagent 4 Type
    cat_idx = (2 * N_expts) + expt;
    if next_batch(cat_idx) == 1
        new_slug.reagent_4 = 4; % cat 1
    elseif next_batch(cat_idx) == 2
        new_slug.reagent_4 = 5; % cat 2
    elseif next_batch(cat_idx) == 3
        new_slug.reagent_4 = 8; % cat 3
    elseif next_batch(cat_idx) == 4
        new_slug.reagent_4 = 9; % cat 4
    else
        disp('Error');
    end
    out_comp(expt,8) = new_slug.reagent_4;

    % Reagent 4 Concentration
    new_slug.reagent_4_conc = init_comp(1,9);
    out_comp(expt,9) = new_slug.reagent_4_conc;

    % Reagent 5 Type
    base_idx = (3 * N_expts) + expt;
    if next_batch(base_idx) == 1
        new_slug.reagent_5 = 6; % DBU
    elseif next_batch(base_idx) == 2
        new_slug.reagent_5 = 7; % BTMG
    else
        disp('Error');
    end
    out_comp(expt,10) = new_slug.reagent_5;
    
    % Reagent 5 Concentration
    new_slug.reagent_5_conc = init_comp(1,11);
    out_comp(expt,11) = new_slug.reagent_5_conc;

    % Reagent 6 Type
    new_slug.reagent_6 = init_comp(1,12);
    out_comp(expt,12) = new_slug.reagent_6;

    % Reagent 6 Concentration
    new_slug.reagent_6_conc = init_comp(1,13);
    out_comp(expt,13) = new_slug.reagent_6_conc;

    % Makeup Type
    new_slug.makeup = init_comp(1,14);
    out_comp(expt,14) = new_slug.makeup;

    % Slug Volume
    new_slug.prepared_vol = init_comp(1,15);
    out_comp(expt,15) = new_slug.prepared_vol;

    % Base Volume
    new_slug.base_vol = init_comp(1,16);
    out_comp(expt,16) = new_slug.base_vol;

    % Quench vol
    new_slug.quench_vol = init_comp(1,17);
    out_comp(expt,17) = new_slug.quench_vol;

    % Temperature
    new_slug.temperature = next_batch(expt);
    out_comp(expt,18) = new_slug.temperature;
    
    new_slug.residence_time_goal = 60 * next_batch(N_expts + expt);
    new_slug.residence_time_actual = 0;
    out_comp(expt,19) = new_slug.residence_time_goal;

    % Multiple Injections
    if length(new_slug.residence_time_goal) > 1
        new_slug.multi_injections = strtrim(strsplit(raw{row, 20}, ';'));
        new_slug.multi_injected = zeros(size(new_slug.multi_injections));
    end

    % Sample time
    new_slug.hplc_sampletime = raw{1, 21};
    out_comp(expt,21) = new_slug.hplc_sampletime;

    % ELN
    new_slug.eln = (iteration * N_expts) + expt;
    out_comp(expt,22) = new_slug.eln;

    % Check for validity of multi-step definition before adding to list
    multi = length(new_slug.temperature) > 1;
    if multi % multi step
        if length(new_slug.temperature) == (length(new_slug.multi_injections) + 1)
            all_slugs = [all_slugs new_slug];
        end
    else % single step
        all_slugs = [all_slugs new_slug];
    end

end % for row = 1:N_rows

%out_comp
%out_comp = out_comp(:,N_expts)
xlswrite(dest_path,out_comp,'Initial Slugs','A2:V100');

end

