function [react_slug, v1_new, num_passes, upcoming_step, base_inj_vol, ...
            quench_inj_vol, start_infuse, end_infuse, last_step, first_step] = ...
         cwc_get_next_slug_in_reactor_v4(all_slugs, v1_normal, v1_osc, ...
            oscillatory_vol, outlet_to_quench_vol, T_set)
% finds the next slug to enter the reactor 
% v2 allows multistep chemistry
% v3 allows using a reaction time of "-3" to mean 3 passes at max velocity
% v3Q is intended for when multiple injections occur at the outlet (quench)
% v4 is intended for flexible multistep chemistry where injections can
%   occur at either the inlet or outlet

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% October 27, 2015
% January 26, 2016
%
% Inputs:
%               all_slugs is the list of slugs
%               v1_normal is  the flow rate upon exit
%               v1_osc is the oscillatory flow rate (max)
%               oscillatory_vol is the vol between photodetectors
%               outlet_to_quench_vol is the fixed distance to quench
%               T_set is the reactor temperature in C
%               
% Outputs:
%               react_slug is the INDEX of the identified slug
%               v1_new is the flow rate for oscillation
%               num_passes is the number of cycles (0 is straight through,
%                   2 is one forward-backward-forward)
%               upcoming_step is the index of the reaction step for the
%                   current slug
%               base_inj_vol is the volume (uL) to inject right before the
%                   next reaction step (to prep injection)
%               quench_inj_vol is the volume (uL) to inject right after the
%                   next reaction step
%               start_infuse is a 1 or 0 depending on if the slug is
%                   starting this step by infusing or withdrawing
%               end_infuse is a 1 or a 0 depending on if the slug should be
%                   infusing at the end of this upcoming step
%               last_step is a 1 or 0 depending on if this next step is the
%                   last one
%               first_step is a 1 or 0 depending on if this next step is
%                   the first one
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Defaults
react_slug = 0;
v1_new = 0;
num_passes = 0;
upcoming_step = 0;
base_inj_vol = 0;
quench_inj_vol = 0;
last_step = 0;
first_step = 0;
end_infuse = 0;
start_infuse = 0;
    
% If T_set < 20, then chances are we are doing an unheated photoredox rxn
% ambient temperature ~23 degC
if T_set < 20
    T_set = 23;
end

% Find injected slug that is not COMPLETELY done reacting (its last step)
% react_slug = find(and(cwc_list_property(all_slugs, 'residence_time_actual(end)') == 0, ...
%                       cwc_list_property(all_slugs, 'injected') == 1), 1, 'first');

react_slug = find(and((and(cwc_list_property(all_slugs, 'residence_time_actual(end)') == 0, ...
                      cwc_list_property(all_slugs, 'injected') == 1)),...
                      cwc_list_property(all_slugs, 'complete') == 0), 1, 'first');                 
                  
% If no slug, return 0s
if isempty(react_slug)
    react_slug = 0;
    return
end

% Figure out what step we're about to start
upcoming_step = find(all_slugs(react_slug).residence_time_actual == 0, 1, 'first');

% This is the first step
if upcoming_step == 1
    start_infuse = 1;
    first_step = 1;
    base_inj_vol = all_slugs(react_slug).base_vol;
else
    % What came before?
    prev_inj = all_slugs(react_slug).multi_injections{upcoming_step - 1};
    split = strsplit(prev_inj, '@');
    loc = lower(split{2});
    % At the inlet or outlet?
    if or(loc == 'i', loc == 'b')
        % If we were supposed to have a multi_injection, then we should
        % set that volume (about to inject)
        start_infuse = 1;
        base_inj_vol = str2double(split{1});
    else
        start_infuse = 0;
    end    
end

% Is this the last step?
last_step = 1 * (upcoming_step == length(all_slugs(react_slug).residence_time_goal));
if last_step == 1
    quench_inj_vol = all_slugs(react_slug).quench_vol;
    end_infuse = 1;
else
    % Check what's supposed to come next
    next_inj = all_slugs(react_slug).multi_injections{upcoming_step};
    split = strsplit(next_inj, '@');
    vol = str2double(split{1});
    loc = lower(split{2});
    
    % At the inlet or outlet?
    if or(loc == 'i', loc == 'b')
        %base_inj_vol = vol;
        end_infuse = 0;
    else
        quench_inj_vol = vol;
        end_infuse = 1;
    end       
end

% Get target time
residence_time_goal = all_slugs(react_slug).residence_time_goal(upcoming_step);

%% valid residence time in seconds
if residence_time_goal > 0 

    % Get time from outlet to quench (fixed)
    min_time = outlet_to_quench_vol / v1_normal * 60;

    % Get new oscillatory goal
    oscillatory_time_goal = residence_time_goal - min_time;
    oscillatory_volume_ideal = oscillatory_time_goal / 60 * v1_osc;

    % Number of reactor volumes
    num_reactor_vols = oscillatory_volume_ideal / oscillatory_vol;

    % Direction at end depends on if this is the first step
    if (end_infuse - start_infuse) == 0
        % Need to round up to the nearest odd number
        round_reactor_vols = floor((num_reactor_vols - 1) / 2) * 2 + 1;
        if round_reactor_vols < 1
            num_passes = 1;
            v1_new = v1_osc;
            return
        end
        num_passes = round_reactor_vols;

    else
        % Need to round up to the nearest even number
        round_reactor_vols = floor(num_reactor_vols / 2) * 2;
        if round_reactor_vols < 2
            num_passes = 2;
            v1_new = v1_osc;
            return
        end
        num_passes = round_reactor_vols;
    end

    % Find exact flow rate now
    v1_new = round_reactor_vols * oscillatory_vol / oscillatory_time_goal * 60;

    % Correct for ideal gas law expansion
    v1_new = v1_new / (T_set + 273.15) * 293.15;

%% Using a negative residence time to indicate # of passes
else 
    num_reactor_vols = - residence_time_goal;
    
    % Round as appropriate
    if (end_infuse - start_infuse) == 0
        % Need to round up to the nearest odd number
        round_reactor_vols = floor((num_reactor_vols - 1) / 2) * 2 + 1;
        num_passes = round_reactor_vols;
        if round_reactor_vols < 1
            num_passes = 1;
        end
    else
        % Need to round up to the nearest even number
        round_reactor_vols = floor(num_reactor_vols / 2) * 2;
        num_passes = round_reactor_vols;
        if round_reactor_vols < 2
            num_passes = 2;
        end
    end
    
    % When defining reaction time with number of passes, always move at
    % the maximum allowable carrier velocity
    v1_new = v1_osc;
    
    % Correct for ideal gas law expansion
    v1_new = v1_new / (T_set + 273.15) * 293.15;
     
end

end