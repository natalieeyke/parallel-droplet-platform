function [all_slugs] = cwc_mark_slug_objective(all_slugs, ana_slug)
% marks slug with objective function value

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs list of slugs
%               ana_slug is the INDEX of the completed slug
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_slugs(ana_slug).objective = 1;

end