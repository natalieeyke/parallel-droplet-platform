function [ new_reactor_slug ] = lmb_generate_reactor_slug( all_slugs, react_slug, num_passes, timestamp )
%generates a reactor_slug from all_slug object  
%object
%   Lorenz Baumgartner, January 13th, 2017
%input 
% react_slug: index of reacting slug 
% all_slugs: all slug objects
% num_passes
% timestamp of slug creation

new_reactor_slug = reactor_slug();
new_reactor_slug = lmb_copy_fields_reactor( new_reactor_slug, all_slugs, react_slug );
        

%initialize log oscillation data
new_reactor_slug.nPasses = num_passes;
new_reactor_slug.timestamp = timestamp;

new_reactor_slug.index = 0;
new_reactor_slug.oscill_flow_rate = zeros(num_passes,1);
new_reactor_slug.compensation_factor = zeros(num_passes,1);
new_reactor_slug.compensation_delay = zeros(num_passes,1);

new_reactor_slug.time_initial_detection = zeros(num_passes,1);
new_reactor_slug.time_next_detection = zeros(num_passes,1);
new_reactor_slug.time_PS2_detection = zeros(1,1);  

new_reactor_slug.time_between_PD_PS2 = zeros(1,1);
new_reactor_slug.time_between_detections = zeros(num_passes,1);
new_reactor_slug.average_flow_rate_pass = zeros(num_passes,1);
new_reactor_slug.average_flow_rate_PD_PS2 = zeros(1,1);


end

