classdef Reagent
    
    properties
        id = 0;
        name = 'New reagent';
        type = 1.0;
        conc = 1.0;
        istd_conc = 0.0;
        density = 1000;
        
        RackID = 220;
        PlaceID = 1;
        WellID = 1;
    end
    
    methods
    end
    
end

