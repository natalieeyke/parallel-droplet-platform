function [ res_residence_time_goal ] = lmb_correct_residence_time_goal(residence_time_goal,temperature)
%Returns corrected residence time goal for single pass

%   Input:
%   residence_time_goal in s
%   temperature in �C
%   Output: 
%   corrected_residence_time_goal in s

%   Temperature intervall: 30�C to 110�C
%   Actual residence time intervall: 60s - 600s


%Model assumptions:
% maximum oscillatory flow rate is 400 �l/min
% oscillatory volume is 310 �l
% volume reactor outlet to quench is set to 0 �l
% 15 �l reaction slug
% 1:5 H2O:THF 
% 3.5 �l online injection
% concentration of injected base: 1.63 M
% carrier gase: nitrogen
% carrier gas syringe: 9.525 mm inner diameter, 8 ml volume
% pressure 100 PSI
% compensation delay: 4s 
% compensation factor: 3s
% PD delay: 13 s
% constant flow mode
%
%tubing:
%carrier syringe to valve: 78.4 cm x 0.03 in ID
%carrier valve to rinse T-junction: 6.9 cm x 0.03 in ID
%rinse T-junction to LH valve: 33.8 cm x 0.03 in ID
%LH sample loop: 17 �l, most likely 0.02 in ID
%LH valve to inlet T-junction: 26.2 cm x 0.02 in ID
%Reactor tubing: 15.2 cm x 1/16 in ID, distance between end of inlet
%fitting to edge of reactor inlet: 2 cm
%outlet T-junction to HPLC valve: 18.5 cm x 0.02 in ID
%HPLC valve to pressure bomb: 12.8 cm x 0.02 in ID




%define model parameters and variable boundaries
A_P_single = [88.219272821977310;28.855003462429330;-3.325523487726843];
D_p_multi =  [3.739703503037389e+02;2.673526029537235e+02;-15.170590691711709;-15.646756135574087;-19.452144883354975];


model_function_single_pass = @(x,y,P)  P(1,1) + P(2,1).*x +  P(3,1).*y;
single_pass_model_upper_limit = model_function_single_pass(1,-1,A_P_single); 




if residence_time_goal<=single_pass_model_upper_limit 
        
        temperature = (temperature-30).*2./(110-30) -1;%normalize and center
        residence_time_goal_normalized = ( residence_time_goal - A_P_single(1,1) -A_P_single(3,1).*temperature )./A_P_single(2,1);
        %denormalize and decenter result
        res_residence_time_goal = (residence_time_goal_normalized +1).*(139-70)./2 +70 ;        
        
        if res_residence_time_goal > 139
            
            res_residence_time_goal = 139; %ensure single pass: make sure 139s is not exceeded
            
        end
        
        else if residence_time_goal> single_pass_model_upper_limit 
                
        temperature = (temperature-30).*2./(110-30) -1;%normalize and center
        
        residence_time_goal_normalized =   (residence_time_goal -D_p_multi(1,1)-D_p_multi(3,1).*temperature-D_p_multi(5,1).*temperature.^2)./(D_p_multi(2,1)+D_p_multi(4,1).*temperature);    
       %denormalize and decenter result
        res_residence_time_goal = (residence_time_goal_normalized +1).*(1000-140)./2 +140 ; 
       
            else
                
                disp('something went wrong with the residence time correction')
                
            end %end if


end

