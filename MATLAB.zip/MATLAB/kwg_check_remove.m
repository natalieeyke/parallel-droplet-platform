function [ check ] = kwg_check_remove( all_slugs, opt_variables, buffer, lin, tol )
% Checks if we can remove the discrete variable's experiments and 
% parameters based on potential rank deficiency issues or matrix
% computational errors.


if lin
    [ X_proposed ] = cwc_optimization_slugs_to_linmat( ... 
        cwc_optimization_completed_slugs(all_slugs), opt_variables);
else
    [ X_proposed ] = cwc_optimization_slugs_to_quadmat( ...
        cwc_optimization_completed_slugs(all_slugs), opt_variables );
end

if ( length(all_slugs) > size(X_proposed, 2) + buffer ) && ...
        ( rank(X_proposed, tol) >= size(X_proposed, 2) )
    check = true;
   
else
    check = false;
end %if

end
        