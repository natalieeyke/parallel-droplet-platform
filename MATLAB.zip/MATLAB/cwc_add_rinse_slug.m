function [ rinse_slugs ] = cwc_add_rinse_slug( rinse_slugs, new_vol )
% add a rinse_slug to the list

new_slug = RinseSlug();
new_slug.current_volume = new_vol;
new_slug.in_system = 1;

% Push all current rinse slugs an extra volume 
for i = 1:length(rinse_slugs)
    rinse_slugs(i).distance = rinse_slugs(i).distance + new_vol;
end

rinse_slugs = [rinse_slugs new_slug];

end

