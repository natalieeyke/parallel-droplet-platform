function [liquid_handler_start_times, loop_to_reactor_start_times, rinse_transfer_lines_start_times, reactor_to_analysis_start_times, rinse_reactor_start_times, analysis_start_times, reactors_start_times] = nse_scheduler_v2(all_slugs, N_reactors, tau_prep, tau_loop_to_reactor, tau_rinse_vent_transfer_lines, tau_rinse_vent_reactor, tau_reactor_to_analysis, tau_analysis)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v1: January 2022; built for demonstration and schedule visualization
% v2: February 2022: updated for integration with main control software
% - throughout, distinguish between "times" (which are times after the
% startup at which specific operations occur) and the "taus" on which the
% times depend, which are the lengths (in seconds) of specific operations
% - account for computer processing time
% - Based on the ordered batch of droplets received from
% nse_parse_initial_slugs_parallel_v7.m, assign each slug a
% prep_start_time, inject_onto_platform_time (i.e. get droplet to sample loop and then
% pause until inject_onto_platform_time), eject_from_reactor_time (which is
% just travel_to_reactor_tau plus residence_tau), and a start_analysis_time
% - Account for rinse and vent operation times as well as the length of the hplc method when defining the schedule
% for the droplets. All of these operations should also be triggered according to the schedule
% - Can use a combo of "it's time" and "rinse_trigger = true" to start the
% rinse; ideally, rinse_trigger will be set to true before an operation
% reaches its specified start time. Rinse_trigger can be based on phase
% sensor readings - this is how we'll incorporate those; in cases where
% it's_time is true but rinse_trigger is not, that's how we'll know there's
% a problem
% 
% INPUTS
% All tau values are specified in seconds
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Change everything from seconds to minutes if seeking to visualize
% tau_prep = tau_prep / 60;
% tau_loop_to_reactor = tau_loop_to_reactor / 60;
% tau_rinse_vent_transfer_lines = tau_rinse_vent_transfer_lines / 60;
% tau_rinse_vent_reactor = tau_rinse_vent_reactor / 60;
% tau_reactor_to_analysis = tau_reactor_to_analysis / 60;
% tau_analysis = tau_analysis / 60;


N_rxns = max(size(all_slugs));
tau_rxns = zeros(1, N_rxns);
for i = 1:N_rxns
    tau_rxns(i) = all_slugs(i).residence_time_goal;% / 60;% Uncomment the division by 60 to convert residence time from seconds to minutes for visualization purposes
end

% Initialize parameters and arrays for discrete sections of hardware in
% which droplets cannot coexist
% The array main_path is used to check for conflicts, since there cannot be
% two droplets in the main flowpath at the same time, but there are four
% unique operations that occur in the main flowpath: 1) transport droplet
% to reactor; 2) rinse #1 (which rinses everything except the reactor); 3)
% transport droplet to analysis; and 4) rinse #2 (which rinses everything,
% including the most recent reactor, while also pushing the outgoing
% droplet to waste)
% Therefore, we need hardware arrays for each of the four main flowpath
% sub-operations so we can define schedules for those operations, but we
% don't need to include them in the conflict check because they are covered
% by the main flowpath conflict check
N_timepoints = 1000000; % Each timepoint corresponds to one second (or one minute, if you divide all of the residence times by 60)
liquid_handler = zeros(1, N_timepoints);
main_path = zeros(1, N_timepoints);
loop_to_reactor = zeros(1, N_timepoints); % scheduling array for carrier syringe-based transport of droplet from injection valve sample loop to reactor
rinse_transfer_lines = zeros(1, N_timepoints); % scheduling array for rinsing the transfer lines only
reactor_to_analysis = zeros(1, N_timepoints); % scheduling array for carrier syringe-based transport of droplet from reactor to analysis
rinse_reactor = zeros(1, N_timepoints); % scheduling array for rinsing the reactor and the transfer lines
reactors = zeros(N_reactors, N_timepoints);
hplc = zeros(1, N_timepoints);

lh_start = int16(1);
for r = 1:N_rxns
    
    % Create temporary copies of each hardware section's array; after confirming that
    % there's no overlap, update the original arrays
    lh_temp = liquid_handler;
    main_path_temp = main_path;
    reactor_temp = reactors;
    lc_temp = hplc;
    
    reactor = int16(all_slugs(r).assigned_reactor); % reactor number
    
    % Lay out a proposal for the schedule
    lh_end = lh_start + tau_prep - 1; % the liquid handler requires time equal to tau_prep to complete the droplet preparation
    main_in_start = lh_end + 1; % the main flowpath is in use once the lh is done prepping; at this point, can trigger the injection valve to switch and carrier to infuse drop to reactor
    main_in_end = main_in_start + tau_loop_to_reactor - 1;
    reactor_start = main_in_end + 1; % the reactor is in use once travel to the reactor is complete
    main_rinse_1_start = main_in_end + 1; % the main loop is still in use for the rinsing process after the droplet has traveled to the reactor
    main_rinse_1_end = main_rinse_1_start + tau_rinse_vent_transfer_lines - 1;
    reactor_end = reactor_start + tau_rxns(r) - 1;
    main_out_start = reactor_end + 1;
    main_out_end = main_out_start + tau_reactor_to_analysis - 1;
    main_rinse_2_start = main_out_end + 1;
    main_rinse_2_end = main_rinse_2_start + tau_rinse_vent_reactor - 1;
    lc_start = main_out_end + 1;
    lc_end = lc_start + tau_analysis - 1;
    
    % Check to see if any hardware is busy during a window that the
    % schedule above would overlap with
    busy = sum(lh_temp(1, lh_start : lh_end)) + ...
           sum(main_path_temp(1, main_in_start : main_in_end)) + ...
           sum(main_path_temp(1, main_rinse_1_start : main_rinse_1_end)) + ...
           sum(reactor_temp(reactor, reactor_start : reactor_end)) + ...
           sum(main_path_temp(1, main_out_start : main_out_end)) + ...
           sum(main_path_temp(1, main_rinse_2_start : main_rinse_2_end)) + ...
           sum(lc_temp(1, lc_start : lc_end));
    
    % If the schedule above would result in overlapping operations for any
    % of the hardware, shift the proposed schedule back until the overlap is eliminated
    while busy
        lh_start = lh_start + 1; % shift the proposed schedule back, then repeat the scheduling code above, and again check for overlap
        lh_end = lh_start + tau_prep - 1;
        main_in_start = lh_end + 1;
        main_in_end = main_in_start + tau_loop_to_reactor - 1;
        reactor_start = main_in_end + 1;
        main_rinse_1_start = main_in_end + 1;
        main_rinse_1_end = main_rinse_1_start + tau_rinse_vent_transfer_lines - 1;
        reactor_end = reactor_start + tau_rxns(r) - 1;
        main_out_start = reactor_end + 1;
        main_out_end = main_out_start + tau_reactor_to_analysis - 1;
        main_rinse_2_start = main_out_end + 1;
        main_rinse_2_end = main_rinse_2_start + tau_rinse_vent_reactor - 1;
        lc_start = main_out_end + 1;
        lc_end = lc_start + tau_analysis - 1;
        busy = sum(lh_temp(1, lh_start : lh_end)) + ...
               sum(main_path_temp(1, main_in_start : main_in_end)) + ...
               sum(main_path_temp(1, main_rinse_1_start : main_rinse_1_end)) + ...
               sum(reactor_temp(reactor, reactor_start : reactor_end)) + ...
               sum(main_path_temp(1, main_out_start : main_out_end)) + ...
               sum(main_path_temp(1, main_rinse_2_start : main_rinse_2_end)) + ...
               sum(lc_temp(1, lc_start : lc_end));
        
    end

    % "Accept" the proposed schedule by updating the main hardware arrays
    liquid_handler(1, lh_start : lh_end) = r * ones(1, tau_prep);
    main_path(1, main_in_start : main_in_end) = r * ones(1, tau_loop_to_reactor);
    loop_to_reactor(1, main_in_start : main_in_end) = r * ones(1, tau_loop_to_reactor);
    main_path(1, main_rinse_1_start : main_rinse_1_end) = r * ones(1, tau_rinse_vent_transfer_lines);
    rinse_transfer_lines(1, main_rinse_1_start : main_rinse_1_end) = r * ones(1, tau_rinse_vent_transfer_lines);
    reactors(reactor, reactor_start : reactor_end) = r * ones(1, tau_rxns(r));
    main_path(1, main_out_start : main_out_end) = r * ones(1, tau_reactor_to_analysis);
    reactor_to_analysis(1, main_out_start : main_out_end) = r * ones(1, tau_reactor_to_analysis);
    main_path(1, main_rinse_2_start : main_rinse_2_end) = r * ones(1, tau_rinse_vent_reactor);
    rinse_reactor(1, main_rinse_2_start : main_rinse_2_end) = r * ones(1, tau_rinse_vent_reactor);
    hplc(1, lc_start : lc_end) = r * ones(1, tau_analysis);
    
    lh_start = lh_start + tau_prep;
    
end

%%% RECORD OPERATION START TIMES FOR USE BY THE MAIN VI
% placeholders for the reaction that the operation in question is currently processing
lh_rxn = 0; 
loop_to_reactor_rxn = 0;
rinse_transfer_lines_rxn = 0;
reactors_rxns = zeros(N_reactors, 1);
reactor_to_analysis_rxn = 0;
rinse_reactor_rxn = 0;
analysis_rxn = 0;

% arrays for storing the start times
% For maximum flexibility, and to allow the queue to be edited easily in
% real-time, give hardware sequences their start times and the reaction
% numbers corresponding to those start times; then, have each operation
% grab any additional info it needs from the all_slugs list using the
% reaction number. If the queue needs to be reset, rerun the scheduler, and
% either restart the main timer or pass the time of reset as an input to
% the scheduler
% The reaction numbers are implicit in the start times array structure: the
% column index corresponds to the reaction number - therefore, when
% resetting, add the last reaction completed before the reset to the
% reaction numbers being used (so that the user sees a meaningful reaction
% number, rather than starting over from 1)
% Have each hardware sequence keep track of which reaction number its
% completed and which reaction number is next so it knows where in the
% arrays to look for information
liquid_handler_start_times = zeros(1, N_rxns); % The column index corresponds to the reaction number; At each liquid handler start time, grab the info about the next reaction in the queue (or the one specified by the reaction number) in order to prep it
loop_to_reactor_start_times = zeros(1, N_rxns); % The column index corresponds to the reaction number (use to get reactor assignment); At each loop to reactor start time, initiate the loop to reactor sequence: open the assigned reactor's valve to the system, switch the injection valve position, and infuse until the droplet reaches the reactor, with "reaches the reactor" determined via the reactor's phase sensor only; trigger using a combo of start time and lh inj valve phase sensor signal
rinse_transfer_lines_start_times = zeros(1, N_rxns); % At each rinse transfer lines start time, just infuse the rinse droplets using the rinse syringe and the carrier syringe
reactor_to_analysis_start_times = zeros(1, N_rxns); % should trigger droplet transport to analysis - leave reactor valve open to system for rinsing
rinse_reactor_start_times = zeros(1, N_rxns); % should include which reactor it's rinsing - pass the current slug info that was grabbed from the queue by the liquid handler sequence to the rinse reactor sequence - valve should have been left open by the preceding transport operation; close it when rinse is done
analysis_start_times = zeros(1, N_rxns); % trigger using a combo of start time and analytical valve phase sensor signal
reactors_start_times = zeros(N_reactors, N_rxns);% The row denotes the reactor number, and the column denotes the reaction number; At each reactor start time, simply switch the reactor valve position to the isolated position; trigger using a combo of start time and reactor phase sensor signal - just a check to make sure everything is ok; use reaction number to get the residence time; once the residence time is reached, the next operation starts, the droplet leaves, and the reactor sequence should check for this reactor's next reaction, use its reaction number to get its temperature, and start navigating to that temperature; first operation in the reactor while loop should be to get the next temperature and hold there until otherwise triggered, so that it works for each reactor's first reaction too

for i = 1:N_timepoints % Each timepoint corresponds to one second
    % When the value for a particular index in a hardware array is greater
    % than the previous value, the hardware is performing an operation for
    % a new reaction - the hardware activity should start at the time in seconds equal
    % to the index when this occurs
    
    % Liquid handler: program such that it accesses the prep info for the
    % next droplet in the queue at each start time
    % in other words, no need to add info about which reaction it is here
    lh_rxn_new = liquid_handler(i);
    if lh_rxn_new > lh_rxn
        liquid_handler_start_times(1, lh_rxn_new) = i;
        lh_rxn = lh_rxn_new;
    end
    
    loop_to_reactor_rxn_new = loop_to_reactor(i);
    if loop_to_reactor_rxn_new > loop_to_reactor_rxn
        loop_to_reactor_start_times(loop_to_reactor_rxn_new) = i;
        loop_to_reactor_rxn = loop_to_reactor_rxn_new;
    end
    
    rinse_transfer_lines_rxn_new = rinse_transfer_lines(i);
    if rinse_transfer_lines_rxn_new > rinse_transfer_lines_rxn
        rinse_transfer_lines_start_times(rinse_transfer_lines_rxn_new) = i;
        rinse_transfer_lines_rxn = rinse_transfer_lines_rxn_new;
    end
    
    reactor_to_analysis_rxn_new = reactor_to_analysis(i);
    if reactor_to_analysis_rxn_new > reactor_to_analysis_rxn
        reactor_to_analysis_start_times(reactor_to_analysis_rxn_new) = i;
        reactor_to_analysis_rxn = reactor_to_analysis_rxn_new;
    end
    
    rinse_reactor_rxn_new = rinse_reactor(i);
    if rinse_reactor_rxn_new > rinse_reactor_rxn
        rinse_reactor_start_times(rinse_reactor_rxn_new) = i;
        rinse_reactor_rxn = rinse_reactor_rxn_new;
    end
    
    analysis_rxn_new = hplc(i);
    if analysis_rxn_new > analysis_rxn
        analysis_start_times(analysis_rxn_new) = i;
        analysis_rxn = analysis_rxn_new;
    end
    
    reactors_rxns_new = reactors(:, i);
    for j = 1:N_reactors
        if reactors_rxns_new(j) > reactors_rxns(j)
            reactors_start_times(j, reactors_rxns_new(j)) = i;
            reactors_rxns(j) = reactors_rxns_new(j);
        end
        
%         if reactors_rxns_new(2) > reactors_rxns(2)
%             reactors_start_times(2, reactors_rxns_new(2)) = i;
%             reactors_rxns(2) = reactors_rxns_new(2);
%         end
%         
%         if reactors_rxns_new(3) > reactors_rxns(3)
%             reactors_start_times(3, reactors_rxns_new(3)) = i;
%             reactors_rxns(3) = reactors_rxns_new(3);
%         end
%         
%         if reactors_rxns_new(4) > reactors_rxns(4)
%             reactors_start_times(4, reactors_rxns_new(4)) = i;
%             reactors_rxns(4) = reactors_rxns_new(4);
%         end
%         
%         if reactors_rxns_new(5) > reactors_rxns(5)
%             reactors_start_times(5, reactors_rxns_new(5)) = i;
%             reactors_rxns(5) = reactors_rxns_new(5);
%         end
%         
%         if reactors_rxns_new(6) > reactors_rxns(6)
%             reactors_start_times(6, reactors_rxns_new(6)) = i;
%             reactors_rxns(6) = reactors_rxns_new(6);
%         end
%         
%         if reactors_rxns_new(7) > reactors_rxns(7)
%             reactors_start_times(7, reactors_rxns_new(7)) = i;
%             reactors_rxns(7) = reactors_rxns_new(7);
%         end
%         
%         if reactors_rxns_new(8) > reactors_rxns(8)
%             reactors_start_times(8, reactors_rxns_new(8)) = i;
%             reactors_rxns(8) = reactors_rxns_new(8);
%         end
%         
%         if reactors_rxns_new(9) > reactors_rxns(9)
%             reactors_start_times(9, reactors_rxns_new(9)) = i;
%             reactors_rxns(9) = reactors_rxns_new(9);
%         end
%         
%         if reactors_rxns_new(10) > reactors_rxns(10)
%             reactors_start_times(10, reactors_rxns_new(10)) = i;
%             reactors_rxns(10) = reactors_rxns_new(10);
%         end
    end
            

end

% Use the reactor start times combined with reactor phase sensor signal as a way to verify that everything is
% behaving as it should; but reactors also need a signal - a
% "reactor_end_times" - that triggers them to start navigating to the next
% reaction temperature - in other words, "

%disp(liquid_handler_start_times)

C = cat(1, liquid_handler, main_path, reactors, hplc);
C = C ./ N_rxns;
reactors_start_times
%cmap = parula;
[~, runtime] = max(hplc);
%image(C)
%colormap(cmap);%, 'Colormap', cmap)
%imshow(C, 'Colormap', cmap) % 'InitialMagnification', 5000, 
%imshow(liquid_handler)
%imshow(main_path)
%imshow(reactors)
%imshow(hplc)

end