classdef OptVar
    % Variable to be used in optimization
    
    properties
        label = 'unlabeled'; % label
        type = ''; % continuous or discrete
        map = @(x) x; % how variable scales
        min = -1; % maximum
        max = 1; % minimum
        values = [0, 1]; % allowable values for discrete variables
        modifies = {1}; % for discrete variables
    end
    
    properties(Access = protected)
        map_min = -1; % minimum mapped value
        map_max = 1; % maximum mapped value
        mapped_prev = false; % previously mapped
    end
    
    methods
        % Inverse of mapping function
        function res = unmap(obj, val)
            % Make sure this is a continuous var
            if strcmp(obj.type, 'discrete')
                error('Calling unmap on discrete variable')    
            end
            % Get 'default' unscaled value
            default = mean([obj.min, obj.max]);
            % Define unmapping function using fzero
            options = optimoptions('fsolve', 'Display', 'none');
            res = fsolve(@(x) obj.map(x) - val, default, options);
        end
        
        % Complete scaling (with mapping)
        function res = scale_pm1(obj, val)
            % Get simple mapping
            mapped = obj.map(val);
            % Calculate bounds if necessary
            if ~obj.mapped_prev
                obj.map_min = obj.map(obj.min);
                obj.map_max = obj.map(obj.max);
                obj.mapped_prev = true;
            end
            % Scale between -1 and +1
            res = -1 + 2 * (mapped - obj.map_min) / (obj.map_max - obj.map_min);
        end
        
        % Complete unscaling (with unmapping)
        function res = unscale_pm1(obj, val)
             % Calculate bounds if necessary
            if ~obj.mapped_prev
                obj.map_min = obj.map(obj.min);
                obj.map_max = obj.map(obj.max);
                obj.mapped_prev = true;
            end
            % Scale from -1 to +1 to map_min to map_max
            mapped = obj.map_min + (obj.map_max - obj.map_min) * (val + 1) / 2;
            % Unscale
            res = obj.unmap(mapped);
        end
        
        % Convert discrete variable to one-hot
        function res = one_hot(obj, val)  
            if strcmp(obj.type, 'continuous')
                error('Calling one_hot on continuous variable')    
            end
            res = double(obj.values == val); %double value for X, catalyst number 3 is converted to double [0010 0000] 
            if sum(res) == 0
                error(['Value ' num2str(val) ' not recognized as valid ' ...
                       'for discrete variable ' obj.label])
            end
        end
        
        function res = one_hot_trunc(obj,val)
            %creates truncated one hot vector for use with multiple
            %discrete variables
            %example: 
            % discrete variable pool: [12,16,30] %reagent IDs
            % choice: [16]
            % one hot vector: [0 1 0] 
            % 
            % truncated one hot vector: 
            % - assume effect of first element in discrete variable pool is
            % captured in offset
            % - indicate shift to other elements by one hot vector
            % discrete variable pool: [12,16,30]
            % choice: [12]
            % truncated one hot vector: [0 0]
            
            % discrete variable pool: [12,16,30]
            % choice: [16]
            % truncated one hot vector: [1 0]            

            % discrete variable pool: [12,16,30]
            % choice: [30]
            % truncated one hot vector: [0 1] 
            
            
            if strcmp(obj.type, 'continuous')
                error('Calling one_hot_trunc on continuous variable')    
            end
            
            n_res_digits = (size(obj.values,2)-1); %number of digits for truncated one-hot vector
            res = zeros(1,n_res_digits );
            
            for i = 1:n_res_digits %for the number of digits in truncated one_hot vector

            choice_index = find(obj.values==val);

            if ~isempty(choice_index) %make sure choice actually exists in pool

                for j = 1:size(obj.values,2) %for all choices in pool

                    if i + 1 == choice_index;

                        res(1,i) = 1;

                    end %end if i+1

                end %end for j
                
            else
                
                error('Discrete variable choice not in pool!') 

            end %end isempty        

            end  %end for i
            
            
        end % end one_hot_trunc
      
    end
    
end
