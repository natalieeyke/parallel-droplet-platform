function [inject_slug,inject_flag,abort] = ...
    cwc_check_can_inject_now(all_slugs, rinse_slugs, max_v1, V1, V3, T, T_tol, ana_time, warmup_time, cushion_time, hold_sys, hold_sys2, refill_hold)
% determines if we're ready to inject a slug that's waiting in the needle

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 5, 2012
% CWC
% June 17, 2015
%
% Inputs:
%               slug_tracker_prior is the current slug_tracker matrix
%               time is the current time (in sec)
%               v1 is the carrier phase flow rate (in uL/min)
%               v1_react is the effective carrier flow rate in the reactor at the set point temperature assuming feed at 25 deg. C (in uL/min)
%               max_v1 is the maximum v1 (in uL/min)
%               min_v1 is the minimum v1 (in uL/min)
%               V1 is the volume of tubing prior to reactor (in uL)
%               V2 is the volume of reactor (in uL)
%               V3 is the volume of tubing after the reactor (in uL)
%               buffer_length is the distance after a slug passes at which the flowrate changes (in uL)
%               lead_slug is the first slug which hasn't flown out of
%               the reactor + buffer_length
%               T is the measured temperature (in deg C)
%               T_tol is the absolute temperature tolerance (in deg C)
%               ana_time is the time needed for analysis (in min)
%               warmup_time is the time needed to start up the HPLC (in sec)
%               cushion_time is the time to wait between HPLC analyses (in sec)
%               hold_sys is 1 if no slugs are to be injected into system, 0 otherwise
%               hold_sys2 is 1 if no slugs are to be injected into system, 0 otherwise
%               refill_hold is 1 if no more slugs should be injected into system before refill, 0 otherwise
% Outputs:
%               inject_slug is 1 if prepared slug can be injected into
%               system, 0 otherwise
%               inject_flag denotes restriction for slug being injected, if
%               any
%               abort cancels slug injection if 1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set defaults
inject_slug = 0;
inject_flag = 'Default';
abort = 0;
    
% Find slug in prep which has not been injected into system
prep_slug = find(cwc_list_property(all_slugs, 'in_prep') - ...
                 cwc_list_property(all_slugs, 'injected') == 1, 1, 'first');

if isempty(prep_slug)
    inject_slug = 0;
    inject_flag = 'Couldnt get prep slug';
    abort = 0;
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check for slugs in system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if any(cwc_list_property(all_slugs, 'in_system') == 1)
    inject_slug = 0;
    inject_flag = 'Wait for slug to finish';
    return
end

if any(cwc_list_property(rinse_slugs, 'complete') == 0)
    inject_slug = 0;
    inject_flag = 'Wait for rinse slugs to finish';
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Check for hold on system
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if hold_sys >= 1
    inject_slug = 0;
    inject_flag = 'System Hold On';
    return
end

if hold_sys2 >= 1
    inject_slug = 0;
    inject_flag = 'System Hold On';
    return
end

if refill_hold >= 1
    inject_slug = 0;
    inject_flag = 'System Holding for Refill';
%     abort = 1;
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Temperature check
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% prep_slug temperature must be within reactor temperature and
% tolerance
if abs(T - all_slugs(prep_slug).temperature(1)) >= T_tol
    inject_slug = 0;
    inject_flag = 'Temp Tolerance Not Satisfied';
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This is test for adequate spacing in analysis
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hplc_slug = find(cwc_list_property(all_slugs, 'in_hplc') == 1, 1, 'first');
if ~isempty(hplc_slug)
    current_hplc_time = all_slugs(hplc_slug).analysis_time;
    time_from_inj_to_hplc = (V1 + V3) / 80 + ...
                            sum(all_slugs(prep_slug).residence_time_goal) / 60;

    if time_from_inj_to_hplc < ana_time + warmup_time / 60 + ...
                               cushion_time / 60 - current_hplc_time / 60
        inject_slug = 0;
        inject_flag = 'HPLC will not be finished';
        return
    end
end


% If all requirements are met, inject slug
inject_slug = 1;
inject_flag = 'Can inject now';

end