function [ W ] = cwc_optimization_slugs_to_weights( completed_slugs )
% cwc_optimization_slugs_to_weights converts all_slugs to a weights matrix
% that is Nexp x Nexp. For now, the weight is just the exp(obj)
% (so that as we get closer to the optimum, it will be weighted higher)

N = length(completed_slugs);
W = eye(N);

yields = cwc_list_property(completed_slugs, 'yield');

for i = 1:N
    W(i,i) = yields(i);
end %for

end