function [ reactor_slug ] = lmb_update_reactor_infusing_last_pass( reactor_slug, all_slugs, react_slug, time, num_passes_completed,oscillatory_vol )
%INFUSING: Updates reactor slug after PD detection ("oscillating waiting
%for PD detection") after last pass
% Input:
% reactor_slug
% all_slugs
% react_slug
% time
% num_passes_completed

% Output:
% reactor_slug

reactor_slug = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug );

%update fields of current infusing pass
reactor_slug.time_next_detection(num_passes_completed,1) = time;
reactor_slug.time_between_detections(num_passes_completed,1) = reactor_slug.time_next_detection(num_passes_completed,1) - reactor_slug.time_initial_detection(num_passes_completed,1);

if reactor_slug.time_between_detections(num_passes_completed,1) ~= 0
    
    reactor_slug.average_flow_rate_pass(num_passes_completed,1) = oscillatory_vol/reactor_slug.time_between_detections(num_passes_completed,1)*60;

end


end

