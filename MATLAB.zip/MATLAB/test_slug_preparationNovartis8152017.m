clc
clear
%May 19th 2017

reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_novartis.xlsx';
inj_vol = 20; %sample loop volume in �L
rho_tf = 786.0; %transfer fluid density in g/L


% reagent_table lists all reagents in the system
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

% slug_tracker is the matrix of slug information
% index identifies the information contained in each column of slug_tracker 
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
rinse_slugs = [];


[prep_slug,comp,all_slugs] =   cwc_get_next_slug_to_prep_v4(all_slugs,reagent_table,inj_vol,rho_tf);
all_slugs.istd_conc
 
 
 why