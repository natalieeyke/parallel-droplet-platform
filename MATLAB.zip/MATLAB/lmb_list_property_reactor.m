function [ property_list ] = lmb_list_property_reactor(reactor_history, property)
% Finds the property of each entry in 'reactor_history' and returns as list

if isempty(reactor_history)
    property_list = [];
    return
end

if length(reactor_history) == 1
    eval(['property_list = reactor_history(1).' property ';']);
    return
end

property_list = zeros(length(reactor_history), length(eval(['reactor_history(1).' property])));
for i = 1:length(reactor_history)
    eval(['property_list(i, :) = reactor_history(i).' property ';']);
end

end