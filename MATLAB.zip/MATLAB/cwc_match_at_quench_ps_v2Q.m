function [all_slugs, quench_matched] = ...
    cwc_match_at_quench_ps_v2Q(all_slugs, ps_dist, dist_tol, this_slug)
% this function finds what kind of slug was detected at hplc phase sensor
% v2Q is for multi-step chemistry where injections occur at outlet
%    must know which slug to expect
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% July 7, 2015
% Inputs:
%               all_slugs is list of reacting slugs
%               ps_dist is distance to hplc phase sensor
%               dist_tol is the tolerance (uL) for matching
%               this_slug is the index of the expected slug
%               
% Outputs:
%               all_slugs is the updated slug list
%               quench_matched is a flag if the slug was found
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Default
quench_matched = 0;

if ~this_slug
    return
end

% Check within distance tolerance
if and(abs(all_slugs(this_slug).distance - ps_dist) < dist_tol, ...
        all_slugs(this_slug).distance_matched > 150)
    quench_matched = 1;
    % Update distance with match
    all_slugs(this_slug).distance_matched = ps_dist;
end

end