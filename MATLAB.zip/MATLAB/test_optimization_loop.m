clear
clc

%%
%initialize
reagent_table_path = 'REAGENT_TABLE_LMB_20171003.xlsx';
simulate_function = 'lmb_optimization_simulate_multidiscrete';
noise = 0;

reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);

analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

 
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
all_slugs(1).reagent_2 = 9;
[ opt_state ] = cwc_optimization_define_v3(); 

% Use the first slug in all_slugs as a template for the D-opt design
load('tmp_all_slugs')
%   [ all_slugs ] = lmb_optimization_generate_ffd_v2( all_slugs, opt_state );


%%
%optimization


opt_done = 0;
update_optimization_prompt = 0;

while opt_done~=1
    
    incomplete_slugs = cwc_list_property(all_slugs, 'complete') == 0; 
     
    
    % Simulate  incomplete experiments
for i = 1:length(all_slugs)
    if all_slugs(i).complete == 0 
        
        all_slugs(i) = eval([simulate_function '(all_slugs(i), noise);']);
        all_slugs(i).complete = 1;
    
    end
end
    

% Do we need to add slugs now?
if not(any(incomplete_slugs))
    
    % Add the next round
    [ all_slugs, opt_state, output_prompt ] =  lmb_optimization_add_slugs_as_needed_v3(  all_slugs ,opt_state);

     update_optimization_prompt = 1;

     
     
end

opt_done = opt_state.opt_done;
end

why