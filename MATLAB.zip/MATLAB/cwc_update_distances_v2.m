function [all_slugs, rinse_slugs] = ...
    cwc_update_distances_v2(all_slugs, rinse_slugs, time_prior, time, v1, v1_react)
% updates distances of slugs and time in reactor
% v2 allows multi-step reactions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs are reacting slugs
%               rinse_slugs are current rinse slugs
%               time_prior is the time at which slug_tracker_prior was
%               computed (in sec)
%               time is the current time (in sec)
%               v1 is the carrier phase flow rate (in uL/min)
%               v1_react is the effective carrier flow rate in the reactor at the set point temperature assuming feed at 25 deg. C (in uL/min)
% Outputs:
%               updated all_slugs and rinse_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Update reacting slugs (rxn time for specific step)
for i = 1:length(all_slugs)
    if all_slugs(i).in_reactor
        all_slugs(i).distance = all_slugs(i).distance + ...
                            v1_react / 60 * (time - time_prior);
        all_slugs(i).residence_time_actual(all_slugs(i).in_reactor) = ...
        	all_slugs(i).residence_time_actual(all_slugs(i).in_reactor) + (time - time_prior);
    elseif all_slugs(i).in_system
        all_slugs(i).distance = all_slugs(i).distance + ...
                            v1 / 60 * (time - time_prior);
                        
    elseif all_slugs(i).in_hplc
        all_slugs(i).analysis_time = all_slugs(i).analysis_time + (time - time_prior);
        
    end
    
%     % Didn't match, but slug left system
%     if and(all_slugs(i).in_system == 1, all_slugs(i).distance > 1000)
%         all_slugs(i).in_system = 0;
%         all_slugs(i).complete = -1;
%         all_slugs = cwc_remake_failed_slug(all_slugs, all_slugs(i));
%     end
end

% Update rinse slugs
for i = 1:length(rinse_slugs)
%     if and(rinse_slugs(i).distance > 105, rinse_slugs(i).distance < 110)
%         rinse_slugs(i).in_reactor = 1;
%     end

    if rinse_slugs(i).in_reactor
        rinse_slugs(i).distance = rinse_slugs(i).distance + ...
                            v1_react / 60 * (time - time_prior);
    elseif rinse_slugs(i).in_system
        rinse_slugs(i).distance = rinse_slugs(i).distance + ...
                            v1 / 60 * (time - time_prior);
    end
    
    if and(rinse_slugs(i).complete == 0, rinse_slugs(i).distance > 1100)
        rinse_slugs(i).in_system = 0;
        rinse_slugs(i).in_reactor = 0;
        rinse_slugs(i).complete = 1;
    end
end

end