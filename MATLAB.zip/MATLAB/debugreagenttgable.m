reagent_table_path = 'C:\Users\Admin\Documents\Input\Reagent_table_hongkun_20170403.xlsx';

[reagent_table,reagent_table_index] = load_reagent_table(reagent_table_path);
