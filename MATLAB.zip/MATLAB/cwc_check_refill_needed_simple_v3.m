function [v1, refill_hold, refill_now] = cwc_check_refill_needed_simple_v3( ...
    all_slugs, v1_prior,  fill_vol1,refill_hold_prior)
% checks to see if a refill is needed, based on refilling every 4 slugs
% v2 lets refills occur when rinse slugs in system
% v3 outsourced update of fill volume 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% August 7, 2015
%
% Inputs:
%               all_slugs and rinse_slugs are lists of slugs
%               v1_prior is the current carrier phase flow rate (in uL/min)
%               fill_vol1 is the updated liquid volume in carrier syringe (in mL)
%               refill_hold_prior is 1 if no more slugs should be injected into system before refill, 0 otherwise
% Outputs:
%               
%               v1 is the carrier phase flow rate (in uL/min)
%               refill_hold is 1 if no more slugs should be injected into system before refill, 0 otherwise
%               refill_now is 1 if refill should start, 0 otherwise
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Set default
refill_hold = 0;
refill_now = 0;
v1 = v1_prior;


% Check if refill is needed (EVERY FOUR SLUGS)
if refill_hold_prior == 1 
    refill_hold = 1;
else
   sys_slug = find(cwc_list_property(all_slugs, 'in_system') == 1);
   if and(mod(sys_slug, 2) == 0, fill_vol1 < 7)
       refill_hold = 1;
   elseif fill_vol1 < 3.2 % new
       refill_hold = 1;
   end
end



% Check if refill should start now
if refill_hold == 1
    if sum(cwc_list_property(all_slugs, 'in_system')) == 0 
        refill_now = 1;
        v1 = 0;
    end
end

end