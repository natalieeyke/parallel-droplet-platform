function [ inject_rinse_now ] = cwc_check_can_inject_rinse( all_slugs, refill_hold )
% This function checks to see if a rinse slug can be injected
    
if refill_hold
    inject_rinse_now = 0;
    return
end

sys_slug = find(cwc_list_property(all_slugs, 'in_system') == 1, 1, 'first');
if sys_slug
    if all_slugs(sys_slug).inj_quench == 0
        inject_rinse_now = 0;
        return
    end
    % POTENTIALLY TEMPORARY: DON'T INJECT UNTIL IN HPLC LOOP
    inject_rinse_now = 0;
    return
end

inject_rinse_now = 1;

end

