function [ reactor_slug ] = lmb_update_reactor_withdrawing_pass( reactor_slug, all_slugs, react_slug, new_v1, outlet_comp_factor, inlet_comp_delay, time, num_passes_completed,oscillatory_vol )
%WITHDRAWING: update reactor slug after PD detection ("oscillating waiting for PD detection") while an withdrawing pass that is not
% the final pass
% Input:
% reactor_slug
% all_slugs
% react_slug
% new_v1: updated oscillatory flow rate of next pass
% inlet_comp_delay: compensation delay in s to stop current withdrawing pass
% time
% num_passes_completed
% outlet_comp_factor of next infusing pass

% Output:
% reactor_slug

reactor_slug = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug );

%update fields of current withdrawing pass
reactor_slug.compensation_delay(num_passes_completed,1) = inlet_comp_delay;
reactor_slug.time_next_detection(num_passes_completed,1) = time;
reactor_slug.time_between_detections(num_passes_completed,1) = reactor_slug.time_next_detection(num_passes_completed,1)- reactor_slug.time_initial_detection(num_passes_completed,1);

if reactor_slug.time_between_detections(num_passes_completed,1) ~= 0
    
       reactor_slug.average_flow_rate_pass(num_passes_completed,1) = oscillatory_vol/reactor_slug.time_between_detections(num_passes_completed,1) *60;

end

%update fields of next infusing pass
reactor_slug.oscill_flow_rate(num_passes_completed+1,1) = new_v1;  
reactor_slug.compensation_factor(num_passes_completed+1,1)= outlet_comp_factor;
reactor_slug.time_initial_detection(num_passes_completed+1,1)= time;




end

