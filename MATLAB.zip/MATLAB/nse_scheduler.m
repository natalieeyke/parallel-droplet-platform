function nse_scheduler(~)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v1: January 2022; built for demonstration and schedule visualization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
% Operation time spans
%rxns = [20, 18, 17, 16, 15, 15, 15, 14, 12, 11, 9, 8, 7, 5, 4, 4, 4, 3, 2, 1];
prep = 5;
travel_rinse_vent = 1;
method = 10;

N_rxns = 100;
%rxns = randi(10, 1, N_rxns);
rxns = 140 .* ones(1, N_rxns);
rxns = sort(rxns, 'descend');
N_reactors = 10;
N_timepoints = 5000;

% Populate each reaction one-by-one and verify
% Concerned about the size of the matrix
liquid_handler = zeros(1, N_timepoints);
main_path = zeros(1, N_timepoints);
reactors = zeros(N_reactors, N_timepoints);
hplc = zeros(1, N_timepoints);

% Create temporary copies of each function's array; after confirming that
% there's no overlap, update the original arrays
lh_start = int16(1);
for r = 1:N_rxns
    lh_temp = liquid_handler; main_path_temp = main_path;
    reactor_temp = reactors;
    lc_temp = hplc;
    
    % Select reactor
    reactor = mod(r, N_reactors);
    if reactor == 0
        reactor = N_reactors;
    end
    
    % Check for availability
    lh_end = lh_start + prep - 1;
    main_in_start = lh_end + 1;
    main_in_end = main_in_start + travel_rinse_vent - 1;
    reactor_start = main_in_end + 1;
    reactor_end = reactor_start + rxns(r) - 1;
    main_out_start = reactor_end + 1;
    main_out_end = main_out_start + travel_rinse_vent - 1;
    lc_start = main_out_end + 1;
    lc_end = lc_start + method - 1;
    busy = sum(lh_temp(1, lh_start : lh_end)) + ...
           sum(main_path_temp(1, main_in_start : main_in_end)) + ...
           sum(reactor_temp(reactor, reactor_start : reactor_end)) + ...
           sum(main_path_temp(1, main_out_start : main_out_end)) + ...
           sum(lc_temp(1, lc_start : lc_end));
    
    while busy
        lh_start = lh_start + 1;
        lh_end = lh_start + prep - 1;
        main_in_start = lh_end + 1;
        main_in_end = main_in_start + travel_rinse_vent - 1;
        reactor_start = main_in_end + 1;
        reactor_end = reactor_start + rxns(r) - 1;
        main_out_start = reactor_end + 1;
        main_out_end = main_out_start + travel_rinse_vent - 1;
        lc_start = main_out_end + 1;
        lc_end = lc_start + method - 1;

        busy = sum(lh_temp(1, lh_start : lh_end)) + ...
           sum(main_path_temp(1, main_in_start : main_in_end)) + ...
           sum(reactor_temp(1, reactor_start : reactor_end)) + ...
           sum(main_path_temp(1, main_out_start : main_out_end)) + ...
           sum(lc_temp(1, lc_start : lc_end));
        
    end

    liquid_handler(1, lh_start : lh_end) = r * ones(1, prep);
    main_path(1, main_in_start : main_in_end) = r * ones(1, travel_rinse_vent);
    reactors(reactor, reactor_start : reactor_end) = r * ones(1, rxns(r));
    main_path(1, main_out_start : main_out_end) = r * ones(1, travel_rinse_vent);
    hplc(1, lc_start : lc_end) = r * ones(1, method);
    
    lh_start = lh_start + prep;
    
end
C = cat(1, liquid_handler, main_path, reactors, hplc);
C = C ./ N_rxns;
cmap = parula;
[~, runtime] = max(hplc)
%imshow(C, 'InitialMagnification', 1600, 'Colormap', cmap)
%imshow(liquid_handler)
%imshow(main_path)
%imshow(reactors)
%imshow(hplc)
toc

end