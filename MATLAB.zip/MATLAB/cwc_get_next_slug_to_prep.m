function [prep_slug,comp,all_slugs,fill_min2,fill_min3] = cwc_get_next_slug_to_prep(all_slugs,reagent_table,reagent_table_index,inj_vol,rho_tf,fill_min2_prior,fill_min3_prior)
% SLUG_IN_PREP identifies composition of next slug to be prepared and
% updates the slug to reflect actual values (i.e., rounding)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs is the list of slugs
%               reagent_table is a matrix containing information in
%               reagent_table_path
%               reagent_table_index gives the header rows for reagent_table
%               inj_vol is the slug volume injected into the system (in uL)
%               rho_tf is the density of the transfer fluid (in g/L)
%               injection valve (in uL)
%               fill_min2_prior is the minimum fill volume needed for all precat slugs before precat injection point (in mL)
%               fill_min3_prior is the minimum fill volume needed for all base slugs before base injection point (in mL)
% Outputs:
%               prep_slug is the INDEX assigned to the slug
%               comp is the composition of the next slug to be prepared
%               all_slugs is the new list of slugs
%               fill_min2 is the minimum fill volume needed for all precat slugs before precat injection point (in mL)
%               fill_min3 is the minimum fill volume needed for all base slugs before base injection point (in mL)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find reagent number index
col_reag_num = find(strcmp(deblank(reagent_table_index),'Reagent Number') == 1);

% Find reagent type index
col_type = find(strcmp(deblank(reagent_table_index),'Type') == 1);

% Find molar mass index
col_mw = find(strcmp(deblank(reagent_table_index),'Molar Mass (g/mol)') == 1);

% Find reagent concentration (in M) index
col_reag_conc = find(strcmp(deblank(reagent_table_index),'Reagent Conc (M)') == 1);

% Find ISTD concentration (in g/L) index
col_istd = find(strncmp(deblank(reagent_table_index),'ISTD Conc',9) == 1);

% Find Density (in g/L) index
col_density = find(strncmp(deblank(reagent_table_index),'Density',7) == 1);

% Find rack number index
col_rack_id = find(strcmp(deblank(reagent_table_index),'Rack Number') == 1);

% Find rack placement index
col_place_id = find(strcmp(deblank(reagent_table_index),'Rack Placement') == 1);

% Find sample well number index
col_sample_id = find(strcmp(deblank(reagent_table_index),'Sample Well Number') == 1);

% Find first slug which has not been injected into system
i = find(cwc_list_property(all_slugs, 'injected') == 0, 1, 'first');

if i ~= 0
    % Update to make slug in prep
    all_slugs(i).in_prep = 1;
    
    % Return slug index, too
    prep_slug = i;
    
    % Target base concentration (M)
    rb_conc = all_slugs(i).base_conc;
    
    % Target precatalyst concentration (M)
    rp_conc = 0;
    
    % Bulk base concentration
    row_base = find(reagent_table(:,col_type) == 6);
    if isempty(row_base) == 0
        CB = reagent_table(row_base,col_reag_conc);
        C_ISTD_base = reagent_table(row_base,col_istd);
    else
        CB = 0;
        C_ISTD_base = 0;
    end
    
    % Bulk precat concentration
    row_precat = find(reagent_table(:,col_type) == 5);
    if isempty(row_precat) == 0
        CP = reagent_table(row_precat,col_reag_conc);
        C_ISTD_precat = reagent_table(row_precat,col_istd);
    else
        CP = 0;
        C_ISTD_precat = 0;
    end
    
    % Load Volume (uL)
    load_vol = all_slugs(i).prepared_vol*1000/rho_tf; % rho_tf corrects volume sampled (h_tf/h_0 = (g/g)*(rho_0/rho_tf))
    load_vol = round(load_vol*10)/10;
    
    % Slug volume = injection volume + (Slug volume)*(frac base) + (Slug volume)*(frac precat)
    if CB > 0
        if CP > 0
            slug_vol = inj_vol/(1 - rb_conc/CB - rp_conc/CP);
        else
            slug_vol = inj_vol/(1 - rb_conc/CB);
        end
    elseif CP > 0
        slug_vol = inj_vol/(1 - rp_conc/CP);
    else
        slug_vol = inj_vol;
    end
    slug_vol = round(slug_vol*10)/10;
    
    % Minimum precat fill volume
    if CP > 0
        precat_vol = round(rp_conc/CP*slug_vol*10)/10;
    else
        precat_vol = 0;
    end
    fill_min2 = fill_min2_prior + precat_vol/1000;
    
    % Minimum base fill volume and record
    base_vol = slug_vol - inj_vol - precat_vol;
    all_slugs(i).base_vol = base_vol;
    fill_min3 = fill_min3_prior + base_vol/1000;
    
    % Total ISTD added (g)
    ISTD_mass = 0;
    
    % Total ISTD added (g)
    ISTD_mass = ISTD_mass + C_ISTD_precat*precat_vol*1e-6 + C_ISTD_base*base_vol*1e-6;
    
    % Calculate composition and position of reagents
    comp = zeros(7,4);
    
    % Reagent 1
    % Bulk concentration (M)
    r1_num = find(reagent_table(:,col_reag_num) == all_slugs(i).reagent_1);
    c1 = reagent_table(r1_num,col_reag_conc);
    r1_density = reagent_table(r1_num,col_density)/1000; %relative to H2O    
    if isnan(c1) == 0
        % Desired concentration (M)
        r1_conc = all_slugs(i).reagent_1_conc;
        % Reagent volume (uL), rounded to nearest 0.1 uL
        comp(2,1) = round(r1_conc/c1*(load_vol/inj_vol)*slug_vol*r1_density*10)/10;
    else
        c1 = 0;
        comp(2,1) = 0;
    end
    % Position
    comp(2,2) = reagent_table(r1_num,col_rack_id);
    comp(2,3) = reagent_table(r1_num,col_place_id);
    comp(2,4) = reagent_table(r1_num,col_sample_id);
    
    % Reagent 2
    % Bulk concentration (M)
    r2_num = find(reagent_table(:,col_reag_num) == all_slugs(i).reagent_2);
    c2 = reagent_table(r2_num,col_reag_conc);
    r2_density = reagent_table(r2_num,col_density)/1000; %relative to H2O
    if isnan(c2) == 0
        % Desired concentration (M)
        r2_conc = all_slugs(i).reagent_2_conc;
        % Reagent volume (uL), rounded to nearest 0.1 uL
        comp(3,1) = round(r2_conc/c2*(load_vol/inj_vol)*slug_vol*r2_density*10)/10;
    else
        c2 = 0;
        comp(3,1) = 0;
    end
    % Position
    comp(3,2) = reagent_table(r2_num,col_rack_id);
    comp(3,3) = reagent_table(r2_num,col_place_id);
    comp(3,4) = reagent_table(r2_num,col_sample_id);
    
    % Reagent 3
    % Bulk concentration (M)
    r3_num = find(reagent_table(:,col_reag_num) == all_slugs(i).reagent_3);
    c3 = reagent_table(r3_num,col_reag_conc);
    r3_density = reagent_table(r3_num,col_density)/1000; %relative to H2O
    if isnan(c3) == 0
        % Desired concentration (M)
        r3_conc = all_slugs(i).reagent_3_conc;
        % Reagent volume (uL), rounded to nearest 0.1 uL
        comp(4,1) = round(r3_conc/c3*(load_vol/inj_vol)*slug_vol*r3_density*10)/10;
    else
        c3 = 0;
        comp(4,1) = 0;
    end
    % Position
    comp(4,2) = reagent_table(r3_num,col_rack_id);
    comp(4,3) = reagent_table(r3_num,col_place_id);
    comp(4,4) = reagent_table(r3_num,col_sample_id);
    
    % Reagent 4
    % Bulk concentration (M)
    r4_num = find(reagent_table(:,col_reag_num) == all_slugs(i).reagent_4);
    c4 = reagent_table(r4_num,col_reag_conc);
    r4_density = reagent_table(r4_num,col_density)/1000; %relative to H2O
    if isnan(c4) == 0
        % Desired concentration (M)
        r4_conc = all_slugs(i).reagent_4_conc;
        % Reagent volume (uL), rounded to nearest 0.1 uL
        comp(5,1) = round(r4_conc/c4*(load_vol/inj_vol)*slug_vol*r4_density*10)/10;
    else
        c4 = 0;
        comp(5,1) = 0;
    end
    % Position
    comp(5,2) = reagent_table(r4_num,col_rack_id);
    comp(5,3) = reagent_table(r4_num,col_place_id);
    comp(5,4) = reagent_table(r4_num,col_sample_id);
    
    % Reagent 5
    % Bulk concentration (M)
    r5_num = find(reagent_table(:,col_reag_num) == all_slugs(i).reagent_5);
    c5 = reagent_table(r5_num,col_reag_conc);
    r5_density = reagent_table(r5_num,col_density)/1000; %relative to H2O
    if isnan(c5) == 0
        % Desired concentration (M)
        r5_conc = all_slugs(i).reagent_5_conc;
        if r2_density ~= 1
            % Reagent volume (uL), rounded to nearest 0.1 uL
            comp(6,1) = round(r5_conc/c5*(load_vol/inj_vol)*slug_vol*r5_density*10)/10;
        else
            % Reagent volume (uL) minus volume of reagent 2 (This is for
            % reagent 2 in water, no makeup water desired)
            comp(6,1) = round(r5_conc/c5*(load_vol/inj_vol)*slug_vol*r5_density*10)/10 - comp(3,1);
        end
    else
        c5 = 0;
        comp(6,1) = 0;
    end
    % Position
    comp(6,2) = reagent_table(r5_num,col_rack_id);
    comp(6,3) = reagent_table(r5_num,col_place_id);
    comp(6,4) = reagent_table(r5_num,col_sample_id);
    
    % Makeup
    rm_num = find(reagent_table(:,col_reag_num) == all_slugs(i).makeup);
    rm_density = reagent_table(rm_num,col_density)/1000; %relative to H2O
    % Makeup volume (uL)
    sampled_vol = comp(2,1)/r1_density + comp(3,1)/r2_density + comp(4,1)/r3_density + comp(5,1)/r4_density + comp(6,1)/r5_density;
    comp(7,1) = round((load_vol - sampled_vol)*rm_density/2*10)/10;
    comp(1,1) = round(rm_density*(load_vol - sampled_vol - comp(7,1)/rm_density)*10)/10;
    % Position
    comp(1,2) = reagent_table(rm_num,col_rack_id);
    comp(1,3) = reagent_table(rm_num,col_place_id);
    comp(1,4) = reagent_table(rm_num,col_sample_id);
    comp(7,2) = reagent_table(rm_num,col_rack_id);
    comp(7,3) = reagent_table(rm_num,col_place_id);
    comp(7,4) = reagent_table(rm_num,col_sample_id);
    
    % Update load_vol
    load_vol = sampled_vol + comp(1,1)/rm_density + comp(7,1)/rm_density;
    
    % Correct slug concentration in slug_tracker
    all_slugs(i).reagent_1_conc = (comp(2,1)/r1_density)*c1/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_2_conc = (comp(3,1)/r2_density)*c2/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_3_conc = (comp(4,1)/r3_density)*c3/load_vol*inj_vol/slug_vol;
    all_slugs(i).reagent_4_conc = (comp(5,1)/r4_density)*c4/load_vol*inj_vol/slug_vol;
    if r2_density ~= 1
        all_slugs(i).reagent_5_conc = (comp(6,1)/r5_density)*c5/load_vol*inj_vol/slug_vol;
    else
        all_slugs(i).reagent_5_conc = ((comp(6,1)+comp(3,1))/r5_density)*c5/load_vol*inj_vol/slug_vol;
    end
    
    
    % Total ISTD added (g)
    ISTD_mass = ISTD_mass + reagent_table(r1_num,col_istd)*(comp(2,1)/r1_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + reagent_table(r2_num,col_istd)*(comp(3,1)/r2_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + reagent_table(r3_num,col_istd)*(comp(4,1)/r3_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + reagent_table(r4_num,col_istd)*(comp(5,1)/r4_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + reagent_table(r5_num,col_istd)*(comp(6,1)/r5_density)/load_vol*inj_vol*1e-6;
    ISTD_mass = ISTD_mass + reagent_table(rm_num,col_istd)*(comp(1,1)+comp(7,1))/rm_density/load_vol*inj_vol*1e-6;
    
     % Update slug volume in slug_tracker
    all_slugs(i).injected_vol = slug_vol;
    
    % Find molar mass of ISTD
    ISTD_num = find(reagent_table(:,col_type) == 9);
    ISTD_mw = reagent_table(ISTD_num,col_mw);
    
    % List ISTD concentration in slug_tracker
    ISTD_conc = (ISTD_mass/ISTD_mw)/(slug_vol*1e-6);
    all_slugs(i).istd_conc = ISTD_conc;
    
    % Temperature is accurate to 0.1oC
    all_slugs(i).temperature = round(all_slugs(i).temperature*10)/10;
    
else
    % Don't update slug_tracker. Return all zeros for comp
    prep_slug = 0;
    comp = zeros(7,4);
    fill_min2 = fill_min2_prior;
    fill_min3 = fill_min3_prior;
end

end