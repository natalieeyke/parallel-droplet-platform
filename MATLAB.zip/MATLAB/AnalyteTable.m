classdef AnalyteTable < handle

    % Defines the reagent table stock solutions
    properties
        analytes = [Analyte()];
    end
    
    methods
        function obj = load_from_file(obj, reagent_table_path)
            obj.analytes = []; % clear
            
            [num,txt,raw] = xlsread(reagent_table_path,'Analyte List','A1:Z200');
            headers = raw(1, :);
            col_id     = find(strncmp(headers,'Analyte Number',14), 1, 'first');
            col_name    = find(strncmp(headers,'Analyte Name',12), 1, 'first');
            col_type    = find(strncmp(headers,'Type',4), 1, 'first');
            col_rt_min    = find(strncmp(headers,'Min Ret Time',12), 1, 'first');
            col_rt_max   = find(strncmp(headers,'Max Ret Time',12), 1, 'first');
            col_cal    = find(strncmp(headers,'Linear',6), 1, 'first');
            col_wv    = find(strncmp(headers,'Wavelength',10), 1, 'first');
                                   
            % First row is header
            for i = 2:size(raw, 1)
                newAnalyte = Analyte();
                
                newAnalyte.id = raw{i, col_id};
                if isnan(newAnalyte.id)
                    break % done with table
                end
                
                newAnalyte.id = raw{i, col_id};
                newAnalyte.name = raw{i, col_name};
                newAnalyte.type = find(raw{i, col_type} == ['ABCMPXRSTIWD']); %1 = A, 4 = M
                newAnalyte.min_ret_time = raw{i, col_rt_min};
                newAnalyte.max_ret_time = raw{i, col_rt_max};
                newAnalyte.linear_calib = raw{i, col_cal};
                newAnalyte.wavelength = raw{i, col_wv};
                
                obj.analytes = [obj.analytes newAnalyte];
            end
            
           
        end
        
        function analyte = find_by_id(obj, id)
            analyte = obj.analytes(find([obj.analytes.id] == id, 1, 'first'));
            if isempty(analyte)
                analyte = [];
            end
        end
    end
end

