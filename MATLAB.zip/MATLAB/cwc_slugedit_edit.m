function [ all_slugs, edit_flag ] = cwc_slugedit_edit( all_slugs, index, ...
    field, fieldpretty, value )
% Given the all_slugs array and the index of a slug to remake, this script
% does just that

edit_flag = ['Cannot edit slug ' num2str(all_slugs(index).number) '''s "' fieldpretty '" anymore'];

% Trying to change slug composition, must occur before preparation or
% injection
if strcmp(field, 'reagent_1') || ...
        strcmp(field, 'reagent_1_conc') || ...
        strcmp(field, 'reagent_2') || ...
        strcmp(field, 'reagent_2_conc') || ...
        strcmp(field, 'reagent_3') || ...
        strcmp(field, 'reagent_3_conc') || ...
        strcmp(field, 'reagent_4') || ...
        strcmp(field, 'reagent_4_conc') || ...
        strcmp(field, 'reagent_5') || ...
        strcmp(field, 'reagent_5_conc') || ...
        strcmp(field, 'makeup')
    if (all_slugs(index).in_prep ~= 0 || all_slugs(index).injected ~= 0)
        return
    end
    value_num = str2double(value);
    if isnan(value_num)
        edit_flag = ['Invalid value ' value ' for field "' fieldpretty '"'];
        return
    end
    all_slugs(index).(field) = value_num;
    edit_flag = ['Set slug ' num2str(all_slugs(index).number) '''s "' ...
        fieldpretty '" to ' value];
    return
end

if strcmp(field, 'quench_vol') || ...
        strcmp(field, 'base_vol')
    if all_slugs(index).injected ~= 0
        return
    end
    value_num = str2double(value);
    if isnan(value_num)
        edit_flag = ['Invalid value ' value ' for field "' fieldpretty '"'];
        return
    end
    all_slugs(index).(field) = value_num;
    edit_flag = ['Set slug ' num2str(all_slugs(index).number) '''s "' ...
        fieldpretty '" to ' value];
    return
end

% Trying to change online injection, res time, can occur once injected
if strcmp(field, 'residence_time_goal') || ...
        strcmp(field, 'temperature') || ...
        strcmp(field, 'multi_injections')
    if all_slugs(index).injected ~= 0
        return
    end
    if isempty(strfind(value, '@'))
        value_num = str2double(strsplit(value, ';'));
    else
        value_num = strsplit(value, ';');
    end
    all_slugs(index).(field) = value_num;
    edit_flag = ['Set slug ' num2str(all_slugs(index).number) '''s "' ...
        fieldpretty '" to ' value];
    return
end

% Changing sampletime can be whenever
if strcmp(field, 'hplc_sampletime')
    if all_slugs(index).in_hplc || all_slugs(index).analysis_time
        return
    end
    value_num = str2double(value);
    if isnan(value_num)
        edit_flag = ['Invalid value ' value ' for field "' fieldpretty '"'];
        return
    end
    all_slugs(index).(field) = value_num;
    edit_flag = ['Set slug ' num2str(all_slugs(index).number) '''s "' ...
        fieldpretty '" to ' value];
    return
end

end