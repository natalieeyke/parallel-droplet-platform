classdef ReagentTable < handle

    % Defines the reagent table stock solutions
    properties
        reagents = [Reagent()];
    end
    
    methods
        function obj = load_from_file(obj, reagent_table_path)
            obj.reagents = []; % clear
            
            [num,txt,raw] = xlsread(reagent_table_path,'Reagent List','A1:Z200');
            headers = raw(1, :);
            col_id      = find(strncmp(headers,'Reagent Number',14), 1, 'first');
            col_name    = find(strncmp(headers,'Reagent Name',12), 1, 'first');
            col_type    = find(strncmp(headers,'Type',4), 1, 'first');
            col_conc    = find(strncmp(headers,'Reagent Conc (M)',16), 1, 'first');
            col_istd    = find(strncmp(headers,'ISTD',4),1, 'first');
            col_density = find(strncmp(headers,'Density',7),1, 'first');
            col_rack    = find(strncmp(headers,'Rack Num',8), 1, 'first');
            col_place   = find(strncmp(headers,'Rack Pla',8), 1, 'first');
            col_well    = find(strncmp(headers,'Sample',6), 1, 'first');
                        
            % First row is header
            for i = 2:size(raw, 1)
                newReagent = Reagent();
                
                newReagent.id = raw{i, col_id};
                if isnan(newReagent.id)
                    break % done with table
                end
                
                newReagent.name = raw{i, col_name};
                newReagent.type = find(raw{i, col_type} == ['ABCMPXRSTIWD']);
                newReagent.conc = raw{i, col_conc};
                if ~isempty(raw{i, col_istd})
                    newReagent.istd_conc = raw{i, col_istd};
                else
                    newReagent.istd_conc = 0;
                end
                if ~isempty(raw{i, col_density})
                    newReagent.density = raw{i, col_density};
                else
                    newReagent.density = 1000;
                end
                newReagent.RackID = raw{i, col_rack};
                newReagent.PlaceID = raw{i, col_place};
                newReagent.WellID = raw{i, col_well};
                
                obj.reagents = [obj.reagents newReagent];
            end
            
           
        end
        
        function reagent = find_by_id(obj, id)
            reagent = obj.reagents(find([obj.reagents.id] == id, 1, 'first'));
            if isempty(reagent)
                reagent = [];
            end
        end
    end
end

