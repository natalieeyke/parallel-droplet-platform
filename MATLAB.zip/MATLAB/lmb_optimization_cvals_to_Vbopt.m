function [ G ] = lmb_optimization_cvals_to_Vbopt( cvals, dvals, opt_vars, ...
                                                      lin, X, T, T2, ...
                                                      X_opt_obj, X_opt_y, ...
                                                      obj_vals, log_yield_vals, ...
                                                      completed_slugs , removed_dvals )
   
 % lmb: adapted for multiple discrete variables                                                 
% New slug
slug = cwc_optimization_cdvals_to_slug(cvals, dvals, opt_vars);
if lin
    [ X_new ] = lmb_optimization_slugs_to_linmat( slug, opt_vars, removed_dvals );
else
    [ X_new ] = lmb_optimization_slugs_to_quadmat( slug, opt_vars, removed_dvals );
end
X = [X; X_new];

% Get overall W matrix
W_unnorm = cwc_optimization_slugs_to_weights( completed_slugs );
W_unnorm(end + 1, end + 1) = exp(X_new * T2);
W = W_unnorm * length(diag(W_unnorm)) / sum(diag(W_unnorm)); % normalize, so that sum of weights = 1

% Append to experimental data
obj_vals = [obj_vals; X_new * T]; %T: vector of model parameters
log_yield_vals = [log_yield_vals; X_new * T2];

[~, ~, mse_obj, ~] = lscov(X, obj_vals, diag(W)); % objective %mse mean square error
[~, ~, mse_y, ~] = lscov(X, log_yield_vals, diag(W)); % yield

%G = X_opt * (X' * W * X)^-1 * X_opt';
innermat2 = X' * W * X;
G_obj = sqrt(mse_obj * (X_opt_obj * (innermat2 \ X_opt_obj')));
G_y = sqrt(mse_y * (X_opt_y * (innermat2 \ X_opt_y')));

% G-optimal criterion
G = G_obj + G_y; % equal weighting between yield and obj

end