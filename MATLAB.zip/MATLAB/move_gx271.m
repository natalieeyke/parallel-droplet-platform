function [new_pos,Z_pos] = move_gx271(RackID,PlaceID,SampleID)
%MOVE_GX271 finds X/Y and Z coordinates to move GX-271 liquid handler robot to

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% September 30, 2011
% Determines X/Y and Z coordinates for a given rack and sample #
% Inputs:
%               RackID is the Gilson rack #
%               PlaceID is the Gilson rack placement (1 left, 2 middle)
%               SampleID is the sample vial number
% Outputs:
%                new_pos is the position to move the liquid handler
%                to in "X_pos/Y_pos"
%                z_pos is the height to lower the arm to
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Do for Rack #200 or #209
if RackID == 200 || RackID == 209
    
        % X coordinate is in increments of 16
        rack_col = floor((SampleID-1)/16);
        % Spacing is 16.3 mm, Start is 36 mm for place 1 and 156 mm for place 2
        if PlaceID == 1
            X_pos = round(16.3*rack_col + 36);
        elseif PlaceID == 2
            X_pos = round(16.3*rack_col + 156);
        end

        % Y-coordinate slolums
        if SampleID <= 16
                  rack_row = mod(SampleID-1,16);
                  offset = 0;
        elseif SampleID <= 32
                  rack_row = mod(17-(SampleID+1),16);
                  offset = 9;
        elseif SampleID <= 48
                  rack_row = mod(SampleID-1,16);
                  offset = 0;
        elseif SampleID <= 64
                  rack_row = mod(17-(SampleID+1),16);
                  offset = 9;
        elseif SampleID <= 80
                  rack_row = mod(SampleID-1,16);
                  offset = 0;
        elseif SampleID <= 96
                  rack_row = mod(17-(SampleID+1),16);
                  offset = 9;
        end
        % Spacing is 17.8 mm, Start is 9 mm + offset
        Y_pos = round(17.8*rack_row + 9 + offset);
        
        % Z position
        if RackID == 209
            Z_pos = 164; % usually 162, changed on 29Jul21 NSE
        else
            Z_pos = 89;
        end
            
end 

% Do for Rack #207
if RackID == 207
       
        % X coordinate is in increments of 15
        rack_col = floor((SampleID-1)/15);
        % Spacing is 19.4 mm, Start is 38 mm for place 1 and 157 mm for place 2
        if PlaceID == 1
            X_pos = round(19.4*rack_col + 38);
        elseif PlaceID == 2
            X_pos = round(19.4*rack_col + 157);
        end

        % Y-coordinate slolums
        if SampleID <= 15
                  rack_row = mod(SampleID-1,15);
        elseif SampleID <= 30
                  rack_row = mod(16-(SampleID+1),15);
        elseif SampleID <= 45
                  rack_row = mod(SampleID-1,15);
        elseif SampleID <= 60
                  rack_row = mod(16-(SampleID+1),15);
        elseif SampleID <= 75
                  rack_row = mod(SampleID-1,15);
        end
        % Spacing is 19.4 mm, Start is 11 mm
        Y_pos = round(19.4*rack_row + 11);
        
        % Z position
        Z_pos = 92;

end

% Do for Rack #220
if RackID == 220 || RackID == 221
       
        % X coordinate is in increments of 15
        rack_col = floor((SampleID-1)/14);
        % Spacing is 20.4 mm, Start is 36.5 mm for place 1 and 155.3 mm for place 2
        if PlaceID == 1
            X_pos = round(10*(20.4*rack_col + 36.5))/10;
        elseif PlaceID == 2
            X_pos = round(10*(20.4*rack_col + 155.3))/10;
        end

        % Y-coordinate slolums
        if SampleID <= 14
                  rack_row = mod(SampleID-1,14);
        elseif SampleID <= 28
                  rack_row = mod(15-(SampleID+1),14);
        elseif SampleID <= 42
                  rack_row = mod(SampleID-1,14);
        elseif SampleID <= 56
                  rack_row = mod(15-(SampleID+1),14);
        elseif SampleID <= 70
                  rack_row = mod(SampleID-1,14);
        end
        % Spacing is 21.1 mm, Start is 9.8 mm
        Y_pos = round(10*(21.1*rack_row + 9.8))/10;
        
        % Z position
        if RackID == 221
            Z_pos = 135.5;
        else
            Z_pos = 131;
        end

end

% Convert to a string
X_str = num2str(X_pos);
Y_str = num2str(Y_pos);
new_pos = [X_str '/' Y_str];
Z_pos = num2str(Z_pos);

end

