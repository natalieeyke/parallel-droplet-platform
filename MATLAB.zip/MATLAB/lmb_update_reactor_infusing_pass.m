function [ reactor_slug ] = lmb_update_reactor_infusing_pass( reactor_slug, all_slugs, react_slug, new_v1, outlet_comp_delay, inlet_comp_factor,  time, num_passes_completed,oscillatory_vol )
%INFUSING: Updates reactor slug after PD detection ("oscillating waiting for PD detection") while an infusing pass that is not
% the final pass
% Input:
% reactor_slug
% all_slugs
% react_slug
% new_v1: updated oscillatory flow rate of next pass
% outlet_comp_delay compensation delay at outlet to stop infusing slug
% time
% num_passes_completed
% inlet_comp_factor: compensation factor at inlet for next pass

% Output:
% reactor_slug


reactor_slug = lmb_copy_fields_reactor( reactor_slug, all_slugs, react_slug );

%update fields of current infusing pass
reactor_slug.compensation_delay(num_passes_completed,1) = outlet_comp_delay;
reactor_slug.time_next_detection(num_passes_completed,1) = time;
reactor_slug.time_between_detections(num_passes_completed,1) = reactor_slug.time_next_detection(num_passes_completed,1) - reactor_slug.time_initial_detection(num_passes_completed,1);

if reactor_slug.time_between_detections(num_passes_completed,1) ~= 0
    
    reactor_slug.average_flow_rate_pass(num_passes_completed,1) = oscillatory_vol/reactor_slug.time_between_detections(num_passes_completed,1)*60;

end

%update fields of next withdrawing pass
reactor_slug.oscill_flow_rate(num_passes_completed+1,1) = -1*new_v1;  
reactor_slug.compensation_factor(num_passes_completed+1,1)= inlet_comp_factor;
reactor_slug.time_initial_detection(num_passes_completed+1,1)= time;





end

