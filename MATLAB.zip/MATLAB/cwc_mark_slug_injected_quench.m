function [all_slugs] = cwc_mark_slug_injected_quench(all_slugs, inj_slug, inj_vol)
% marks a slug as being injected into with quench

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% December 11, 2011
% CWC
% July 7, 2015
%
% Inputs:
%               all_slugs list of slugs
%               inj_slug is the INDEX assigned to the injected slug
%               inj_vol is the volume to inject
% Outputs:
%               updated all_slugs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_slugs(inj_slug).inj_quench = 1;
all_slugs(inj_slug).current_vol = all_slugs(inj_slug).current_vol + inj_vol;

end