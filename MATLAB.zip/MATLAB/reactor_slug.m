classdef reactor_slug
    % Slug describes a slug in the system
    % v2 includes multiple-step chemistry, where base injections in uL
    
    properties
        number = 0;
        reagent_1 = 0;
        reagent_1_conc = 0;
        reagent_2 = 0;
        reagent_2_conc = 0;
        reagent_3 = 0;
        reagent_3_conc = 0;
        reagent_4 = 0;
        reagent_4_conc = 0;
        reagent_5 = 0;
        reagent_5_conc = 0;
        makeup = 0;
        prepared_vol = 0;
        injected_vol = 0;
        current_vol = 0;
        base_vol = 0;
        quench_vol = 0;
        temperature = [];
        residence_time_goal = [];
        multi_injections = {};
        multi_injected = [];
        residence_time_actual = [];
        istd_conc = 0;
        in_prep = 0;
        in_system = 0;
        injected = 0;
        in_reactor = 0;
        in_hplc = 0;
        distance = 0;
        distance_matched = 0;
        inj_base = 0;
        inj_quench = 0;
        analysis_time = 0;
        complete = 0;
        yield = 0;
        objective = 0;
        
        %log pass information
        index = [];%index of slug in reactor history
        timestamp = [];%timestamp at which slug was created
        nPasses = [];
        
        oscill_flow_rate = [];  %target oscillatory during pass
        compensation_factor = []; %compensation factor at beginning of pass
        compensation_delay = []; %compensation delay at beginning of pass
        
        time_initial_detection = []; %time at beginning of pass
        time_next_detection = [];  %time at end of pass
        time_PS2_detection = [];    %time when slug is detected at phase sensor 2

        time_between_PD_PS2 = [];
        time_between_detections = [];
        average_flow_rate_pass = [];
        average_flow_rate_PD_PS2 = [];
        
    end
    
    methods
    end
    
end

