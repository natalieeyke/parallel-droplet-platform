clc
clear
RackID = 350;
PlaceID = 1;
SampleID = 10;

[New_XY_1, New_Z_1] = move_gx241(RackID, PlaceID, SampleID);

RackID = 350;
PlaceID = 1;
SampleID = 9;


[New_XY_2, New_Z_2] = move_gx241(RackID, PlaceID, SampleID);