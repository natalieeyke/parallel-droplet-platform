function [] = slug_analysis_write_v2(ana_path,data_path,ana_slug,ret_time,area,conc,analyte_table)
%SLUG_ANALYSIS_WRITE records slug analysis results

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BJR
% January 23, 2012
% Inputs:
%               ana_path is the path to the file where analysis data are
%               stored
%               data_path is the HPLC output file location
%               ana_slug is the slug currently in analysis
%               ret_time is a matrix of retention times for the reagent
%               numbers in reagent_table
%               area is a matrix of peak areas for the reagent numbers in
%               reagent_table
%               conc is the calibrated chromatogram concentrations
% Outputs:
%               None
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid4 = -1;

while fid4 < 0
    
    % Load analysis file
    fid4 = fopen(ana_path,'a');
    
    if fid4 < 0
        fclose('all');
    end
    
end

% Write header
fprintf(fid4,'--------------------------------------------------------------------\r\n');
fprintf(fid4,'                            Slug %d                                 \r\n',ana_slug);
fprintf(fid4,'--------------------------------------------------------------------\r\n');
fprintf(fid4,' Reagent Name | Ret Time (min) | Peak Area (mAU*s) | Concentration (M) or g/L for ISTD \r\n',ana_slug);

% Loop for all reagents
for reag_row = 1:length(ret_time(:,1))
    
    reag_id = ret_time(reag_row,1);
    analyte_index = [analyte_table.analytes.id] == reag_id;
    reag_name = analyte_table.analytes(analyte_index).name;
  
    ret = ret_time(reag_row,2);
    a = area(reag_row,2);
    c = conc((conc(:,1) == reag_id),2);
    
    if isempty(c)
        if analyte_table.analytes(analyte_index).type == 10
            fprintf(fid4,' %s (ISTD) |     %6.3f     |   %12.5f    |      - \r\n',reag_name,ret,a);% Mark internal standard
        else
            fprintf(fid4,' %s    |     %6.3f     |   %12.5f    |      - \r\n',reag_name,ret,a);% Write to file
        end
        
    else
        
        if analyte_table.analytes(analyte_index).type == 10
            fprintf(fid4,' %s (ISTD) |     %6.3f     |   %12.5f    |      %6.5f \r\n',reag_name,ret,a,c);% Mark internal standard
        else
            fprintf(fid4,' %s    |     %6.3f     |   %12.5f    |      %6.5f \r\n',reag_name,ret,a,c);% Write to file
        end
        
    end
    
    
    

    
    
end

fprintf(fid4,'\r\n');

% File name for HPLC data
file_name = [data_path '\REPORT01.xls'];

% Record location of HPLC data file
fprintf(fid4,'See %s for HPLC Data\r\n',file_name);

fprintf(fid4,'\r\n');

% Close list of slugs
fclose(fid4);

end