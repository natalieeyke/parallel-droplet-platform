function [ completed_slugs ] = cwc_optimization_completed_slugs( all_slugs )
% cwc_optimization_completed_slugs returns only those slugs which are
% completed

complete = cwc_list_property(all_slugs, 'complete') == 1;
completed_slugs = all_slugs(complete);

end