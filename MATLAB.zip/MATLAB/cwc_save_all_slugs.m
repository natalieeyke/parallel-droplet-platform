function [] = cwc_save_all_slugs(all_slugs, path)
% dumps all_slugs so it can be re-read by LabView

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% CWC
% June 29, 2016
%
% Inputs:
%               all_slugs is the list of slugs
%               path is the file to save to
% Outputs:
%               None
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid1 = -1;

while fid1 < 0
    
    % Load list of slugs
    fid1 = fopen(path,'w');
    
    if fid1 < 0
        fclose('all');
    end
    
end

% Loop for all slugs
for i = 1:length(all_slugs)
    num = all_slugs(i).number;
    r1 = all_slugs(i).reagent_1;
    c1 = all_slugs(i).reagent_1_conc;
    r2 = all_slugs(i).reagent_2;
    c2 = all_slugs(i).reagent_2_conc;
    r3 = all_slugs(i).reagent_3;
    c3 = all_slugs(i).reagent_3_conc;
    r4 = all_slugs(i).reagent_4;
    c4 = all_slugs(i).reagent_4_conc;
    r5 = all_slugs(i).reagent_5;
    c5 = all_slugs(i).reagent_5_conc;
    mk = all_slugs(i).makeup;
    vol = all_slugs(i).current_vol
    base = all_slugs(i).base_conc;
    qu = all_slugs(i).quench_vol;
    temp = all_slugs(i).temperature;
    rt = all_slugs(i).residence_time_goal;
    
    % Write to file
    fprintf(fid1,'%6.0f  |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f      %6.3f   |%6.0f  |    %6.1f     |    %6.3f     |     %6.3f      |    %6.1f    |   %6.0f \r\n',num,r1,c1,r2,c2,r3,c3,r4,c4,r5,c5,mk,vol,base,qu,temp,rt);    
end

% Close list of slugs
fclose(fid1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while fid2 < 0
    
    % Load slug status
    fid2 = fopen(status_path,'a');
    
    if fid2 < 0
        fclose('all');
    end
    
end

% Write header
fprintf(fid2,'@%6.1f s -------------------------------------------------------------------------------------------------------------------------------------------\r\n', time);
fprintf(fid2,' Slug # | In Preparation | Injected into System | Injected into HPLC | Completed | Distance Traveled (uL) | Time in Reactor (s) | Analysis Time (s) \r\n');
fprintf(fid2,'----------------------------------------------------------------------------------------------------------------------------------------------------\r\n');

% Loop for all slugs
for i = 1:length(all_slugs)
    num = all_slugs(i).number;
    prep = all_slugs(i).in_prep;
    if prep == 1
        prep = sprintf('Yes');
    else
        prep = sprintf('No ');
    end
    sys = all_slugs(i).in_system;
    if sys == 1
        sys = sprintf('Yes');
    else
        sys = sprintf('No ');
    end
    lc = all_slugs(i).in_hplc;
    if lc == 1
        lc = sprintf('Yes');
    else
        lc = sprintf('No ');
    end
    comp = all_slugs(i).complete;
    if comp == 1
        comp = sprintf('Yes');
    else
        comp = sprintf('No ');
    end
    dis = all_slugs(i).distance;
    react = all_slugs(i).residence_time_actual;
    ana = all_slugs(i).analysis_time;
    
    % Write to file
    fprintf(fid2,'%6.0f  |      %s       |         %s          |        %s         |    %s    |         %6.1f         |       %6.1f        |      %6.1f       \r\n',num,prep,sys,lc,comp,dis,react,ana);    
end

% Close slug status list
fclose(fid2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while fid3 < 0
    
    % Load system data
    fid3 = fopen(system_path,'a');
    
    if fid3 < 0
        fclose('all');
    end
    
end

% Write to file
fprintf(fid3,'  %6.1f  |           %6.3f           |       %6.1f        |        %6.1f         \r\n',time,v1,T,T_set);

% Close system status list
fclose(fid3);

end