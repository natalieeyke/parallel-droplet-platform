function [ lin, percent_improve, N_extra, ...
    yield_criterion, tol, patience, buffer, counter_i, not_improving, prev_best_b, ...
    fathomed_dvals, removed_dvals, opt_done, opt_variables, all_slugs_ret ] = ...
    cwc_kwg_optimization_add_slugs_as_needed( lin, percent_improve, N_extra, ...
    yield_criterion, tol, patience, buffer, counter_i, not_improving, prev_best_b, ...
    fathomed_dvals, removed_dvals, opt_done, opt_variables, all_slugs_old ) 
                                   

%% Get RSM parameters
% Get experimental matrix
all_slugs = all_slugs_old; %create a copy that can be modified
all_slugs_ret = all_slugs_old; %return original list of all slugs

for i = 1:length(removed_dvals)%remove slugs with removed discrete variables before fitting model parameters
    [ all_slugs, opt_variables_new ] = ...
        kwg_dvals_remove( all_slugs, opt_variables, removed_dvals(i) );
end



[ completed_slugs ] = cwc_optimization_completed_slugs( all_slugs );
if lin
    [ X ] = cwc_optimization_slugs_to_linmat( completed_slugs, opt_variables );
else
    [ X ] = cwc_optimization_slugs_to_quadmat( completed_slugs, opt_variables );
end
[ dval_labels ] = cwc_optimization_slugs_to_dval_labels( completed_slugs, opt_variables );

% Get weights
[ W_unnorm ] = cwc_optimization_slugs_to_weights( completed_slugs );
[ W ] = W_unnorm * length(diag(W_unnorm)) / sum(diag(W_unnorm)); % normalized so average == 1

% Get objective function values
[ b ] = cwc_list_property( completed_slugs, 'objective' );

% Get yield values 
[ yield_vals ] = cwc_list_property( completed_slugs, 'yield' );
[ log_yield_vals ] = log( yield_vals );

% Get concentrations of catalyst
[ conc ] = cwc_list_property( completed_slugs, 'reagent_1_conc');

% Get WLS parameters
disp(['number of completed experiments: ' num2str(length(b))])
disp(['number of parameters:            ' num2str(size(X, 2))])
disp(['rank of X:                       ' num2str(rank(X,tol))])
if length(b) < size(X, 2)
    warning('More parameters to fit than experiments')
end
if rank(X,tol) < size(X, 2)
    warning('More parameters to fit than rank of X')
end

% Response surface fitting
[T_obj, stdT_obj, mse_obj, S_obj] = lscov(X, b, diag(W)); % objective
[T_y, stdT_y, mse_y, S_y] = lscov(X, log_yield_vals, diag(W)); % yield

% Get predictions
b_hat = X * T_obj;
y_hat = X * T_y;

%% Plot current data
% Get confidence bounds on prediction for response at each point
b_hat_pm = zeros(size(b_hat)); 
y_hat_pm = zeros(size(y_hat));
b_hat_pm_mean = zeros(size(b_hat));
y_hat_pm_mean = zeros(size(y_hat));

innermat = inv(X' * W * X);

for i = 1:length(b_hat)
    % CI for individual response at X(i,:) of obj
    b_hat_pm(i) = tinv(0.99, length(b) - length(T_obj)) * ...
                  sqrt(mse_obj * (1 + X(i, :) * innermat * X(i, :)'));

    % CI for mean response at X(i, :) of obj
    b_hat_pm_mean(i) = tinv(0.99, length(b) - length(T_obj)) * ...
                       sqrt(mse_obj * X(i, :) * innermat * X(i, :)');

    % CI for individual response at X(i, :) of yield
    y_hat_pm(i) = tinv(0.99, length(log_yield_vals) - length(T_y)) * ...
                  sqrt(mse_y * (1 + X(i, :) * innermat * X(i, :)'));

    % CI for mean response at X(i, :) of yield
    y_hat_pm_mean(i) = tinv(0.99, length(log_yield_vals) - length(T_y)) * ...
                       sqrt(mse_y * X(i, :) * innermat * X(i, :)');
end %for

%% Use the predicted optimum to see if we can fathom any discrete vars
check = false; % initialize
fathomed_pre = false; % initialize

% Check if we can remove experiments from fathomed queue
for i = 1:length(fathomed_dvals)
    [ all_slugs_new, opt_variables_new ] = ...
        kwg_dvals_remove( all_slugs, opt_variables, fathomed_dvals(i) );

    [ check ] = kwg_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol );

    if check
        removed_exp = length(all_slugs) - length(all_slugs_new);

        all_slugs = all_slugs_new;
        opt_variables = opt_variables_new;

        disp(['Fathoming out discrete variable set ' ...
               num2str(fathomed_dvals(i)) ' from fathom queue'])
        disp(['...removed ' num2str(removed_exp) ' experiments'])

        removed_dvals = [removed_dvals, fathomed_dvals(i)]; % add to removed variable list
        fathomed_dvals(i) = 0; % place holder 0

        fathomed_pre = true;
    end %if
end %for 
removals = find(fathomed_dvals == 0);
fathomed_dvals(removals) = []; % remove from fathomed list

if fathomed_pre
    disp(['reset convergence timer, making progress!'])
    not_improving = -1;
    return
end %if

% Find the predicted optima
[ cvals_opts, b_opts, yield_opts, dvals_combos ] = ...
    cwc_kwg_optimization_estimate_max( T_obj, T_y, opt_variables, lin, ...
                                       fathomed_dvals, removed_dvals, ...
                                       yield_criterion);

% Get maximum yield
max_yield = max(yield_opts);

% Get maximum objective
[b_opt_max, i_opt] = max(b_opts);

% Get yield/cvals/dvals at maximum objective
y_opt_max = yield_opts(i_opt);
cvals_opt_max = cvals_opts(:, i_opt);
dvals_opt_max = dvals_combos(:, i_opt);

disp(['> estimated max objective at dvals = ' num2str(dvals_opt_max) ...
      ', cvals = ' num2str(cvals_opt_max')]);
disp(['> estimated max objective = ' num2str(b_opt_max)])
disp(['> estimated global max yield = ' num2str(exp(max_yield))])

% Estimate uncertainty at optimum
X_opt = cwc_optimization_cvals_to_X( cvals_opt_max, dvals_opt_max, ...
                                     opt_variables, lin );

innermat = inv(X' * W * X);
b_opt_std = sqrt(mse_obj * (X_opt * innermat * X_opt'));
y_opt_std = sqrt(mse_y * (X_opt * innermat * X_opt'));
b_opt_pm = tinv(0.99, length(b) - length(T_obj)) * b_opt_std;
y_opt_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_opt_std;

% Prediction lower bound
b_opt_lb = b_opt_max - b_opt_pm;

disp(['> b_hat = ' num2str(b_opt_max) ' +/- ' num2str(b_opt_pm) ...
      ' (99% conf. interval)']);
disp(['> y_hat = ' num2str(exp(y_opt_max)) ' +/- ' num2str(y_opt_pm) ...
      ' (99% conf. interval)']);

% Fathom worst variables first
diff_array = b_opts - b_opt_lb;
[sorted_diff_array, index] = sort(diff_array);

fathomed = false; % initialize
check = false; % initialize

if counter_i > 0        
    for i = 1:length(b_opts)
        if sorted_diff_array(i) < 0
            disp(['Ready to fathom out discrete variable set ' ...
                  num2str(dvals_combos(:, index(i))) ', estimated opt (' ...
                  num2str(b_opts(index(i))) ') < global opt 99% lb (' ...
                  num2str(b_opt_lb) ')'])

            [ all_slugs_new, opt_variables_new ] = kwg_dvals_remove( ... 
                all_slugs, opt_variables, dvals_combos(:, index(i)) );

            [ check ] = kwg_check_remove( all_slugs_new, opt_variables_new, buffer, lin, tol);

            if check
                removed_exp = length(all_slugs) - length(all_slugs_new);

                all_slugs = all_slugs_new;
                opt_variables = opt_variables_new;

                removed_dvals = [removed_dvals, dvals_combos(:, index(i))];

                disp(['Fathoming out discrete variable set ' ...
                      num2str(dvals_combos(:, index(i)))])
                disp(['...removed ' num2str(removed_exp) ' experiments'])

                fathomed = true;
            else
                if any(fathomed_dvals == dvals_combos(:,index(i))) == 0 
                    fathomed_dvals = [fathomed_dvals, dvals_combos(:, index(i))];
                    disp(['Adding discrete variable set ' ...
                           num2str(dvals_combos(:, index(i))) ...
                           ' to the fathom queue'])
                end %if
                continue  
            end %if

        end %if
    end %for

    if fathomed % need to recalculate T, W, etc.
        disp(['reset convergence timer, making progress!'])
        not_improving = -1;
        return
    end

    disp(['no variables to fathom'])
else
    counter_i = counter_i + 1;
end %if

%% Determine if sufficient progress is being made
% Filter by completed slugs
completed_slugs = cwc_optimization_completed_slugs( all_slugs );
obj_values = cwc_list_property( completed_slugs, 'objective' );
yield_values = cwc_list_property( completed_slugs, 'yield' );

% Filter by yield criterion 
yield_crit = max(yield_values);
yield_index = find( cwc_list_property(completed_slugs, 'yield') >= ...
                    yield_criterion * yield_crit );
obj_yield_values = obj_values(yield_index);
best_b = max(obj_yield_values);

% Sign change
if prev_best_b < 0
    prev_best_b_correction = - prev_best_b;
else
    prev_best_b_correction = prev_best_b;
end %if

if ( (best_b - prev_best_b) / prev_best_b_correction ) <= percent_improve
    not_improving = not_improving + 1;

    disp([num2str(not_improving) ' iterations without ' ...
          num2str(100*percent_improve) '% exp. improvement or fathoming'])   

    if not_improving > patience
        disp(['Failed to make satisfactory progress for more than ' ...
              num2str(patience) ' slugs'])
        opt_done = 1;
    end
else
    disp(['objective function = ' num2str(best_b) ' >= ' num2str(prev_best_b)])
    prev_best_b = best_b;
    not_improving = 0;
end

%% Get the next set of G-optimal experiments (for each dval set)
% Get G-optimal
[ cvals_opts, G_opts, dvals_opts ] = ...
    cwc_kwg_optimization_get_Gopt( opt_variables, lin, ...
                                   fathomed_dvals, removed_dvals,  ...
                                   X, T_obj, T_y, yield_criterion, b, ...
                                   log_yield_vals, completed_slugs );

%% Add those experiments to all_slugs
for i = 1:length(G_opts)
    cvals_opt = cvals_opts(:, i);
    dvals_opt = dvals_opts(:, i);
    disp(['for dvals ' num2str(dvals_opt') ', proposed cvals ' num2str(cvals_opt')])

    % Estimate uncertainty at G_opt
    X_next = cwc_optimization_cvals_to_X( cvals_opt, dvals_opt, opt_variables, lin );

    innermat = inv(X' * W * X);
    b_next_std = sqrt(mse_obj * (1 + (X_next * innermat * X_next')));
    y_next_std = sqrt(mse_y * (1 + (X_next * innermat * X_next')));
    b_next_pm = tinv(0.99, length(b) - length(T_obj)) * b_next_std;
    y_next_pm = tinv(0.99, length(log_yield_vals) - length(T_y)) * y_next_std;

    b_next = X_next * T_obj;
    y_next = X_next * T_y;

    % Define new slug and simulate
    new_slug_vals = cwc_optimization_cdvals_to_slug( cvals_opt, dvals_opt, opt_variables );
    new_slug = all_slugs(1);
    for opt_var = opt_variables
        eval(['new_slug.' opt_var.label ' = new_slug_vals.' opt_var.label ';']);
    end
    % Set slug number
    
    new_slug.number = max(cwc_list_property(all_slugs_ret,'number'))+1;
    % Reset vals
    new_slug.injected_vol = 0;
    new_slug.current_vol = 0;
    new_slug.residence_time_actual = 0;
    new_slug.in_prep = 0;
    new_slug.in_system = 0;
    new_slug.injected = 0;
    new_slug.in_reactor = 0;
    new_slug.in_hplc = 0;
    new_slug.distance = 0;
    new_slug.distance_matched = 0;
    new_slug.inj_base = 0;
    new_slug.inj_quench = 0;
    new_slug.analysis_time = 0;
    new_slug.complete = 0;
    new_slug.yield = 0;
    new_slug.objective = 0;
    all_slugs_ret = [all_slugs_ret new_slug];

    % Report
    disp(['----- NEXT EXPERIMENT:-----'])
    disp(['    res time:     ' num2str(new_slug.residence_time_goal)])
    disp(['    temp:         ' num2str(new_slug.temperature)])
    disp(['    reag 1:       ' num2str(new_slug.reagent_1)])
    disp(['    reag 1 conc:  ' num2str(new_slug.reagent_1_conc)])
    disp(['    PRE OBJ:      ' num2str(b_next) ' +\- ' num2str(b_next_pm) ...
          ' (99% confidence)'])
    disp(['    PRE YIELD:    ' num2str(exp(y_next)) ' +\- ' num2str(y_next_pm) ...
          ' (99% confidence)'])
end
    
end