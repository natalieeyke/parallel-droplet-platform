

%
%inputs
reagent_table_path = 'C:\Users\Admin\Documents\Input\REAGENT_TABLE_LMB_20170923.xlsx';

ana_path = 'C:\Users\Admin\Desktop\log\ana_path';
stamp = '20170524test.txt';
ana_path = [ana_path stamp]; %add date/time


% reagent_table lists all reagents in the system
reagent_table = ReagentTable();
reagent_table.load_from_file(reagent_table_path);
analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);


% slug_tracker is the matrix of slug information
% index identifies the information contained in each column of slug_tracker 
[all_slugs] = cwc_parse_initial_slugs_v5(reagent_table_path);
rinse_slugs = [];


rho_tf = 889;
inj_vol = 15;
paused_queue =0;
refill_hold =0;

% Check whether slug can be started
[start_prep,prep_flag] = cwc_check_can_start_prep_v2(all_slugs,refill_hold, paused_queue);
inject_rinse_now = cwc_check_can_inject_rinse( all_slugs, refill_hold );

invalid_concs = 0;


   [prep_slug,comp,all_slugs] = ...
            cwc_get_next_slug_to_prep_v4_dilution_adjustment(all_slugs,reagent_table,inj_vol,rho_tf);
    

comp

why

