function [ all_slugs, delete_flag ] = cwc_slugedit_delete( all_slugs, index )
% Given the all_slugs array and the index of a slug to remake, this script
% does just that

delete_flag = ['Cannot delete slug ' num2str(all_slugs(index).number)];
if ~(all_slugs(index).in_prep ~= 0 || all_slugs(index).injected ~= 0)
    delete_flag = ['Deleted slug ' num2str(all_slugs(index).number) ' from queue'];
    all_slugs = all_slugs(1:length(all_slugs) ~= index);
end

end

