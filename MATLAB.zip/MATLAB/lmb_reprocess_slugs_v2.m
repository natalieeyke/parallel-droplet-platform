function [all_slugs,analyte_table,counter_yield_changes] = lmb_reprocess_slugs_v2(process_fun,ana_path,all_slugs,reagent_table_path,ana_time,warmup_time)
%lmb_reprocess_slugs reloads the analyte table and reprocesses all slugs
%that have completed analysis, slugs with failed areas are not remade

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% LMB May 24, 2017
%
% Inputs:
%               process_fun is function name for hplc data processing
%               all_slugs is the list of slugs
%               ana_path is the folder path for the data log
%               reagent_table_path is the path of the reagent table
%               ana_slug is the slug INDEX currently in analysis
%               ana_time is the HPLC analysis time in min 
%               warmup_time is the HPLC warm up time in s
% Outputs:
%               all_slugs is the updated all_slugs
%               analyte_table is the reloaded analyte table
%               counter_yield_changes counts how many yield values were
%               recalculated during the data reprocessing

%  v2 takes in function name 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%reload
analyte_table = AnalyteTable();
analyte_table.load_from_file(reagent_table_path);

ana_time_threshold = (ana_time*60+warmup_time-45); %convert to seconds, adjust with warmup time

optimization_on = 0;
counter_yield_changes = 0;
reprocessing = 1;

for ana_slug = 1:size(all_slugs,2)
    
    if all_slugs(ana_slug).analysis_time >= ana_time_threshold 
        
        data_path = all_slugs(ana_slug).hplc_data_path;
        yield_prior = all_slugs(ana_slug).yield;
        [all_slugs,~] = ...
        feval(process_fun, data_path,ana_path,all_slugs,...
        analyte_table,ana_slug,optimization_on,reprocessing);

        if yield_prior ~= all_slugs(ana_slug).yield

            counter_yield_changes = counter_yield_changes+1;    

        end
    
    end

end



end